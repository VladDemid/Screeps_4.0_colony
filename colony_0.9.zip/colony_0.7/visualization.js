module.exports.roomLevels = function roomLevels() {
    mainRoom = "W49N43"
    const posX = 6
    const posY = 18
    if (!Memory.visual || Game.time % 200) {
        Memory.visual = {}
        Memory.visual.roomsInfo = {}
        for (let room in Memory.gl_var.myRooms) {
            if (Game.rooms[room].controller && Game.rooms[room].controller.my) {
                roomMem = Memory.gl_var.myRooms[room]
                Memory.visual.roomsInfo[room] = {}
                Memory.visual.roomsInfo[room].creepsCount = roomMem.screepsCounts.total
                Memory.visual.roomsInfo[room].spawnLevel = roomMem.spawnLevel
                
            }
        }
    }
    let index = 0
    
    //bucket
    let bucketColor = null
    const myBucket = Game.cpu.bucket
    if (myBucket > 8000) {bucketColor = "green"} else 
    if (myBucket > 6000) {bucketColor = "yellow"} else 
    if (myBucket > 4000) {bucketColor = "orange"} else 
    {bucketColor = "red"}
    
    bucketWidth = 2.9 * (myBucket / 10000)
    new RoomVisual(mainRoom).text(`Bucket-${myBucket}` , posX, posY - 0.4, {color: bucketColor, font: 0.7, stroke: "black", strokeWidth: 0.1, align: "left"});
    new RoomVisual(mainRoom).rect(posX + 4.45, posY - 1.15, 3, 1, {fill: 'transparent', stroke: 'grey'});
    new RoomVisual(mainRoom).rect(posX + 4.5, posY - 1.1, bucketWidth, 0.9, {fill: bucketColor});
    
    
    //стата по румам
    for (let room in Memory.visual.roomsInfo) {
        index++ 
        const controllerLevel = Game.rooms[room].controller.level
        const spawnLevel = Memory.visual.roomsInfo[room].spawnLevel
        const creepsCount = Memory.visual.roomsInfo[room].creepsCount
        
        const thisController = Game.rooms[room].controller
        const progressToUpgrade = thisController.progressTotal - thisController.progress
        const daysToUpgrade = (progressToUpgrade / 290000).toFixed(1)
        
        let statColor = null
        if (creepsCount <= 3) {statColor = "red"} else 
        if (controllerLevel != spawnLevel) {statColor = "orange"} else 
        {statColor = "gray"}
        
        let upgrColor = null
        if (daysToUpgrade <= 1) {upgrColor = "green"} else 
        if (daysToUpgrade < 3) {upgrColor = "yellow"} else 
        {upgrColor = "gray"} 
        
        new RoomVisual(mainRoom).text(`${room}: ${controllerLevel} lvl, ${creepsCount} creeps` , posX, posY + index * 0.55, {color: statColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        if (!isNaN(daysToUpgrade) ) {
            new RoomVisual(mainRoom).text(`Upgr time- ${daysToUpgrade}` , posX + 4.9, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        if (daysToUpgrade < 1) { //уточнение в часах
            const hoursToUpgrade = ((progressToUpgrade / 290000) * 24).toFixed(1)
            new RoomVisual(mainRoom).text(`(${hoursToUpgrade}h)` , posX + 7.6, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        
    }
    
    // console.log("----------------");
} 
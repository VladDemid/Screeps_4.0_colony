const reverseComponents = ["GO"]


module.exports.checkLabs = function checkLabs(room) {
    const allLabs = Memory.gl_var.myRooms[room].labs
    const terminal = Game.rooms[room].terminal
    
    let boostLab = null
    let inputLabs = []
    let outputLabs = []
    
    if (allLabs.boostLab) {
        boostLab = Game.getObjectById(allLabs.boostLab.id)
    }
    if (allLabs.inputLabs) {
        for (lab of allLabs.inputLabs) {
            inputLabs.push(Game.getObjectById(lab.id))
        }
    }
    if (allLabs.outputLabs) {
        for (lab of allLabs.outputLabs) {
            outputLabs.push(Game.getObjectById(lab.id))
        }
    }
    
    if (!Memory.synthesis) {
        Memory.synthesis = {}
    }
    if (!Memory.synthesis[room]) {
        Memory.synthesis[room] = {
            action: "idle",
            status: null,
            components: null
        }
    }
    
    
    
    // this.markLabs(boostLab, inputLabs, outputLabs)
    this.checkReactionsQueue(boostLab, inputLabs, outputLabs, room, terminal)
};

module.exports.checkReactionsQueue = function checkReactionsQueue(boostLab, inputLabs, outputLabs, room, terminal) {
    if (Memory.synthesis[room] && Memory.synthesis[room].action == "idle" && Game.time % 1 == 0) {
        for (component of reverseComponents) {
            if (terminal.store[component] > 5000) {
                Memory.synthesis[room].action = "reverse"
                Memory.synthesis[room].status = "waiting"
                Memory.synthesis[room].components = [component]
                // console.log(component);
                break;
            }
        }
    } else if (Memory.synthesis[room].action == "reverse") {
        if (Memory.synthesis[room].status == "active") {
            for (lab of outputLabs) {
                if (lab.store[Memory.synthesis[room].components[0]] > 0) {
                    if ( lab.cooldown == 0 && (Game.cpu.bucket > 5000 || (Game.cpu.bucket > 1000 && Game.cpu.getUsed() < 16) ) ) {
                        lab.reverseReaction(inputLabs[0], inputLabs[1])  
                    }
                } else {
                    Memory.synthesis[room].status = "ready" //закончили упражнение
                }
            }
        }
    }
    
}

module.exports.markLabs = function markLabs(boostLab, inputLabs, outputLabs) {
    if (boostLab) {
        // console.log(Object.keys(boostLab), );
        new RoomVisual(boostLab.room.name).text(`💊` , boostLab.pos.x, boostLab.pos.y + 0.05, {color: "white", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
    
    if (inputLabs) {
        for (lab of inputLabs) {
            new RoomVisual(lab.room.name).text(`📥` , lab.pos.x, lab.pos.y + 0.05, {color: "white", font: 0.5, stroke: "black", strokeWidth: 0.1});
        }
    }
    
    if (outputLabs) {
        for (lab of outputLabs) {
            new RoomVisual(lab.room.name).text(`📤` , lab.pos.x, lab.pos.y + 0.05, {color: "white", font: 0.4, stroke: "black", strokeWidth: 0.1});
        }
    }
    
};

/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('flags');
 * mod.thing == 'a thing'; // true
 */
// W49N34_scoutTeam_4_W49N37
module.exports.sortFlags = function sortFlags(flags, population) {
    Memory.flagsInfo = {}
    // Memory.constants.roomMaxCreeps["W49N34"]["4"]["FGGGGGGGGGG"] = 2
    for(let flag in flags) {
        const flagSplittedName = flag.split("_")
        if(flagSplittedName[1] == "def") {
            roomName = flags[flag].room.name;
            position = {
                x: flags[flag].pos.x,
                y: flags[flag].pos.y,
                roomName: flags[flag].room.name,
            }
            if (!Memory.gl_var.myRooms[roomName].positions) {
                Memory.gl_var.myRooms[roomName].positions = {}
            }
            Memory.gl_var.myRooms[roomName].positions.defence = position
        } else if (flagSplittedName.length == 4) {
            const flagFromRoom = flagSplittedName[0]
            const flagAction = flagSplittedName[1]
            const flagCount = parseInt(flagSplittedName[2], 10)
            const flagTargetRoom = flagSplittedName[3]
            const flagPosition = flags[flag].pos
            if (!Memory.flagsInfo[flagFromRoom]) {
                Memory.flagsInfo[flagFromRoom] = {}
            }
            const spawnLevel = population.getSpawnLevel(flagFromRoom)
            
            const action = {
                flagTargetRoom: flagTargetRoom,
                flagCount: flagCount,
                flagPosition: flagPosition,
                spawnLevel: spawnLevel
            }
            
            // console.log(JSON.stringify(action));
            
            
            Memory.gl_var.myRooms[flagFromRoom].flagEvents[flagAction] = action
            
            if (Game.rooms[flagFromRoom].storage && Game.rooms[flagFromRoom].storage.store["energy"] > Memory.constants.energyThresholds.upgradersTakeEnergyFromStore + 10000) {
                // Memory.constants.roomMaxCreeps[flagFromRoom][spawnLevel][flagAction] = flagCount
                Memory.flagsInfo[flagFromRoom][flagAction] = action
                // console.log(flagFromRoom, spawnLevel, flagAction, flagCount);
            }
        }
    }
}


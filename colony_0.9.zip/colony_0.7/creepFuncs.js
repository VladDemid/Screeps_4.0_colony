/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('creepFuncs');
 * mod.thing == 'a thing'; // true
 */
 
const routeConstants2 = {
    W49N34: {
        W49N46: ["W50N34","W50N46"],
        W47N31: ["W50N34","W50N30","W47N30"],
        W48N31: ["W50N34","W50N30","W48N30"],
        W45N41: ["W50N34","W50N40","W45N40"],
        W48N46: ["W50N34","W50N46"],
        W42N28: ["W50N34","W50N30","W40N30","W40N29"],
        W41N37: ["W50N34","W50N40","W40N40","W40N37"],
        W49N39: ["W50N34","W50N40","W49N40"],
        W49N37: ["W50N34","W50N37"],
        W51N31: ["W50N34","W50N30","W49N30","W51N30"],
        W46N29: ["W50N34","W50N30","W46N30"],
        W49N31: ["W50N34","W50N31"],
        W49N27: ["W50N34","W50N27"],
        W49N26: ["W50N34","W50N26"],
        W49N39: ["W50N34","W50N40","W49N40"],
        W49N43: ["W50N34","W50N43"],
        W49N37: ["W50N34","W50N37"],
    },
    W49N35: {
        W45N29: ["W49N35","W50N34","W50N30","W45N30"],
        W49N39: ["W50N35","W50N40","W49N40"],
        W49N43: ["W50N35","W50N43"],
        W49N37: ["W50N35","W50N37"],
    },
    W48N31: {
        W51N31: ["W48N30","W51N30"],
        W47N26: ["W48N30","W47N30"],
        W43N29: ["W48N30","W42N30"],
        W42N28: ["W48N30","W42N30"],
        W49N31: ["W48N30","W50N30","W50N31"],
        W46N29: ["W48N30","W46N30"],
        W49N26: ["W48N30","W50N30","W50N26"],
        W48N35: ["W47N33","W47N34","W47N35"],
        W43N31: ["W47N33","W43N30"],
    },
    W48N35: {
        W45N37: ["W48N37", "W46N37"]  
    },
    W47N31: {
        W43N29: ["W47N30","W42N30"],
        W46N29: ["W47N30","W46N30"],
        W49N31: ["W47N30","W50N30","W50N31"],
        W45N29: ["W47N30","W45N30"],
        W48N28: ["W47N30","W47N28"],
        W49N26: ["W47N30","W50N30","W50N26"],
        W48N35: ["W47N33","W47N34","W47N35"],
        W43N31: ["W47N30","W43N30"],
    },
    W42N28: {
        W45N29: ["W42N30","W45N30"],
        W46N29: ["W42N30","W46N30"],
        W41N37: ["W42N30","W40N30","W40N37"],
    },
    W49N31: {
        W49N37: ["W50N31","W50N37"],
    },
    W46N29: {
        W43N31: ["W46N30", "W43N30"],
        W47N28: ["W47N29"],
    },
    W43N29: {
        W43N31: ["W42N30", "W43N30"],
        W41N37: ["W42N30","W40N30","W40N37"],
    },
    W42N28: {
        W43N31: ["W41N29","W42N30", "W43N30"],
        W41N37: ["W42N30","W40N30","W40N37"],
    },
    W45N41: {
        W42N53: ["W45N40","W40N40","W40N53"]
    },
    W49N39: {
        W49N43: ["W49N40","W50N40","W50N43"]
    },
    W49N43: {
        W47N45: ["W49N44","W48N44","W48N45"]
    },
}

//принести [component] в "to" до "ammount"
module.exports.bringSome = function bringSome(creep, component, ammount, from, to) { 
    let left = ammount - to.store[component] // осталось/еще надо
    let takeNow // сейчас взять сколько
        
    if (left > creep.store.getCapacity()) {
        takeNow = creep.store.getCapacity();
    } else {
        takeNow = left;
    }
    
    if (creep.store.getFreeCapacity() == 0  || creep.store[component] == takeNow) {
        creep.memory.full = true;
    } else if (creep.store.getFreeCapacity() == creep.store.getCapacity()) {
        creep.memory.full = false;
    }
    
    if (!creep.memory.full) {
        creep.say("🧪📥");
        if (creep.ticksToLive > 20) {
            if(creep.withdraw(from, component, takeNow) == ERR_NOT_IN_RANGE) {
                creep.moveTo(from);
            }
        }
    } else if (creep.memory.full) {
        creep.say("🧪📤");
        if(creep.transfer(to, component) == ERR_NOT_IN_RANGE) {
            creep.moveTo(to);
        }
    }
}

module.exports.cleanAll = function cleanAll(creep, labs, myTerminal) {
    if (Object.keys(creep.store)[0]) {
        if(creep.transfer(myTerminal, Object.keys(creep.store)[0]) == ERR_NOT_IN_RANGE) {
            creep.moveTo(myTerminal);
        }
    } else if (creep.ticksToLive > 20) {
        let cleanFinished = true
        for (lab of labs) {
            // console.log(lab.mineralType );
            if (lab.mineralType) {
                if(creep.withdraw(lab, lab.mineralType) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(lab);
                }
                cleanFinished = false
                break;
            }
        }
        if (cleanFinished) {
            // console.log("done");
            Memory.synthesis[creep.room.name] = {
                action: "idle",
                status: null,
                components: null
            }
        }
    } else {
        creep.suicide()
    }
    
}

module.exports.reverseReactionPrepare = function reverseReactionPrepare(creep, labs, myTerminal, component0) {
    // for (lab of labs) {
    //     if (lab.mineralType) {
    //         if(creep.withdraw(lab, lab.mineralType) == ERR_NOT_IN_RANGE) {
    //             creep.moveTo(lab);
    //         }
    //         break;
    //     }
    // }
    
}


module.exports.transferCreep = function (creep) {
    
};


module.exports.isOdd = function isOdd(num) { // возвращает 0 если четное, 1 если нечетное
    return num % 2
}

module.exports.travel = function travel(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room);
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit, {reusePath: 15}); 
    }    
}

module.exports.myRoutes = function myRoutes(creep, target_room) {
    
    
    if (creep.ticksToLive == 1499 || (creep.ticksToLive == 599 && creep.memory.role == "claimer" )) {
        
        if (routeConstants2[creep.memory.startRoom] && routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]) {
            creep.memory.stops = routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]
            creep.memory.stop = creep.memory.stops[0]
        }
        
    }
    if (creep.memory.stop) {
        if (creep.pos.roomName != creep.memory.stop) {
            // console.log("no");
            const route = Game.map.findRoute(creep.room, creep.memory.stop);
            if(route.length > 0) {
                const exit = creep.pos.findClosestByRange(route[0].exit);
                creep.moveTo(exit, {reusePath: 15}); 
            }
        } else if (creep.pos.roomName == creep.memory.stop) {
            // console.log("yes");
            creep.memory.stops.splice(0, 1)
            creep.moveTo(25, 25) //TEST
            if (creep.memory.stops[0]) {
                creep.memory.stop = creep.memory.stops[0]
            } else {
                creep.memory.stop = null
            }
        }
    } else {
        // creep.memory.teamReady = false
        // creep.memory.waitingCount = myFlagAction.flagCount
        // if (!creep.memory.teamReady) {
        //     if ( Game.time % 10 == 0) {
        //     }
        // }
        
        const route = Game.map.findRoute(creep.room, target_room);
        if(route.length > 0) {
            const exit = creep.pos.findClosestByRange(route[0].exit);
            creep.moveTo(exit, {reusePath: 15}); 
        }    
    }
}


///////////
module.exports.myRoutesTeam = function myRoutes(creep, target_room) {
    
    if ( (creep.ticksToLive == 1499 || (creep.ticksToLive == 599 && creep.memory.role == "claimer" ) || !creep.memory.waitingRoom) && !creep.memory.stop) {
        if (routeConstants2[creep.memory.startRoom] && routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]) {
            creep.memory.stops = routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]
            creep.memory.stop = creep.memory.stops[0]
            creep.memory.waitingRoom = creep.memory.stops[creep.memory.stops.length - 1]
        }
        
    }
    if (creep.memory.stop) {
        if (creep.pos.roomName != creep.memory.stop) {
            this.travel(creep, creep.memory.stop)            
            // const route = Game.map.findRoute(creep.room, creep.memory.stop);
            // if(route.length > 0) {
            //     const exit = creep.pos.findClosestByRange(route[0].exit);
            //     creep.moveTo(exit, {reusePath: 15}); 
            // }
        } else if (creep.pos.roomName == creep.memory.stop) {
            // console.log("yes");
            creep.memory.stops.splice(0, 1)
            creep.moveTo(25, 25) //TEST
            if (creep.memory.stops[0]) {
                creep.memory.stop = creep.memory.stops[0]
            } else {
                creep.memory.stop = null
            }
        }
    } else if (creep.memory.waitingRoom) {
        const myActionName = creep.name.split("_")[1]
        if (!creep.memory.teamReady) {
            if (creep.pos.roomName != creep.memory.waitingRoom) {
                this.travel(creep, creep.memory.waitingRoom) 
                // const route = Game.map.findRoute(creep.room, creep.memory.waitingRoom);
                // if(route.length > 0) {
                //     const exit = creep.pos.findClosestByRange(route[0].exit);
                //     creep.moveTo(exit, {reusePath: 15}); 
                // } 
            } else {
                if (!creep.pos.inRangeTo(25, 25, 5)) {
                    creep.moveTo(25, 25);
                } else {
                    creep.memory.iAmReady = true
                    if (Game.time % 5 == 0) {
                        const teamCreeps = creep.room.find(FIND_MY_CREEPS, {
                            filter: (creep) => (creep.name.split("_")[1] == myActionName) 
                                            && (Game.creeps[creep.name].memory.iAmReady)
                        })
                        if (teamCreeps.length >= creep.memory.waitingCount || creep.memory.waitingCount == 0) {
                            // console.log("we are ready");
                            creep.say(creep.memory.waitingCount)
                            creep.memory.teamReady = true
                        }
                        // console.log("waiting", teamCreeps.length, creep.memory.waitingCount);
                    }    
                }
            }
        } else if (creep.memory.teamReady) {
            this.travel(creep, target_room) 
            // const route = Game.map.findRoute(creep.room, target_room);
            // if(route.length > 0) {
            //     const exit = creep.pos.findClosestByRange(route[0].exit);
            //     creep.moveTo(exit, {reusePath: 15}); 
            // }    
        }
    }
}

module.exports.moveFromEdge = function moveFromEdge(creep) {
    if (creep.pos.y >= 47) {creep.move(TOP)}  
}




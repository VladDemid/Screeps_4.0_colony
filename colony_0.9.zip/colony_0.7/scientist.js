var roleScientist = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --Scientist logic start--
        
        const myStorage = creep.room.storage  
        const myTerminal = creep.room.terminal  
        
        
        creep.say("🔬");
        
        if (creep.store.getUsedCapacity() == 0) {
            creep.memory.full = false;
        } else if (creep.store.getUsedCapacity() == creep.store.getCapacity() ) {
            creep.memory.full = true;
        }
        
        
        if (!creep.memory.myHomePos && Memory.gl_var.myRooms[creep.room.name].labs && Memory.gl_var.myRooms[creep.room.name].labs.inputLabs) {
            const inputLab1 = Game.getObjectById(Memory.gl_var.myRooms[creep.room.name].labs.inputLabs[0].id)
            creep.memory.myHomePos = inputLab1.pos;
        }
        const HomePos = creep.memory.myHomePos
        
        if (!creep.memory.labs && Memory.gl_var.myRooms[creep.room.name].labs) {
            creep.memory.labs = Memory.gl_var.myRooms[creep.room.name].labs
        }
        const labs = creep.memory.labs
        
        
        if (Game.time % 1 == 0) { //если реакция только началась, а крип решит еще принести
            if (Memory.synthesis[creep.room.name]) {
                creep.memory.synthesis = Memory.synthesis[creep.room.name]
            } else {
                creep.memory.synthesis = null
            }
        }
        const synthesis = creep.memory.synthesis
        
        
        
        
        
        
        
        if (synthesis && synthesis.action != "idle") {
            if (synthesis.action == "reverse") {
                // const targetAmmount = (labs.outputLabs.length) * 1000
                if (synthesis.status == "waiting") { //подготовка 
                    let needToBring = false
                    for (lab in labs.outputLabs) {
                        const outputLab = Game.getObjectById(labs.outputLabs[lab].id)
                        if (outputLab && outputLab.store[synthesis.components[0]] < 400 && myTerminal.store[synthesis.components[0]] >= 0) { // в каждой по 1000 надо
                            // console.log(outputLab.store[synthesis.components[0]], synthesis.components[0]);
                            creepFuncs.bringSome(creep, synthesis.components[0], 400, myTerminal, outputLab)
                            needToBring = true
                            break;
                        }
                    }
                    if (!needToBring) {
                        Memory.synthesis[creep.room.name].status = "active"
                    }
                } else if (synthesis.status == "active") {
                    if (!creep.pos.isNearTo(HomePos.x, HomePos.y)) {
                        creep.moveTo(HomePos.x, HomePos.y, {reusePath: 10});
                    }
                } else if (synthesis.status == "ready") {
                    let allLabs = []
                    for (lab in labs.outputLabs) {
                        allLabs.push(Game.getObjectById(labs.outputLabs[lab].id))
                    }
                    for (lab in labs.inputLabs) {
                        allLabs.push(Game.getObjectById(labs.inputLabs[lab].id))
                    }
                    
                    creepFuncs.cleanAll(creep, allLabs, myTerminal)
                }
            }
        } else {
            if (!creep.pos.isNearTo(HomePos.x, HomePos.y)) {
                creep.moveTo(HomePos.x, HomePos.y, {reusePath: 10});
            }
        }
        
        // console.log(creep.pos.isNearTo(creep.memory.myHomePos));
        
    } 
         
        // --Scientist logic end--
        
}

module.exports = roleScientist;

var roleTower = {

    run: function(tower, towerIndex, towersAllCount, roomReapairTowerId) {
        // const tower = Game.getObjectById(towerId)
        const room = tower.room.name
        const enemyFound = Memory.gl_var.myRooms[room].enemyFound
        const towerCpuStart = Game.cpu.getUsed()
        
        let timer = null
        if (Game.cpu.bucket > 8500) {
            timer = 8
        } else {
            timer = 16
        }
        
        if (enemyFound) {
            const enemyMem = Memory.gl_var.myRooms[room].enemy
            if (enemyMem && enemyMem.id) {
                
                const enemy = Game.getObjectById(enemyMem.id)
                // console.log(tower.pos.inRangeTo(enemy, 10));
                if (enemy && (tower.pos.inRangeTo(enemy, 10) || tower.store["energy"] > 250) ) { 
                    tower.attack(enemy)
                }
                
            }
        // если коцаются крипы скауты, то пытается похилить
        } else if (towerIndex == 0 && Memory.gl_var.myRooms[room].needHeal) {
            const needHeal = Memory.gl_var.myRooms[room].needHeal
            const creepToHeal = Game.creeps[needHeal.creepName]
            if (creepToHeal && creepToHeal.hits < creepToHeal.hitsMax) {
                tower.heal(creepToHeal)
            } else {
                Memory.gl_var.myRooms[room].needHeal = null
            }
        } else if ( ( (roomReapairTowerId && tower.id == roomReapairTowerId) || (!roomReapairTowerId && towerIndex == 0) ) && tower.store["energy"] > 500 && Game.time % timer == 0 ) {
            const low_str = tower.room.find(FIND_STRUCTURES, {
                filter: (i) => (i.structureType == "road" && i.hits <= (i.hitsMax - 800) && i.hitsMax <= 25000)
                            || (i.structureType == "constructedWall" && i.hits <= 10000)
                            || (i.structureType == "rampart" && i.hits <= 10000)
                            || (i.structureType != "rampart" && i.structureType != "constructedWall"
                                && i.hits < (i.hitsMax - 800) 
                                && i.hits <= 250000)// например контейнеры
            });
            low_str.sort((a,b) => a.hits - b.hits);
            
            if (low_str[0]) {
                tower.repair(low_str[0]);
            }
            //!!заменить потом челом (fixer), который будет этим заниматься
        } 
        
        // if (enemy && tower.store["energy"] >= 10) {
        //     tower.attack(enemy);
        // }
        
        const towerCpuEnd = Game.cpu.getUsed() - towerCpuStart
        new RoomVisual(tower.room.name).text(towerCpuEnd.toFixed(2) , tower.pos.x, tower.pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
};

module.exports = roleTower;
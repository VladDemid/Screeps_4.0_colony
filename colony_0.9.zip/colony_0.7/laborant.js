var roleLaborant = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --laborant logic start--
        
        const myStorage = creep.room.storage  
        const myTerminal = creep.room.terminal  
        const towers = Memory.gl_var.myRooms[creep.memory.startRoom].structures["tower"]
        let nuker = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].structures["nuker"]) {
            nuker = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].structures["nuker"][0].id)
        }
        
        let tower0 = null
        if (towers && towers.length) {
            tower0 = Game.getObjectById(towers[0].id)
        }
        // if (nuker) {
        //     console.log(Object.keys(nuker));
        // }
        
        const storageMinEnrg = 100000
        const storageMaxEnrg = 500000
        
        const terminalMinEnrg = 20000
        const terminalMaxEnrg = 100000
        
        creep.say("🔗");
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] >= creep.store.getCapacity() * 0.85 || creep.ticksToLive < 12) {
            creep.memory.full = true;
        }
        if (!creep.memory.homePos && Memory.gl_var.myRooms[creep.room.name].positions && Memory.gl_var.myRooms[creep.room.name].positions.laborantPos) {
            creep.memory.homePos = {
                x: Memory.gl_var.myRooms[creep.room.name].positions.laborantPos.x,
                y: Memory.gl_var.myRooms[creep.room.name].positions.laborantPos.y,
            }
        }
        
        let linkTo = Game.getObjectById(Memory.gl_var.myRooms[creep.room.name].links.linkTo.id)
        
        const homePos = creep.memory.homePos
        
        if (!creep.memory.full && creep.ticksToLive > 5) {
            if(!creep.pos.isEqualTo(homePos.x,homePos.y)) {
                creep.moveTo(homePos.x,homePos.y);
            } else {
                if (linkTo.store["energy"] > 0) {
                    creep.withdraw(linkTo, "energy");
                }
            }
            
        } else if (creep.memory.full) {
            if (myStorage && myStorage.store["energy"] < storageMinEnrg) {
                if(creep.transfer(myStorage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage);
                        // console.log('!near storage', creep.name);
                    }
                }
            } else if (towers && towers.length > 0 && tower0 && tower0.store["energy"] < 800) {
                if(creep.transfer(tower0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower0, {reusePath: 15});
                }
            } else if (myTerminal && myTerminal.store["energy"] < terminalMinEnrg) {
                if(creep.transfer(myTerminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(myTerminal, {reusePath: 15});
                }
            } else if (nuker && nuker.store["energy"] < 300000) {
                if(creep.transfer(nuker, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(nuker, {reusePath: 15});
                }
            } else if (myStorage && myStorage.store["energy"] < storageMaxEnrg) {
                if(creep.transfer(myStorage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage);
                    }
                }
            } 
            // else if (my_terminal && my_terminal.store["energy"] < 20000) {
            //     if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_terminal)) {
            //             creep.moveTo(my_terminal);
            //         }
            //     }
            // } else if (my_storage && my_storage.store["energy"] < 100000) {
            //     if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_storage)) {
            //             creep.moveTo(my_storage);
            //         }
            //     }
            // } else if (my_nuker && my_nuker.store["energy"] < 300000) {
            //     if(creep.transfer(my_nuker, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_nuker)) {
            //             creep.moveTo(my_nuker);
            //         }
            //     }
            // } else if (my_pSpawn && my_pSpawn.store["energy"] < 4000) {
            //     if(creep.transfer(my_pSpawn, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_pSpawn)) {
            //             creep.moveTo(my_pSpawn);
            //         }
            //     }
            // } else if (my_terminal && my_terminal.store["energy"] < 100000) {
            //     if(creep.transfer(my_terminal, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_terminal)) {
            //             creep.moveTo(my_terminal);
            //         }
            //     }
            // } else if (my_storage && my_storage.store["energy"] < 500000) {
            //     if(creep.transfer(my_storage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_storage)) {
            //             creep.moveTo(my_storage);
            //         }
            //     }
            // } else if (my_factory && my_factory.store["energy"] < 5000 && my_factory.store["battery"] < 5000) {
            //     if(creep.transfer(my_factory, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(my_factory)) {
            //             creep.moveTo(my_factory);
            //         }
            //     }
            // } 
        } 
    } 
         
        // --laborant logic end--
        
}

module.exports = roleLaborant;
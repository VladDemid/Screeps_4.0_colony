//Game.market.getAllOrders видимо тратит 3-4 cpu, так что надо юзать сразу для всех товаров 
//1 крип (10W 10C 10M) = 2000 energy = 800cr (по 0.4). Он добывает 2к-2.2к минерала => если минерал стоит больше 0.4 или энергия стоит меньше 0.4, то продавать выгодно 

module.exports.marketLogic = function marketLogic() {
    
    if (Game.time % 3 == 0) { //раз в 10 часов примерно собирать статистику
        this.checkPriceHistory()
    }
    
    // const cpu1 = Game.cpu.getUsed()
    if (Game.time % 200 == 0) {
        this.buyPixels() //очень затратная функция (видимо при скане всех ордеров)
    }
    // console.log((Game.cpu.getUsed() - cpu1).toFixed(2));
}

module.exports.checkPriceHistory = function checkPriceHistory() {
    
    // const cpu1 = Game.cpu.getUsed()
    let allMinerals = Object.keys(MINERAL_MIN_AMOUNT) // H,O,L,K,Z,U,X
    const moreGoods = ["pixel", "energy", "power", "GO", "G", "OH"]
    const allGoods = allMinerals.concat(moreGoods)
    const maxPrices = {
        pixel: 2300,
        energy: 0.7,
    }
    
    let marketPricesStats = {}
    marketPricesStats.allGoods = {}
    
    
    for (let g in allGoods) {
        const good = allGoods[g]
        let avgPrice = 0
        let history = Game.market.getHistory(good)
        const daysOfAvgPrice = 7
        let day = 0
        let dayOfStatistic = history.length - 1
        while (day < daysOfAvgPrice) {
            avgPrice += history[dayOfStatistic].avgPrice
            dayOfStatistic--
            day++
        }
        avgPrice /= 7
        if (maxPrices[good] && maxPrices[good] < avgPrice) {
            // console.log(`${good}: OVERPRICE (${good}: ${maxPrices[good]} ${avgPrice})`);
            
            // marketPricesStats[good] = { // запись
            //     avgPrice: null
            // }
        } else {
            // console.log(`${good}: ${avgPrice.toFixed(2)}`);
            
            // marketPricesStats[good] = { // запись
            //     avgPrice: avgPrice.toFixed(3)
            // }
            marketPricesStats.allGoods[good] = avgPrice.toFixed(3) 
        }
    }
    
    
    Memory.marketStats = {}
    if (!Memory.marketStats) {
        Memory.marketStats = {}
    }
    
    Memory.marketStats.prices = marketPricesStats
    
    
}

module.exports.buyPixels = function buyPixels() {
    
    const pixelsLowPrice = 1700
    const pixelsAvgPrice = 2000
    const lowestCreditAmount = 180000000
    
    if (Game.market.credits > lowestCreditAmount) {
        currentOffers = Game.market.getAllOrders(order => order.resourceType == "pixel" &&
        order.type == ORDER_SELL)
        bestOrder = _.min(currentOffers, 'price')
        if (bestOrder.price < pixelsAvgPrice) { //пока поставил pixelsAvgPrice потом надо Low
            // console.log(bestOrder.price);
            console.log(`SALE! (pixel: ${bestOrder.price.toFixed(2)})`);
        } else {
            // console.log(`дорого (pixel: ${bestOrder.price.toFixed(2)})`);
        }
    }
    
}


funcs = require("funcs");

var roleClaimer = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --scout logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        creep.say("🧲");
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 599) {
                creep.memory.targetRoomMem = targetRoom
            }
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        if (creep.pos.roomName != creep.memory.targetRoomMem) {
            creep.say("🥾🧲");
            creepFuncs.myRoutes(creep, targetRoomMem)
        } else {
            if(creep.room.controller && !creep.room.controller.my) {
                if (creep.room.controller.reservation && creep.room.controller.reservation.ticksToEnd > 0) {
                    if(creep.attackController(creep.room.controller) == ERR_NOT_IN_RANGE) { //если еще зарезервирован, то аттаковать
                        creep.moveTo(creep.room.controller);
                    }
                } else if (creep.room.controller.owner && !creep.room.controller.my) {
                    
                    // if (!creep.pos.isNearTo(creep.room.controller)) {
                    //     creep.moveTo(creep.room.controller);
                    // }
                    
                    if(creep.attackController(creep.room.controller) == ERR_NOT_IN_RANGE) { //если еще зарезервирован, то аттаковать
                        creep.moveTo(creep.room.controller);
                    }
                    
                    // const thisController = creep.room.controller
                    // const claimersNearController = thisController.pos.findInRange(FIND_MY_CREEPS, 1)
                    // const upgradeBlockedTimer = thisController.upgradeBlocked
                    // if (!upgradeBlockedTimer && claimersNearController.length == 2) {
                        
                    //     // console.log("claim");
                    //     if(creep.attackController(creep.room.controller) == ERR_NOT_IN_RANGE) { //если еще зарезервирован, то аттаковать
                    //         creep.moveTo(creep.room.controller);
                    //     }
                    // } else if (upgradeBlockedTimer && upgradeBlockedTimer > creep.ticksToLive && upgradeBlockedTimer < 400) {
                    //     creep.suicide()
                    // }
                    
                } else if (!creep.room.controller.owner) {
                    // console.log(creep.claimController(creep.room.controller));
                    if(creep.claimController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(creep.room.controller);
                        // creep.moveTo(4,37);
                    }
                } else {
                    creep.moveTo(creep.room.controller);
                }
                
                    // if(creep.reserveController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                    //     creep.moveTo(creep.room.controller);
                    // }
                    
            } else {
                if (!creep.pos.isNearTo(creep.room.controller)) {
                    creep.moveTo(creep.room.controller);
                }
            }
            creepFuncs.moveFromEdge(creep)
        }
        // --scout logic end--
        
    }
};

module.exports = roleClaimer;
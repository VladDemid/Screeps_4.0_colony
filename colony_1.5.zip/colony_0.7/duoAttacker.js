funcs = require("funcs");

var roleDuoAttacker = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        let targetPos = null
        let targetRoom = null 
        const myHealerCreepName = creep.name.replace("Attacker", "Healer")
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            creep.memory.needBoost = false //если флага нет, то ничего не делать
        }
        
        let myHealerCreep = null
        if (creep.memory.myHealerCreepId) {
            myHealerCreep = Game.getObjectById(creep.memory.myHealerCreepId)
        } else {
            myHealerCreep = Game.creeps[myHealerCreepName]
        }
        
        if (!creep.memory.myHealerCreepId && myHealerCreep) {
            creep.memory.myHealerCreepId = myHealerCreep.id
        }
        
        creep.memory.needBoost = false
        if (creep.memory.needBoost == undefined || creep.memory.needBoost === true) {
            creepFuncs.boostCreepMass(creep)
        } else {
            if (Game.cpu.bucket > 1000) {
                if (creep.memory.targetRoomMem && creep.pos.roomName != creep.memory.targetRoomMem) {
                    const isAtTheEdges = creepFuncs.isAtTheEdges(creep)
                    if (isAtTheEdges || myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) {
                        // creepFuncs.myRoutes(creep, creep.memory.targetRoomMem)
                        creepFuncs.goCorridors(creep, creep.memory.targetRoomMem)
                        creep.say("🥾💤");
                    }
                } else {
                    creep.say("💤");
                    if ( !myHealerCreep || (myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) ) {
                        if (targetPos && targetPos.x) {
                            if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 1)) {
                                creep.moveTo(targetPos.x, targetPos.y);
                            }
                        } else {
                            if (!creep.pos.inRangeTo(25, 25, 10)) {
                                creep.moveTo(25, 25);
                            }
                        }
                        
                    }
                    
                }
            }
        }
        
        
            
        
        
    }
};

module.exports = roleDuoAttacker;
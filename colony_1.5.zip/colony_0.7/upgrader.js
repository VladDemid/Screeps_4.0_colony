// creepFuncs = require("creepFuncs")

var construction;
// когда 4 link`а, один поставить к контроллеру и держать там крипов
var roleUpgrader = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myStorage = creep.room.storage
        const myController = creep.room.controller
        const containers = Memory.gl_var.myRooms[creep.room.name].containers
        let containersSorted = null
        if (Memory.gl_var.myRooms[creep.room.name].containersSorted) {
            containersSorted = Memory.gl_var.myRooms[creep.room.name].containersSorted
        }
        
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        
        // const ticksToSaveController = 2000
        const energyContainerReservation = 500 //оставить для остальных важных процессов
        
        const energyStoreReservation = Memory.constants.energyThresholds.upgradersTakeEnergyFromStore //оставить для остальных важных процессов
        const ticksToLive = creep.ticksToLive
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest = creepFuncs.isOdd(creepIndex)
        
        
        creep.say("🔋");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (!creep.memory.linkUpgrId && creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } else if (creep.memory.linkUpgrId && creep.store["energy"] >= creep.store.getCapacity() * 0.9) {
            creep.memory.full = true;
        }
        
        
        if (!creep.memory.linkUpgrId) {
            if (Memory.gl_var.myRooms[creep.room.name].links && Memory.gl_var.myRooms[creep.room.name].links.linkUpgr) {
                creep.memory.linkUpgrId = Memory.gl_var.myRooms[creep.room.name].links.linkUpgr.id
            } else {
                creep.memory.linkUpgrId = false
            }
        }   
        const mySource = Game.getObjectById(creep.memory.mySourceId)
        
        // var sources = creep.room.find(FIND_SOURCES);
        
        if (!creep.memory.full) {
            if (ticksToLive > 60) {
                let myUpgrLink = null
                if (creep.memory.linkUpgrId) {
                    myUpgrLink = Game.getObjectById(creep.memory.linkUpgrId)
                }
                
                if (!creep.memory.building && myUpgrLink ) { //&& myUpgrLink.store["energy"] > 0
                    if(creep.withdraw(myUpgrLink, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(myUpgrLink)) {
                            creep.moveTo(myUpgrLink, {reusePath: 8});
                        }
                    }
                } else if (myStorage && myStorage.store["energy"] > 0) {
                    if (myStorage.store["energy"] > energyStoreReservation) {
                        if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(myStorage)) {
                                creep.moveTo(myStorage, {reusePath: 15});
                            } 
                        }
                    } else {
                        if (!creep.pos.inRangeTo(myStorage, 2)) {
                            creep.moveTo(myStorage);
                        }
                        // if (!creep.pos.isNearTo(myStorage)) {
                        //     creep.moveTo(myStorage, {reusePath: 10});
                        // } 
                    }
                } else if (containersSorted && containersSorted.length && containersSorted.length == 2) {
                    if (!creep.memory.targetContainerId || Game.time % (40 + creepIndex*20) == 0) {
                        creep.memory.targetContainerId = containersSorted[1].id
                    }
                    const targetContainer = Game.getObjectById(creep.memory.targetContainerId)
                    if (targetContainer.store["energy"] > energyContainerReservation) {
                        if(creep.withdraw(targetContainer, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(targetContainer)) {
                                creep.moveTo(targetContainer, {reusePath: 8});
                            }
                        }
                    } else {
                        if (!creep.pos.inRangeTo(targetContainer, 2)) {
                            creep.moveTo(targetContainer);
                        } 
                        if (creep.pos.x == targetContainer.pos.x && creep.pos.y == targetContainer.pos.y) {
                            
                        }
                        
                    }
                } else {
                    // var sources = creep.room.find(FIND_SOURCES);
                    
                    const creepIndex = creep.name.split('_')[2] - 1
                    const dest_mining = creepFuncs.isOdd(creepIndex)
                    const target_source = sources[dest_mining];
                    
                    
                    if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_source);
                    }
                    
                }
            } else {
                creep.suicide()
            }
                
        } else if (creep.memory.full) {
            // creep.repair(Game.getObjectById("60cad343beaaeb595ec8cc16"))
            if (Game.time % 20 == 0) {
                construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    creep.memory.building = 1;
                } else { creep.memory.building = 0; }
            }
            // console.log(my_controller);
            
            if (creep.memory.building) {
                const newConstruction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                // console.log(creep.name, " building", construction);
                if(creep.build(newConstruction) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(newConstruction);
                }
            } else if ( (myController.level < 8 || myController.ticksToDowngrade < 199000 || Game.gcl.level < Memory.constants.targetGCL) && Game.cpu.bucket > 1000 ) {
                if (creep.upgradeController(myController) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(myController, {reusePath: 15});
                }
            }
        }
        
        // if (creep.name == "W41N47_upgrader_1") {
        //     if(creep.signController(creep.room.controller, "♻️mr.Zgot🧱trading💳company📦") == ERR_NOT_IN_RANGE) {
        //         creep.moveTo(creep.room.controller);
        //     }
        // }
        // --starter logic end--
        
    }
};

module.exports = roleUpgrader;
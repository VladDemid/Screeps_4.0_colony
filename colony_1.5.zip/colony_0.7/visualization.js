module.exports.roomLevels = function roomLevels() {
    mainRoom = "W45N41"
    const posX = 27
    const posY = 6
    const resetInterval = 10
    if (!Memory.visual || Game.time % (resetInterval * 2) == 0 ) { //Game.time % 200
        Memory.visual = {}
        Memory.visual.roomsInfo = {}
        // for (let room in Memory.gl_var.myRooms) {
        //     if (Game.rooms[room].controller && Game.rooms[room].controller.my) {
        //         roomMem = Memory.gl_var.myRooms[room]
        //         Memory.visual.roomsInfo[room] = {}
        //         Memory.visual.roomsInfo[room].creepsCount = roomMem.screepsCounts.total
        //         Memory.visual.roomsInfo[room].spawnLevel = roomMem.spawnLevel
                
        //     }
        // }
    }
    let index = 0
    
    //bucket
    let bucketColor = null
    const myBucket = Game.cpu.bucket
    if (myBucket > 8000) {bucketColor = "green"} else 
    if (myBucket > 6000) {bucketColor = "yellow"} else 
    if (myBucket > 4000) {bucketColor = "orange"} else 
    {bucketColor = "red"}
    
    bucketWidth = 2.9 * (myBucket / 10000)
    new RoomVisual(mainRoom).text(`Bucket-${myBucket}` , posX, posY - 0.4, {color: bucketColor, font: 0.7, stroke: "black", strokeWidth: 0.1, align: "left"});
    new RoomVisual(mainRoom).rect(posX + 4.45, posY - 1.15, 3, 1, {fill: 'transparent', stroke: 'grey'});
    new RoomVisual(mainRoom).rect(posX + 4.5, posY - 1.1, bucketWidth, 0.9, {fill: bucketColor});
    
    
    //стата по румам
    
    if (Game.time % resetInterval == 0) {
        for (let room in Memory.gl_var.myRooms) {
            if (Game.rooms[room].controller && Game.rooms[room].controller.my) {
                roomMem = Memory.gl_var.myRooms[room]
                Memory.visual.roomsInfo[room] = {}
                Memory.visual.roomsInfo[room].creepsCount = roomMem.screepsCounts.total
                Memory.visual.roomsInfo[room].spawnLevel = roomMem.spawnLevel
                
                const terminal = Game.rooms[room].terminal
                if (terminal) {
                    const mineral = Game.getObjectById(Memory.gl_var.myRooms[room].sciense.mineral.mineralId)
                    Memory.visual.roomsInfo[room].freeSpace = Math.trunc(terminal.store.getFreeCapacity()/1000)
                    Memory.visual.roomsInfo[room].mineralAmount = Math.trunc(terminal.store[mineral.mineralType]/1000)
                }
                
                
                
                // const thisController = Game.rooms[room].controller
                // const progressToUpgrade = thisController.progressTotal - thisController.progress
                // const daysToUpgrade = (progressToUpgrade / 300000).toFixed(1)
                // Memory.visual.roomsInfo[room].daysToUpgrade = (progressToUpgrade / 300000).toFixed(1)
            }
        }
        
    }
    
    
    for (let room in Memory.visual.roomsInfo) {
        index++ 
        const controllerLevel = Game.rooms[room].controller.level
        const terminal = Game.rooms[room].terminal
        const spawnLevel = Memory.visual.roomsInfo[room].spawnLevel
        const creepsCount = Memory.visual.roomsInfo[room].creepsCount
        
        let thisNuker = null
        if (Memory.gl_var.myRooms[room].structures.nuker) {
            thisNuker = Game.getObjectById(Memory.gl_var.myRooms[room].structures.nuker[0].id)
        }
        
        // ;;;;;;;const thisController = Game.rooms[room].controller
        // ;;;;;;;const progressToUpgrade = thisController.progressTotal - thisController.progress
        // ;;;;;;;const daysToUpgrade = (progressToUpgrade / 300000).toFixed(1)
        
        let statColor = null
        if (creepsCount <= 2) {statColor = "red"} else 
        if (controllerLevel != spawnLevel) {statColor = "orange"} else 
        {statColor = "gray"}
        
        // let upgrColor = null
        // if (daysToUpgrade <= 1) {upgrColor = "green"} else 
        // if (daysToUpgrade < 3) {upgrColor = "yellow"} else 
        // {upgrColor = "gray"} 
        
        new RoomVisual(mainRoom).text(`${room}: ${controllerLevel} lvl, ${creepsCount} ©` , posX, posY + index * 0.55, {color: statColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        if (terminal && terminal.store["power"] > 0 ) {
            new RoomVisual(mainRoom).text(`| ${terminal.store["power"]}p` , posX + 3.5, posY + index * 0.55, {color: statColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        if (terminal) {
            // const freeSpace = Math.trunc(terminal.store.getFreeCapacity()/1000)
            const freeSpace = Memory.visual.roomsInfo[room].freeSpace
            if (freeSpace < 100) {
                let textColor = freeSpace > 50 ? "grey" : "red"
                new RoomVisual(mainRoom).text(`|${freeSpace}k fr` , posX + 6.5, posY + index * 0.55, {color: textColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
            }
        }
        if (terminal) {
            const mineral = Game.getObjectById(Memory.gl_var.myRooms[room].sciense.mineral.mineralId)
            const mineralAmount = Memory.visual.roomsInfo[room].mineralAmount
            const myStockMax = Memory.marketStats.myStockMax
            
            let mineralColor = null
            if (myStockMax[mineral.mineralType] < myStockMax.myMineralMin) {
                mineralColor = "red"
            } else if (myStockMax[mineral.mineralType] < myStockMax.myMineralMin * 1.5) {
                mineralColor = "yellow"
            } else {mineralColor = "grey"}
            
            // const smallAmount = myStockMax[mineral.mineralType] < myStockMax.myMineralMin * 1.5
            // let mineralColor = smallAmount ? "red" : "grey"
            
            new RoomVisual(mainRoom).text(`|${mineral.mineralType} ${mineralAmount}k` , posX + 5, posY + index * 0.55, {color: mineralColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        // if (!isNaN(daysToUpgrade) ) {
        //     new RoomVisual(mainRoom).text(`${daysToUpgrade}` , posX + 7, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        // }
        // if (daysToUpgrade < 1) { //уточнение в часах
        //     const hoursToUpgrade = ((progressToUpgrade / 290000) * 24).toFixed(1)
        //     new RoomVisual(mainRoom).text(`(${hoursToUpgrade}h)` , posX + 7.7, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        // }
        //!!!!!!
        // new RoomVisual(mainRoom).text(`| ${terminal.store["LH2O"]} LH2O` , posX + 7, posY + index * 0.55, {color: "green", font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        //!!!!!!
        if (thisNuker) {
            let nuke = "△"
            let nukerCooldown = thisNuker.cooldown
            let nukerReady = "red"
            let strokeWidth1 = 0.01
            let nukeOpacity = 0.45
            if (nukerCooldown < 25000 && nukerCooldown >= 10000 ) {
                nukerReady = "yellow" //наполнение|ожидание ресов
                nuke = "◮"
            } else if (nukerCooldown < 10000 && nukerCooldown > 0) {
                nukerReady = "brown"
                nuke = "◮"
            } else if (nukerCooldown == 0) {
                if (thisNuker.store["energy"] == 300000 && thisNuker.store["G"] == 5000) {
                    nukerReady = "black"
                    nuke = "▲"
                    nukeOpacity = 0.8
                    strokeWidth1 = 0.1
                } else {
                    nukerReady = "white"
                }
            } 
            // console.log(nukerReady);
            // else if (nukerCooldown < 28000) {
            //     nukerReady = "yellow"
            // }
            // thisNuker.store["energy"] < 300000 || thisNuker.store["G"] < 5000
            new RoomVisual(mainRoom).text(`${nuke}` , posX - 0.4, posY + index * 0.55, {color: "yellow", font: 0.35, stroke: nukerReady, strokeWidth: strokeWidth1, align: "center", opacity: nukeOpacity});
        }
        
    }
    
    // console.log("----------------");
} 

var roleGrabber = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --grabber logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        let targetRes = null
        if (Object.keys(creep.store)[0]) {
            targetRes = Object.keys(creep.store)[0]
        } else {
            targetRes = "power"
        }
        
        
        if (creep.store.getUsedCapacity() == 0) {
            creep.memory.full = false;
        } else if (creep.store.getUsedCapacity() > 0 ) {
            creep.memory.full = true;
        }
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
                creep.memory.mode = "grab"
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4].myActionName = 0
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("🥾");
        
        if (creep.memory.mode == "grab") {
            if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
                creepFuncs.goCorridors(creep, targetRoomMem)
            } else {
                if (creep.memory.full) {
                    creep.memory.mode = "carry"
                }
                creep.say("💰");
                // creep.move(LEFT)
                const targetGrab = Game.getObjectById("6177bb1c3c43778c237efe8a")
                
                if (targetGrab && targetGrab.store[targetRes] > 0) {
                    if(creep.withdraw(targetGrab, targetRes) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(targetGrab)) {
                            creep.moveTo(targetGrab, {reusePath: 15});
                        }
                    }
                } else {
                    if (!creep.pos.inRangeTo(25, 25, 3)) {
                        creep.moveTo(25, 25);
                    }
                }
                // creep.move(TOP)
            }
        } else if (creep.memory.mode == "carry") {
            
            if (creep.pos.roomName != creep.memory.startRoom) {
                creepFuncs.goCorridors(creep, creep.memory.startRoom)
            } else {
                if (!creep.memory.full) {
                    creep.memory.mode = "done"
                }
                
                const myStorage = creep.room.storage
                const myTerminal = creep.room.terminal
                // const finalDepot = myTerminal
                let finalDepot = null 
                if (creep.memory.full && Object.keys(creep.store)[0] == "power") {
                    finalDepot = myStorage
                } else { finalDepot = myTerminal }
                
                if(creep.transfer(finalDepot, targetRes) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(finalDepot)) {
                        creep.moveTo(finalDepot, {reusePath: 8});
                    }
                }
                // if (!creep.pos.inRangeTo(25, 25, 3)) {
                //     creep.moveTo(25, 25);
                // }
            }
        } else if (creep.memory.mode == "done") { 
            creep.suicide()
        }
        // --grabber logic end--
        
    }
};

module.exports = roleGrabber;

var rolePowerAttacker = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --powerAttacker logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4].myActionName = 0
        }
        
        
        
        if (!creep.memory.powerId) {
            if (Memory.obsInfo[creep.memory.startRoom] && Memory.obsInfo[creep.memory.startRoom].status == 'active') {
                creep.memory.powerId = Memory.obsInfo[creep.memory.startRoom].powerId
            }
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("🔴🥾");
        
        if (creep.ticksToLive < 1385) { //ждать хилеров
            if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
                creepFuncs.goCorridors(creep, targetRoomMem)
            } else {
                const powerInfo = Memory.obsInfo[creep.memory.startRoom]
                creep.say("🔴");
                let rangeToEdges = 20 - creep.pos.getRangeTo(25, 25)
                if (rangeToEdges < 5) {
                    rangeToEdges = 5
                }
                if (!creep.memory.mode || Game.time % 5) {
                    const enemyCreeps = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 6)
                        if (!enemyCreeps[0]) {
                            creep.memory.mode = "mining"
                        } else {
                            creep.memory.mode = "fight"
                        }
                        
                }
                
                const ticksToDie = 70
                
                if (creep.memory.mode == "mining" && creep.memory.powerId) {
                    const powerBank = Game.getObjectById(creep.memory.powerId)  
                    if (powerBank) {
                        if (creep.hits > creep.hitsMax * 0.25) {
                            const thisStatus = powerInfo.status
                            //вызов carryer'ов заранее
                            if (creep.ticksToLive > powerInfo.carryComeTime && powerBank.hits / 2250 < powerInfo.carryComeTime && powerInfo.status == "active" ) {
                                const flagCarryersName = `${creep.memory.startRoom}_powerCarryer_${powerInfo.carryersNeed}_${creep.memory.targetRoomMem}`
                                Game.rooms[creep.memory.targetRoomMem].createFlag(25, 25, flagCarryersName)
                                Memory.obsInfo[creep.memory.startRoom].status = 'carryersGoing'
                            }
                            // if (powerBank.hits < 1000000 && creep.ticksToLive > 550 && powerInfo.status == "active") {
                            //     const flagCarryersName = `${creep.memory.startRoom}_powerCarryer_${powerInfo.carryersNeed}_${creep.memory.targetRoomMem}`
                            //     Game.rooms[creep.memory.targetRoomMem].createFlag(25, 25, flagCarryersName)
                            //     Memory.obsInfo[creep.memory.startRoom].status = 'carryersGoing'
                            // }
                            if (powerBank.hits < 15000 && (thisStatus == 'active' || thisStatus == 'carryersGoing') ) {
                                Memory.obsInfo[creep.memory.startRoom].status = 'almostDone'
                            }
                            if ( powerBank && (thisStatus == 'active' || thisStatus == "carryersGoing" || thisStatus == "taking") ) {
                                if (!creep.pos.isNearTo(powerBank)) {
                                    creep.moveTo(powerBank, {reusePath: 4});
                                } else {
                                    creep.attack(powerBank)
                                }
                            } else if (thisStatus == 'almostDone' && Game.time % 5 == 0) {
                                //удалять флаги чуть заранее
                                for (let flagname of Object.keys(Memory.obsInfo[creep.memory.startRoom].flags)) { 
                                    if (Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]]) {
                                        Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]].remove()
                                    }
                                }
                                //перезаписывать вручную значение флагов
                                
                                
                                
                                
                                const carryerCreeps = creep.pos.findInRange(FIND_MY_CREEPS, 10, {
                                    filter: (creep) => (creep.name.split("_")[1] == "powerCarryer") 
                                })
                                const carryersCount = carryerCreeps.length
                                if (carryersCount >= powerInfo.carryersNeed || creep.ticksToLive < ticksToDie) {
                                    Memory.obsInfo[creep.memory.startRoom].status = 'taking'
                                }
                            } 
                            
                        }
                    } else if (!powerBank && (powerInfo.status == "taking" || powerInfo.status == "idle" || creep.ticksToLive < ticksToDie) ) {
                        let haveFlags = false
                        for (let flagname of Object.keys(Memory.obsInfo[creep.memory.startRoom].flags)) {
                            if (Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]]) {
                                Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]].remove()
                                haveFlags = true
                            }
                        }
                        
                        if (!haveFlags) {
                            Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerAttacker = 0
                            Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerHealer = 0
                            Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerCarryer = 0
                            Memory.obsInfo[creep.memory.startRoom].status = 'idle'
                            if (!creep.memory.timer) {
                                creep.memory.timer = 10
                            } else if (creep.memory.timer > 1) {
                                creep.memory.timer = creep.memory.timer - 1
                                if (!creep.pos.inRangeTo(25, 25, 2)) {
                                    creep.moveTo(25, 25, {reusePath: 3});
                                }
                            } else {
                                Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerAttacker = 0
                                Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerHealer = 0
                                Memory.constants.roomMaxCreeps[creep.memory.startRoom][8].powerCarryer = 0
                                creep.suicide()
                            }
                        }
                    } else if (!powerBank && powerInfo.status == "active") { //на случай отсутствия powerBank если меня переиграют
                        for (let flagname of Object.keys(Memory.obsInfo[creep.memory.startRoom].flags)) {
                            if (Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]]) {
                                Game.flags[Memory.obsInfo[creep.memory.startRoom].flags[flagname]].remove()
                            }
                        }
                    }
                } else if (creep.memory.mode == "fight") {
                    const enemyCreep = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                    if (enemyCreep) {
                        if(creep.attack(enemyCreep) == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(enemyCreep)) {
                                creep.moveTo(enemyCreep);
                            }
                        }
                    } else {
                        creep.memory.mode = "mining"
                    }
                } else {
                    if (!creep.pos.inRangeTo(25, 25, 1)) {
                        creep.moveTo(25, 25);
                    }
                }
                // creep.move(TOP)
            }
        }
        // --powerAttacker logic end--
        
    }
};

module.exports = rolePowerAttacker;
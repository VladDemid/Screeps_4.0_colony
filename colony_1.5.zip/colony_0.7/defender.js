/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('defender');
 * mod.thing == 'a thing'; // true
 */

var roleDefender = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --defender logic start--
        let defendPos = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].positions) {
            defendPos = Memory.gl_var.myRooms[creep.memory.startRoom].positions.defence
        }
        // console.log(creep.room.name);
        
        const enemyFound = roomsStructures[creep.memory.startRoom].enemyFound
        const enemy = roomsStructures[creep.memory.startRoom].enemy
        
        let rangeCreep = null
        if (enemy) {
            rangeCreep = enemy.pos.getRangeTo(25,25)
            // console.log(rangeCreep);
        }
        
        const enemy_creeps = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
        if (creep.room.name != creep.memory.startRoom) {
            creepFuncs.travel(creep, creep.memory.startRoom)
        } else {
            if (enemy && rangeCreep < 23) {
                creep.say("⚔️");
                if(creep.attack(enemy) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(enemy)) {
                        creep.moveTo(enemy);
                    }
                }
            } else {
                creep.say("💤");
                if (defendPos && defendPos.x) {
                    if (!creep.pos.inRangeTo(defendPos.x, defendPos.y, 2)) {
                        creep.moveTo(defendPos.x, defendPos.y);
                    }
                } else {
                    if (!creep.pos.inRangeTo(25, 25, 7)) {
                        creep.moveTo(25, 25);
                    }
                }
            }
        }
        // creep.move(BOTTOM)
        
        // --defender logic end--
        
    }
};

module.exports = roleDefender;
module.exports.obsMain = function obsMain() {
    //константы (из каких комнат и куда сканить)
    roomsToScan = {
        W49N39: ["W46N40","W47N40","W48N40","W49N40","W50N40","W51N40","W52N40","W53N40","W54N40","W55N40","W50N36","W50N37","W50N38","W50N39","W50N41","W50N42","W50N43","W50N44","W50N45"],
        W41N39: ["W45N40","W44N40","W43N40","W42N40","W41N40","W40N40","W39N40","W38N40","W37N40","W36N40","W35N40","W40N36","W40N37","W40N38","W40N39","W40N41","W40N42"],
        W48N49: ["W53N50","W52N50","W51N50","W50N50","W49N50","W48N50","W47N50","W46N50","W45N50","W44N50","W43N50","W50N53","W50N52","W50N51","W50N49","W50N48","W50N47"],
        // W41N47: ["W42N50","W41N50","W40N50","W39N50","W38N50","W40N53","W40N52","W40N51","W40N49","W40N48","W40N47","W40N46","W40N45","W40N44","W40N43"],
    }
    //скан корридоров
    
    if (!Memory.obsInfo) {Memory.obsInfo = {}}

    if (!Memory.info) {Memory.info = {}}
    
    
    if (!Memory.info.powerBankMaxAmount) {Memory.info.powerBankMaxAmount = 0}
    if (!Memory.info.powerBankRoom) {Memory.info.powerBankRoom = null}
    if (!Memory.info.fullCycleCompleted) {Memory.info.fullCycleCompleted = false}
    if (!Memory.info.wallBlockedRooms) {Memory.info.wallBlockedRooms = []}
    // Memory.info.wallBlockedRooms = []
    // Memory.info.wallBlockedRooms[0] = {
    //     room: "W49N39",
    //     time: 43474229
    // }
    // Memory.info.wallBlockedRooms[1] = {
    //     room: "W41N39",
    //     time: 43470014
    // }
    
    
    if (!Memory.info.obsScanNumber) {Memory.info.obsScanNumber = 0}
    
    // Memory.obsInfo["W49N34"].status = "idle"
    let foundPower = false
    for (let room in Memory.obsInfo) {
        if (room && Memory.obsInfo[room] && Memory.obsInfo[room].status != "idle" && Game.time - Memory.obsInfo[room].time < 1700) {
            foundPower = true
        } else if (Memory.obsInfo[room].status != "idle" && Game.time - Memory.obsInfo[room].time > 1700) {
            Memory.obsInfo[room].status = "idle"
            //добавить убирание флагов
            
        }
        if (Game.time % 1000 == 0) { // очищаем от старых данных про блок стенами
            const wallBlockedRooms = Memory.info.wallBlockedRooms
            const thisRoomBlockedByWallsIndex = wallBlockedRooms.findIndex( item => item.room == room && (Game.time - item.time > 10000) ) // раз в 12 часов обновлять инфу об заблоченных комнатах
            if (thisRoomBlockedByWallsIndex !== -1 ) {
                Memory.info.wallBlockedRooms.splice(thisRoomBlockedByWallsIndex, 1)
            }
        }
    }
    
    if (Game.cpu.bucket > 9000 && !foundPower) {
        // this.obsScan(roomsToScan)
        // this.testObserveWalls()
    }
    
    // this.obsScanInfo(roomsToScan)
};

module.exports.testObserveWalls = function testObserveWalls() {
    // const observer = Game.getObjectById(Memory.gl_var.myRooms["W49N39"].structures.observer[0].id)
    // observer.observeRoom("W50N44")
    // console.log("test W49N39 --> W50N44");
}

module.exports.obsScan = function obsScan(roomsToScan) {
    const maxRooms = 20
    const timerInterval = 71 //Лучше нечетное до 300 (101)
    const i = Game.time % timerInterval
    if (Game.time % timerInterval < maxRooms) { //скан от observer
        for (let fromRoom of Object.keys(roomsToScan)) {
            if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                const isMy = Game.rooms[fromRoom] && Game.rooms[fromRoom].controller.my 
                if (isMy && Game.rooms[fromRoom].controller.level == 8 && Memory.gl_var.myRooms[fromRoom].structures.observer) {
                    const observer = Game.getObjectById(Memory.gl_var.myRooms[fromRoom].structures.observer[0].id)
                    const targetRoom = roomsToScan[fromRoom][i]
                    // const targetRoom = "W50N28"
                    observer.observeRoom(targetRoom)
                }
            }
        }
    }
    // console.log("----");
    if (Game.time % timerInterval == timerInterval - 1) { // запоминать кол-во холостых проходов по всем комнатам
        if (Memory.info.obsScanNumber < 3) {
            Memory.info.obsScanNumber = Memory.info.obsScanNumber + 1
        }
    }
    
    if (Memory.gl_var.gl_i != 1) { //на случай сохранений 
        if (Game.time % timerInterval > 0 && Game.time % timerInterval < maxRooms + 1) { //скан комнаты на предметы (следующий тик)
            const prevI = (Game.time % timerInterval) - 1
            const i = Game.time % timerInterval
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                    const targetRoom = roomsToScan[fromRoom][i-1]
                    if (targetRoom && Game.rooms[targetRoom]) {
                        // console.log("check");
                        const powerBank = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "powerBank"}})[0]
                        const constructedWall = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "constructedWall"}})[0]
                        const thisRoomBlockedByWalls = Memory.info.wallBlockedRooms.find( item => item.room == fromRoom )
                        
                        if (constructedWall) {
                            // console.log("constructedWall");
                            if (thisRoomBlockedByWalls) {
                                thisRoomBlockedByWalls.time = Game.time
                            } else {
                                const newRoomBlockedByWall = {
                                    room: fromRoom,
                                    time: Game.time
                                }
                                Memory.info.wallBlockedRooms.push(newRoomBlockedByWall)
                            }
                        }
                        //powerBank.hits == powerBank.hitsMax && нет Walls (на случай respawn area)
                        if (!constructedWall && !thisRoomBlockedByWalls && powerBank && (powerBank.hits == powerBank.hitsMax || (powerBank.power >= 7000 && powerBank.hits > 800000) )) { //если нашел powerBank ничейный или ничейный, но ценный
                            const powerAmount = powerBank.power
                            let powerAmountNeed = 3200
                            //obsScanNumber == 1 пропуск
                            if (Memory.info.obsScanNumber == 2) {powerAmountNeed = 3200} //раньше это был костыль чтобы сначала искать более жирные powerBank, щас уже самый мощный
                            if (Memory.info.obsScanNumber == 3) {powerAmountNeed = 3200}
                            const timeToDecay = powerBank.ticksToDecay
                            const timeToDecayNeed = 2100
                            const carryersNeed = Math.trunc(powerAmount / 1250) + 1    
                            const distance = Game.map.getRoomLinearDistance(fromRoom, targetRoom) + 1
                            const carryComeTime = distance * 50 + 175 * (Math.trunc(carryersNeed / 3) + 1)
                            
                            let freeSpots = 0
                            const targetX = powerBank.pos.x
                            const targetY = powerBank.pos.y
                            
                            const thisTerminal = Game.rooms[fromRoom].terminal 
                            const haveBoosts = thisTerminal && thisTerminal.store["LO"] > 1500
                            
                            const thisStorage = Game.rooms[fromRoom].storage 
                            const haveEnergy = thisStorage && thisStorage.store["energy"] > 60000
                            const haveFreeSpace = thisStorage && thisStorage.store["power"] < 150000
                            // if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
                            //     boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
                            // }
                            
                            
                            // if (fromRoom == "W48N49") {
                            //     console.log(haveBoosts, haveEnergy, haveFreeSpace, powerAmount > powerAmountNeed, timeToDecay > timeToDecayNeed);
                            // }
                            if (!constructedWall && haveBoosts && haveEnergy && haveFreeSpace && powerAmount > powerAmountNeed && timeToDecay > timeToDecayNeed) {
                                const lookTerrain = Game.rooms[targetRoom].lookAtArea(targetY-1, targetX-1, targetY+1, targetX+1, {asArray: true})
                                for (let i = 1; i <= 9; i++) {
                                    if (lookTerrain[i].terrain == "plain") {
                                        freeSpots++
                                    }
                                }
                                if (freeSpots >= 3) { //финальная проверка
                                    if (Memory.info.powerBankMaxAmount == powerAmount) {
                                        Memory.info.fullCycleCompleted = true //если наткнулся на такой же powerBank, завершить поиск
                                        Memory.info.powerBankRoom = null //если наткнулся на такой же powerBank, завершить поиск
                                    }
                                    if (powerAmount > Memory.info.powerBankMaxAmount) { // --!! тут возможно неправильно первая переменная!!--
                                        Memory.info.powerBankMaxAmount = powerAmount // записать кол-во power 
                                        Memory.info.powerBankRoom = targetRoom // записать комнату
                                        console.log(`found ${powerAmount} power in ${targetRoom}`);
                                    }
                                    if (Memory.info.fullCycleCompleted && Memory.info.powerBankMaxAmount == powerAmount) {
                                        Memory.info.fullCycleCompleted = false
                                        Memory.info.powerBankMaxAmount = 0
                                        console.log(`start mining power in ${targetRoom}`);
                                        const flagAttackerName = `${fromRoom}_powerAttacker_3_${targetRoom}`
                                        const flagHealerName = `${fromRoom}_powerHealer_3_${targetRoom}`
                                        const flagCarryerName = `${fromRoom}_powerCarryer_${carryersNeed}_${targetRoom}`
                                        Memory.obsInfo[fromRoom] = {
                                            status: "active",
                                            targetRoom: targetRoom,
                                            amount: powerAmount,
                                            powerId: powerBank.id,
                                            carryersNeed: carryersNeed,
                                            freeSpots: freeSpots,
                                            distance: distance,
                                            carryComeTime: carryComeTime,
                                            time: Game.time,
                                            flags: {
                                              attackersFlag: flagAttackerName,
                                              healerFlag: flagHealerName,
                                              carryerFlag: flagCarryerName,
                                            },
                                                
                                        }
                                        Memory.info.obsScanNumber = 0
                                        Game.rooms[targetRoom].createFlag(25, 25, flagAttackerName)
                                        Game.rooms[targetRoom].createFlag(25, 25, flagHealerName)
                                        console.log(flagAttackerName);
                                        break; //если нашел из какой-то румы, то все
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
};


module.exports.obsScanInfo = function obsScanInfo(roomsToScan) {
    const maxRooms = 20
    const timerInterval = 23 //Лучше нечетное до 300 (101)
    const i = Game.time % timerInterval
    if (Game.time % timerInterval < maxRooms) { //скан от observer
        for (let fromRoom of Object.keys(roomsToScan)) {
            if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") || true ) {
                const isMy = Game.rooms[fromRoom] && Game.rooms[fromRoom].controller.my 
                if (isMy && Game.rooms[fromRoom].controller.level == 8 && Memory.gl_var.myRooms[fromRoom].structures.observer) {
                    const observer = Game.getObjectById(Memory.gl_var.myRooms[fromRoom].structures.observer[0].id)
                    const targetRoom = roomsToScan[fromRoom][i]
                    // const targetRoom = "W50N28"
                    observer.observeRoom(targetRoom)
                }
            }
        }
    } 
    // console.log("----");
    if (Game.time % timerInterval == timerInterval - 1) { // запоминать кол-во холостых проходов по всем комнатам
        if (Memory.info.obsScanNumber < 3) {
            Memory.info.obsScanNumber = Memory.info.obsScanNumber + 1
        }
    }
    
    if (Memory.gl_var.gl_i != 1) { //на случай сохранений 
        if (Game.time % timerInterval > 0 && Game.time % timerInterval < maxRooms + 1) { //скан комнаты на предметы (следующий тик)
            const prevI = (Game.time % timerInterval) - 1
            const i = Game.time % timerInterval
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") || true ) {
                    const targetRoom = roomsToScan[fromRoom][i-1]
                    if (targetRoom && Game.rooms[targetRoom]) {
                        // console.log("scan room - ", targetRoom);
                        const powerBank = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "powerBank"}})[0]
                        const constructedWall = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "constructedWall"}})[0]
                        // console.log(constructedWall);
                        let blockedByWall = false
                        
                        // console.log(Memory.info.wallBlockedRooms);
                        if (constructedWall) {
                            const wallBlockedRooms = Memory.info.wallBlockedRooms
                            const thisRoomBlockedByWalls = wallBlockedRooms.find( item => item.room == fromRoom)
                            // console.log(!!thisRoomBlockedByWalls);
                            blockedByWall = true
                            if (thisRoomBlockedByWalls) {
                                thisRoomBlockedByWalls.time = Game.time
                            } else {
                                const newRoomBlockedByWall = {
                                    room: fromRoom,
                                    time: Game.time
                                }
                                Memory.info.wallBlockedRooms.push()
                            }
                        }
                        
                        //powerBank.hits == powerBank.hitsMax && нет Walls (на случай respawn area)
                        if (!constructedWall && !blockedByWall && powerBank && (powerBank.hits == powerBank.hitsMax || (powerBank.power >= 7000 && powerBank.hits > 800000) )) { //если нашел powerBank ничейный или ничейный, но ценный
                            const powerAmount = powerBank.power
                            let powerAmountNeed = 3200
                            //obsScanNumber == 1 пропуск
                            if (Memory.info.obsScanNumber == 2) {powerAmountNeed = 3200} //раньше это был костыль чтобы сначала искать более жирные powerBank, щас уже самый мощный
                            if (Memory.info.obsScanNumber == 3) {powerAmountNeed = 3200}
                            const timeToDecay = powerBank.ticksToDecay
                            const timeToDecayNeed = 2100
                            const carryersNeed = Math.trunc(powerAmount / 1250) + 1    
                            const distance = Game.map.getRoomLinearDistance(fromRoom, targetRoom) + 1
                            const carryComeTime = distance * 50 + 175 * (Math.trunc(carryersNeed / 3) + 1)
                            
                            let freeSpots = 0
                            const targetX = powerBank.pos.x
                            const targetY = powerBank.pos.y
                            
                            const thisTerminal = Game.rooms[fromRoom].terminal 
                            const haveBoosts = thisTerminal && thisTerminal.store["LO"] > 1500
                            
                            const thisStorage = Game.rooms[fromRoom].storage 
                            const haveEnergy = thisStorage && thisStorage.store["energy"] > 60000
                            const haveFreeSpace = thisStorage && thisStorage.store["power"] < 150000
                            // if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
                            //     boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
                            // }
                            
                            // const constructedWall = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "constructedWall"}})[0]
                            
                            // if (fromRoom == "W48N49") {
                            //     console.log(haveBoosts, haveEnergy, haveFreeSpace, powerAmount > powerAmountNeed, timeToDecay > timeToDecayNeed);
                            // }
                            if ( haveBoosts && haveEnergy && haveFreeSpace && powerAmount > powerAmountNeed && timeToDecay > timeToDecayNeed) {
                                const lookTerrain = Game.rooms[targetRoom].lookAtArea(targetY-1, targetX-1, targetY+1, targetX+1, {asArray: true})
                                for (let i = 1; i <= 9; i++) {
                                    if (lookTerrain[i].terrain == "plain") {
                                        freeSpots++
                                    }
                                }
                                if (freeSpots >= 3) { //финальная проверка
                                    if (Memory.info.powerBankMaxAmount == powerAmount) {
                                        Memory.info.fullCycleCompleted = true //если наткнулся на такой же powerBank, завершить поиск
                                        Memory.info.powerBankRoom = null //если наткнулся на такой же powerBank, завершить поиск
                                    }
                                    if (powerAmount > Memory.info.powerBankMaxAmount) { // --!! тут возможно неправильно первая переменная!!--
                                        Memory.info.powerBankMaxAmount = powerAmount // записать кол-во power 
                                        Memory.info.powerBankRoom = targetRoom // записать комнату
                                        console.log(`found ${powerAmount} power in ${targetRoom}`);
                                    }
                                    if (Memory.info.fullCycleCompleted && Memory.info.powerBankMaxAmount == powerAmount) {
                                        console.log("found power: ", targetRoom);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
};



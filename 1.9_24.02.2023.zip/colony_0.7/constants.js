

module.exports = {
    
    maxCreeps: {
        1: { //начинают стартеры и все делают до 2 лвл
            starter: 4,
            defender: 2
        },
        2: { //
            starter: 4,
            miner: 2,
            defender: 2,
            upgrader: 2
        },
        3: { // появляется турель
            starter: 2,
            miner: 2,
            defender: 2,
            upgrader: 2
        },
        4: { //
            starter: 0,
            helper: 1,
            miner: 2,
            defender: 2,
            carryer: 1,
            upgrader: 2,
        },
        5: { //
            starter: 0,
            helper: 1,
            miner: 2,
            defender: 0,
            carryer: 1,
            upgrader: 2,
        },
        6: { //
            starter: 0,
            helper: 1,
            miner: 2,
            laborant: 1,
            defender: 0,
            carryer: 1,
            upgrader: 2,
        },
        7: { //
            starter: 0,
            helper: 1,
            miner: 2,
            laborant: 1,
            defender: 0,
            carryer: 0,
            upgrader: 2,
        },
        8: { //
            starter: 0,
            helper: 1,
            miner: 2,
            laborant: 1,
            defender: 0,
            carryer: 0,
            upgrader: 1,
        },
    },
    roomMaxCreeps: {},
    triggers: {
        countsZeroing: 0
    },
    roles: ["starter", "miner", "upgrader", "helper", "defender",
            "carryer", "helper", "scout", "attacker", "claimer", "laborant", 
            "extractor", "scientist", "roadFixer",
            "towner", "scoutTeam", "attackerTeam", "fixer", "healer", "grabber",
            "duoAttacker","duoHealer","duoDismandler","duoMedic", "harasser",
            "powerAttacker", "powerHealer", "powerCarryer"],
    spawnLevels: {
        1: 300,
        2: 550,
        3: 800,
        4: 1300,
        5: 1800,
        6: 2300,
        7: 5600,
        8: 12900
    },
    creepBody: {
        starter: { //универсальные рабочие пока все плохо
            1: { WORK: 1, CARRY: 1, MOVE: 2 },
            2: { WORK: 2, CARRY: 2, MOVE: 4 },
            3: { WORK: 2, CARRY: 6, MOVE: 4 },
            4: { WORK: 2, CARRY: 6, MOVE: 4 },
            5: { WORK: 2, CARRY: 6, MOVE: 4 },
            6: { WORK: 2, CARRY: 6, MOVE: 4 },
            7: { WORK: 2, CARRY: 6, MOVE: 4 },
            8: { WORK: 2, CARRY: 6, MOVE: 4 },
        },
        defender: { //ближний бой на всякий случай пока нет турелей
            1: {MOVE: 2, ATTACK: 2},
            2: {TOUGH: 1, MOVE: 4, ATTACK: 3},
            3: {TOUGH: 3, MOVE: 4, ATTACK: 5},
            4: {TOUGH: 3, MOVE: 4, ATTACK: 5},
            5: {TOUGH: 1, MOVE: 4, ATTACK: 3},
            6: {TOUGH: 1, MOVE: 4, ATTACK: 3},
        },
        miner: { //статичные копатели (строят вокруг себя||скидывают в ближайшие контейнеры/линки)
            2: { WORK: 3, CARRY: 2, MOVE: 2},
            3: { WORK: 5, CARRY: 2, MOVE: 3},
            4: { WORK: 6, CARRY: 3, MOVE: 3},
            5: { WORK: 8, CARRY: 4, MOVE: 4},
            6: { WORK: 10, CARRY: 4, MOVE: 5},
            7: { WORK: 10, CARRY: 4, MOVE: 5},
            8: { WORK: 10, CARRY: 4, MOVE: 5},
        },
        upgrader: {//строят и улучшают контроллер
            2: { WORK: 2, CARRY: 4, MOVE: 3 },
            3: { WORK: 4, CARRY: 4, MOVE: 4 },
            4: { WORK: 6, CARRY: 6, MOVE: 6 },
            5: { WORK: 8, CARRY: 8, MOVE: 8 },
            6: { WORK: 9, CARRY: 9, MOVE: 9 },
            7: { WORK: 13, CARRY: 13, MOVE: 13 },
            8: { WORK: 13, CARRY: 13, MOVE: 13 },
        },
        carryer: {//переносят энергию от контейнеров в склад пока нет линков
            4: { CARRY: 10, MOVE: 5 },
            5: { CARRY: 12, MOVE: 6 },
            6: { CARRY: 12, MOVE: 6 },
        },
        helper: {//переносят энергию по спавнерам и extension
            4: { CARRY: 10, MOVE: 5 },
            5: { CARRY: 12, MOVE: 6 },
            6: { CARRY: 14, MOVE: 7 },
            7: { CARRY: 18, MOVE: 9 },
            8: { CARRY: 20, MOVE: 10 },
        },
        fixer: {
            4: { WORK: 6, CARRY: 6, MOVE: 6 },
            5: { WORK: 8, CARRY: 8, MOVE: 8 },
            6: { WORK: 10, CARRY: 10, MOVE: 10 },
            7: { WORK: 10, CARRY: 10, MOVE: 10 },
            8: { WORK: 15, CARRY: 15, MOVE: 15 },
        },
        roadFixer: {
            6: { WORK: 10, CARRY: 10, MOVE: 10 },
            7: { WORK: 10, CARRY: 10, MOVE: 10 },
            8: { WORK: 10, CARRY: 10, MOVE: 10 },
        },
        laborant: {
            6: { CARRY: 8, MOVE: 4 },
            7: { CARRY: 16, MOVE: 8 },
            8: { CARRY: 24, MOVE: 12 },
        },
        scientist: {
            6: { CARRY: 8, MOVE: 4 },
            7: { CARRY: 8, MOVE: 4 },
            8: { CARRY: 12, MOVE: 6 },
        },
        extractor: {
            6: { WORK: 10, CARRY: 10, MOVE: 10},  
            7: { WORK: 14, CARRY: 16, MOVE: 15},  
            8: { WORK: 14, CARRY: 16, MOVE: 15},  
        },
        scout: {
            4: { MOVE: 1 },
            5: { MOVE: 1 },
            6: { MOVE: 1 },
            7: { MOVE: 1 },
            8: { MOVE: 1 },
        },
        scoutTeam: {
            4: { MOVE: 1 },
            5: { MOVE: 1 },
            6: { MOVE: 1 },
            7: { MOVE: 1 },
            8: { MOVE: 1 },
        },
        attacker: {
            4: { MOVE: 4, ATTACK: 4 },
            5: { MOVE: 10, ATTACK: 10 },
            6: { TOUGH: 2, MOVE: 8, ATTACK: 6 },
            7: { TOUGH: 5, MOVE: 15, ATTACK: 10 },
            // 7: { MOVE: 16, ATTACK: 16 },
            8: { MOVE: 25, ATTACK: 25 },
            // 8: { MOVE: 20, ATTACK: 20 },
            // 8: { MOVE: 1, ATTACK: 1 },
        },
        attackerTeam: {
            4: { TOUGH: 4, MOVE: 8, ATTACK: 4 },
            5: { TOUGH: 5, MOVE: 11, ATTACK: 6 },
            6: { TOUGH: 5, MOVE: 11, ATTACK: 6 },
            7: { TOUGH: 3, CARRY: 2, MOVE: 17, ATTACK: 12 },
            8: { TOUGH: 3, CARRY: 2, MOVE: 25, ATTACK: 20 },
        },
        healer: {
            4: { MOVE: 4, HEAL: 4 },
            5: { MOVE: 5, HEAL: 5 },
            6: { MOVE: 5, HEAL: 5 },
            7: { MOVE: 5, HEAL: 5 },
            8: { MOVE: 8, HEAL: 8 },
        },
        grabber: {
            8: { CARRY: 25, MOVE: 25}  
        },
        powerAttacker: {
            8: { MOVE: 25, ATTACK: 25 }  
        },
        powerHealer: {
            8: { CARRY: 3, MOVE: 16, HEAL: 16 }  
        },
        powerCarryer: {
            8: { CARRY: 25, MOVE: 25 }  
        },
        duoAttacker: {
            8: { TOUGH: 16, CARRY: 2, MOVE: 12, RANGED_ATTACK: 18 },
        },
        duoHealer: {
            8: { TOUGH: 16, CARRY: 2, MOVE: 12, HEAL: 18}  
        },
        duoDismandler: {
            // 8: { TOUGH: 16, CARRY: 2, MOVE: 12, WORK: 20 },
            8: { TOUGH: 17, CARRY: 2, MOVE: 10, WORK: 19, RANGED_ATTACK: 2 },
        },
        duoMedic: {
            // 8: { TOUGH: 14, CARRY: 2, MOVE: 12, HEAL: 22}  
            8: { TOUGH: 16, CARRY: 1, MOVE: 10, HEAL: 23}  
        },
        claimer: {
            4: { CLAIM: 1, MOVE: 2 },
            5: { CLAIM: 2, MOVE: 2 },
            6: { CLAIM: 3, MOVE: 3 },
            7: { CLAIM: 5, MOVE: 5 },
            8: { CLAIM: 10, MOVE: 10 },
            // 8: { CLAIM: 1, MOVE: 1 },
        },
        towner: { 
            4: { WORK: 6, CARRY: 6, MOVE: 6 },
            5: { WORK: 8, CARRY: 8, MOVE: 8 },
            6: { WORK: 8, CARRY: 8, MOVE: 8 },
            // 7: { WORK: 1, CARRY: 7, MOVE: 8 },
            7: { WORK: 10, CARRY: 10, MOVE: 10 },
            8: { WORK: 15, CARRY: 15, MOVE: 15 },
        },
        harasser: {
            8: { TOUGH: 5, CARRY: 2, RANGED_ATTACK: 15, MOVE: 12, HEAL: 16 }
        }
    },
    creepBoosts: {
        duoAttacker: {
            carry: [false, 3], 
            tough: [false, 3], 
            move: [false, 2], 
            ranged_attack: [false, 3]
          
        },
        duoHealer: {
            carry: [false, 3],
            tough: [false, 3],
            move: [false, 2],
            heal: [false, 3]}  
    },
    energyThresholds: {  
        energyReserveForSpawning: 10000,
        upgradersTakeEnergyFromStore: 15000,
        fixerCanSpawnEnergy: 70000,
        decreaseUpgradersNumber1: 90000,
        increaseUpgradersNumber1: 150000,
        storageAvgEnrg: 250000,           // после чего продавать\распределять по другим румам
        decreaseMinersNumber: 600000,     // спавнить одного майнера
        storageMaxEnrg: 800000            // максимум энергии в складе
    },
    economyThresholds: {
        energyTerminalMin: 20000,
        energyTerminalMax: 50000,   //продавать энергию или распределять
        myMineralMin: 10000,        //начинать распределять по базам
        myMineralMax: 40000,        //продавать или не копать
        otherMineralNeed: 6000,     //хранить 'O','U','H'.. в неосновных комнатах
        boostsAmountNeed: 5000,     //хранить 'UO','LH'.. в неосновных комнатах
        boostsAmountMax: 3000,     //распределять бусты и перестать делать после данного числа
    },
    wallsHitsMin: {
        4: 30000,
        5: 100000,
        6: 300000,
        7: 500000,
        8: 100000000,
    },
    repairTowersIds: {
        W38N41: "614e2744e59fcf843ee95bfc",
        W41N39: "614b1bba5f8dd92ebd1e7886",
        W41N47: "6156db3182bcac211e496bad",
        W42N41: "614fd9357ea4b5f320b0002b",
        W43N41: "613460ea121ad37948357ebe",
        W45N41: "60f94e2e45a2b443cf16d8bf",
        W46N39: "614b4c42882ac4567ca422d8",
        W47N45: "61221200d1a7a37427c37b06",
        W48N47: "6153572394d216017902bb76",
        W48N49: "616d3630b781a12f60ca2975",
        W49N39: "61545769656ec13678a0f067",
        W49N43: "610c8eab0982ca7643887d99",
        W49N57: "6380743fb35d51969953346a",
        W51N59: "63c39b6f7c5969bf6a1326f0",
        // W31N41: "63cf962342011dd9ccab4238",
    },
    targetGCL: 12,
    powerRooms: {                         //Требования: (слелать все комнаты поиска ресов - с power крипами)
        Power_creep_1: "W49N39",          //- есть лаборатории
        Power_creep_2: "W38N41",          //- чем чаще спавнят крипов тем лучше
        Power_creep_3: "W48N49",          //- желательно чтобы source и лабы были рядом 
        Power_creep_4: "W41N39",          //- +поближе к центру всех комнат        
        Power_creep_5: "W48N47",          //- возможно дико тупит патфайндинг когда до source нельзя дойти в пределах 1 клетки       
        Power_creep_6: "W46N39", 
        Power_creep_7: "W42N41",
    }                                     
                                          

    
    
};
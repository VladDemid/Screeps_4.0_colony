constants = require("constants")
mainFuncs = require("mainFuncs")
economy = require("economy")
labs = require("labs")
observers = require("observers")
visualization = require("visualization")
population = require("population")
flagsFuncs = require("flags")
creepFuncs = require("creepFuncs")
roleTower = require("tower")
rolePowerCreep = require("powerCreep");


Memory.gl_var = {
    gl_i: 0, //глобальный счетчик
    myRooms: {}
}

// Memory.compound_fusion = {}
// Memory.army = {}
// Memory.creeps = {}

//helper не успевает донести энергию до 2-х и более турелей (только в одну)
//убрать мой "глобальный" объект
//helper в простое много думают (вроде). добавить таймер чтобы сканировать только раз в 5-10 тиков
//если вокруг helper 2 и более пустых ext, то встать
//у attackerTeam, scoutTeam при вхождении в новую комнату (stops[]) делать creep.moveFromBorder на 1
//если около tower находится враг, то активировать safemode 
//чекнуть как апгрейдеры (4) берут ресы из их линка
//extractor иногда когда берут свой буст идут одновременно к терминалу и лабе (при чем буст взял)
//не спавнить майнеров если полный upgraderLink и storage
// добавить проверку wall в целевой комнате чтобы не спавнить PowerAttacker и других scout (чисто чтобы лишние не спавнились)


//автоскупка GO переделывание в G и O. O продавать по низшим ценам, G раскидывать по 10к, потом продавать по средней цене
//по сравнению цены на энергию и текущий ресурс (H, O, X..) определять покупать его или копать самому 
//скрипт по авто-покупке и авто-продаже определенных ресурсов (можно пока просто списком)
//проверка power miners флагов, вдруг остаются

Memory.constants = constants
let roomsStructures = {} // nameRoom->strName->Obj to use
let roomsMaxCreeps = {} // nameRoom->lvl->role->maxNumber


module.exports.loop = function () {
    
    if (Game.time % 1405 == 0 ) {
        Game.getObjectById('61834f568e77709a83f6c29f').launchNuke(new RoomPosition(6,18, 'W33N42'));
        Game.getObjectById('617af2a6a97db6a4efd656a1').launchNuke(new RoomPosition(21,35, 'W33N42'));
        Game.getObjectById('618d9cf0d4fff184e476ba45').launchNuke(new RoomPosition(22,22, 'W33N42'));
        Game.getObjectById('6185c6f57dd02df9ebab0f71').launchNuke(new RoomPosition(21,35, 'W33N42'));
        Game.getObjectById('61631425fd720f11fc3a69bf').launchNuke(new RoomPosition(6,18, 'W33N42'));
    }
    
    
    Memory.gl_var.creeps_number = 0
    Memory.gl_var.gl_i_max = 200
    Memory.gl_var.gl_i++
    
    const myRooms = Memory.gl_var.myRooms
    
    if (Memory.gl_var.gl_i > Memory.gl_var.gl_i_max) {Memory.gl_var.gl_i = 1}
    
    if (Memory.gl_var.gl_i == 1) {
        const myRooms = Game.rooms
        for (let key in myRooms) { // --ROOMS 1--
            const maxCreepsDefault = JSON.parse(JSON.stringify(Memory.constants.maxCreeps))
            Memory.constants.roomMaxCreeps[key] = maxCreepsDefault
            roomsMaxCreeps[key] = maxCreepsDefault
            if (Game.rooms[key].controller && Game.rooms[key].controller.my) {//мои комнаты с контроллером
                roomsStructures[key] = {} // для будущего наполнения зданиями и прямого использования крипами
                let roomObj = {} //объект в память gl_var->myRooms->...
                roomObj = {roomName: key}
                
                let structuresRaw = JSON.parse(JSON.stringify(Game.rooms[key].find(FIND_MY_STRUCTURES)))//для копирования без ссылок
                roomObj.structuresRaw = structuresRaw // найти все здания (0:.., 1:.., 2:..,)
                // roomObj.structuresRaw = Game.rooms[key].find(FIND_MY_STRUCTURES) // найти все здания (0:.., 1:.., 2:..,)
                roomObj.structures = {} 
                
                for (str of roomObj.structuresRaw) { // --STRUCTURES-- сортировка зданий по типу
                
                    if (str.structureType == "extension") { //очистка лишних полей для extensions
                        let newStr = {}
                        newStr.id = str.id
                        newStr.pos = {}
                        newStr.structureType = "extension"
                        
                        str = newStr
                    } else if (str.structureType == "rampart") {
                        str = {}
                    } else if (str.structureType == "lab") {
                        delete str.room;
                        delete str.pos;
                        delete str.energyCapacity;
                        delete str.owner;
                        delete str.my;
                        delete str.hitsMax;
                        delete str.hits;
                    } else if (str.structureType == "terminal" || str.structureType == "storage" || 
                               str.structureType == "link" || str.structureType == "factory" || str.structureType == "tower") {
                        delete str.room;
                        delete str.pos;
                        delete str.owner;
                        delete str.store;
                        delete str.my;
                        delete str.hitsMax;
                        delete str.hits;
                    } 
                
                    if (roomObj.structures[str.structureType]) { //наполнение зданий по комнатам в память
                        roomObj.structures[str.structureType].push(str)
                    } else {
                        roomObj.structures[str.structureType] = []
                        roomObj.structures[str.structureType].push(str)
                    }
                    
                    if (roomsStructures[key][str.structureType]) { //наполнение зданий по комнатам в прямой объект
                        roomsStructures[key][str.structureType].push(str)
                    } else {
                        roomsStructures[key][str.structureType] = []
                        roomsStructures[key][str.structureType].push(str)
                    }
                    // console.log(roomsStructures[key], key);
                } 
                
                
                delete roomObj.structuresRaw // удаление лишней инфы
                
                roomsStructures[key]["source"] = Game.rooms[key].find(FIND_SOURCES)
                
                
                roomObj.sources = roomsStructures[key]["source"]
                roomObj.constructionsSites = roomsStructures[key]["constructionsSites"]
                roomObj.containers = Game.rooms[key].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}})
                
                roomObj.flagEvents = {}
                roomObj.foundConstrSites = Game.rooms[key].find(FIND_CONSTRUCTION_SITES)
                
                roomObj.sciense = {}
                roomObj.sciense.mineral = {}
                const mineralId = Game.rooms[key].find(FIND_MINERALS)[0].id
                const mineral = Game.getObjectById(mineralId)
                roomObj.sciense.mineral.mineralId = mineralId
                roomObj.sciense.mineral.mineralType = mineral.mineralType
                roomObj.sciense.mineral.mineralAmount = mineral.mineralAmount
                
                // const sources = Game.rooms[my_rooms[i]].find(FIND_SOURCES)
                
                Memory.gl_var.myRooms[key] = roomObj
                
                Memory.gl_var.myRooms[key].enemyFound = false
                Memory.gl_var.myRooms[key].enemy = null //перейти на это
                
                roomsStructures[key].enemyFound = false
                roomsStructures[key].enemy = null // это убрать
                
                
            }
        }
        // Memory.gl_var.my_structures = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES)
        // console.log(Memory.gl_var.my_structures)
        // console.log(Game.rooms[0])
        
    }
    
    
    
    if (Game.time % 5 == 0 || Memory.gl_var.gl_i == 1) {
        flagsFuncs.sortFlags(Game.flags, population)
    }
    
    // const spawn1 = Game.getObjectById("60c93c4071e3e01e3b385a3d")
    // new RoomVisual("W49N34").text(`spawn: ${spawn1.store["energy"]} ${roomsStructures["W49N34"]["spawn"][0].energy}` , 25, 33, {color: "grey", font: 0.6, stroke: "black", strokeWidth: 0.1});
    
    for (let room in myRooms) { // --ROOMS 2--
        if (Game.rooms[room] && Game.rooms[room].controller && Game.rooms[room].controller.my) {
            // console.log(room, Memory.gl_var.myRooms[room].structures.nuker[0].id);
            if (roomsStructures[room].extension && roomsStructures[room].extension.length > 0) {
                if (Game.rooms[room].energyAvailable < Game.rooms[room].energyCapacityAvailable) { // && roomsStructures[room].extension[0].store.getFreeCapacity("energy") == 0
                    // обновление данных, т.к. объекты запоминаются не ссылками, а в моменте gl_i==1
                    
                    //проход по "extensions"
                    const ext0 = Game.getObjectById(roomsStructures[room].extension[0].id)
                    if (ext0.store.getFreeCapacity("energy") == 0) { //???только если в первом нет пустого места???
                        for (let i in roomsStructures[room].extension) {
                            roomsStructures[room].extension[i] = Game.getObjectById(roomsStructures[room].extension[i].id)  
                        }
                        roomsStructures[room].extension.sort((a,b) => a.energy - b.energy);
                        
                        // добавление pos для первого
                        // const ext0New = Game.getObjectById(roomsStructures[room].extension[0].id)
                        // roomsStructures[room].extension[0].pos = {}
                        // roomsStructures[room].extension[0].pos = ext0New.pos
                    }
                    
                    //проход по "spawns"
                    if (roomsStructures[room].spawn) { //!!!!!была ошибка какая-то
                        for (let i in roomsStructures[room].spawn) {
                            roomsStructures[room].spawn[i] = Game.getObjectById(roomsStructures[room].spawn[i].id)  
                        }
                        roomsStructures[room].spawn.sort((a,b) => a.energy - b.energy);
                    }
                    
                    // //проход по "source"
                    // if (roomsStructures[room].sources) { 
                    //     for (let i in roomsStructures[room].source) {
                    //         roomsStructures[room].source[i] = Game.getObjectById(roomsStructures[room].source[i].id)  
                    //     }
                    // }
                    
                    
                }
            }
            // проход по контейнерам
            if (Memory.gl_var.myRooms[room].containers && Memory.gl_var.myRooms[room].containers.length) {
                for (let i in Memory.gl_var.myRooms[room].containers) {
                    Memory.gl_var.myRooms[room].containers[i] = Game.getObjectById(Memory.gl_var.myRooms[room].containers[i].id)
                }
                Memory.gl_var.myRooms[room].containers.sort((a,b) => a.id - b.id);
                
                //containersSorted[0] - наименее заполненный
                Memory.gl_var.myRooms[room].containersSorted = Memory.gl_var.myRooms[room].containers
                Memory.gl_var.myRooms[room].containersSorted.sort((a,b) => a.store["energy"] - b.store["energy"])
                // Memory.gl_var.myRooms[room].containersSorted.sort((a,b) => a.energy - b.energy)
            }
            
            
            //проход по стройкам
            //переделать (при постройке, хочет продолжать строить его, а уже такого объекта нет)
            //чекнуть сколько cpu когда нет строек
            roomsStructures[room]["constructionsSites"] = Game.rooms[room].find(FIND_MY_CONSTRUCTION_SITES)[0] 
            
            //силовое поле на storage
            if (Memory.gl_var.gl_i == 1) {
                const thisStorage = Game.rooms[room].storage
                if (thisStorage) {
                    const thatObjts = Game.rooms[room].lookAt(thisStorage)
                    if (thatObjts.length > 1) {
                        thatObjts.forEach( (obj) => {
                            if (obj.type == LOOK_STRUCTURES && obj.structure.structureType == "rampart") {
                                Memory.gl_var.myRooms[room].strgRmpId = {
                                    id: obj.structure.id
                                }
                            }
                        } )
                    }
                }
            }
            
            //турели
            const towers = Memory.gl_var.myRooms[room].structures.tower
            if (towers) {
                let roomReapairTowerId = null
                if (Memory.constants.repairTowersIds[room]) {
                    const repairTower = Game.getObjectById(Memory.constants.repairTowersIds[room])
                    if (repairTower) {
                        roomReapairTowerId = Memory.constants.repairTowersIds[room]
                    }
                }
                for (let towerIndex in towers) {
                    const towerObj = Game.getObjectById(towers[towerIndex].id)
                    Memory.gl_var.myRooms[room].structures.tower[towerIndex]
                    roleTower.run(towerObj, towerIndex, towers.length, roomReapairTowerId)
                }
                Memory.gl_var.myRooms[room].structures.tower.sort((a,b) => a.energy - b.energy)
                // if (room == "W47N31") {
                //     console.log(Memory.gl_var.myRooms[room].structures.tower[0].store);
                //     console.log(Memory.gl_var.myRooms[room].structures.tower[1].store);
                //     console.log("----------");
                // }
            }
            
            //link's
            if (Memory.gl_var.myRooms[room].structures.link && Memory.gl_var.myRooms[room].structures.link.length) {
                if (Memory.gl_var.gl_i == 1) {
                    //записать координаты точки лаборанта
                    const thisStorage = Game.rooms[room].storage
                    const thisController = Game.rooms[room].controller
                    if (thisStorage) {
                        
                        if (!Memory.gl_var.myRooms[room].positions) {
                            Memory.gl_var.myRooms[room].positions = {}
                        }
                        
                        Memory.gl_var.myRooms[room].links = {}
                        
                        const linkTo = thisStorage.pos.findInRange(FIND_MY_STRUCTURES, 2, {filter: {structureType: STRUCTURE_LINK}})[0]
                        const linkUpgr = thisController.pos.findInRange(FIND_MY_STRUCTURES, 2, {filter: {structureType: STRUCTURE_LINK}})[0]
                        
                        if (linkTo) {
                            const xPos = (thisStorage.pos.x + linkTo.pos.x)/2
                            const yPos = (thisStorage.pos.y + linkTo.pos.y)/2
                            Memory.gl_var.myRooms[room].positions.laborantPos = {
                                x: xPos,
                                y: yPos,
                            }
                            Memory.gl_var.myRooms[room].links.linkTo = {
                                id: linkTo.id
                            }
                        }
                        if (linkUpgr) {
                            Memory.gl_var.myRooms[room].links.linkUpgr = {
                                id: linkUpgr.id
                            }
                        }
                    }
                }
                
            //проход по линкам
                if (Game.time % 5 == 0) {  
                    if (Memory.gl_var.myRooms[room].links.linkTo) {
                        const linkToId = Memory.gl_var.myRooms[room].links.linkTo.id 
                        const linkTo = Game.getObjectById(linkToId)
                        
                        let linkUpgrId = null 
                        let linkUpgr = null 
                        if (Memory.gl_var.myRooms[room].links.linkUpgr) {
                            linkUpgrId = Memory.gl_var.myRooms[room].links.linkUpgr.id
                            linkUpgr = Game.getObjectById(linkUpgrId) 
                        }
                        
                        const links = Memory.gl_var.myRooms[room].structures.link
                        for (let i = 0; i < links.length; i++) {
                            const linkId = Memory.gl_var.myRooms[room].structures.link[i].id
                            if (linkId != linkToId && (!linkUpgrId || linkId != linkUpgrId) ) {
                                link = Game.getObjectById(linkId)
                                if (!linkUpgr) {
                                    if (link.store["energy"] > 600 && link.cooldown == 0 && linkTo.store["energy"] == 0) {
                                        link.transferEnergy(linkTo);
                                        break;
                                    }
                                } else if (link.store["energy"] > 600 && link.cooldown == 0) {
                                    const myStorage = link.room.storage
                                    //наполнять storage сначала до определенного момента
                                    if (linkTo.store["energy"] == 0 && myStorage.store["energy"] < (Memory.constants.energyThresholds.upgradersTakeEnergyFromStore + 10000) ) {
                                        link.transferEnergy(linkTo);
                                        break;
                                    } else if (linkUpgr.store["energy"] <= 200 ) {
                                    //потом давать linkUpgr
                                        link.transferEnergy(linkUpgr);
                                        break;
                                    } else if (linkTo.store["energy"] == 0) {
                                    //если linkUpgr наполнен, то уже на базу отправлять
                                        link.transferEnergy(linkTo);
                                        break;
                                    }
                                }
                            }
                        }
                        
                    }
                }
            }
            
            //labs
            
            if (Game.rooms[room].controller.level >= 6 && Memory.gl_var.myRooms[room].structures.lab && Memory.gl_var.myRooms[room].structures.lab.length >= 1) {
                let labObject = {} //для внесения в память в конце
                if (Memory.gl_var.gl_i == 1 && Game.rooms[room].terminal) { //сначала найти и отсортировать
                    // Memory.gl_var.myRooms[room].labs = {}
                    const boostLab = Game.rooms[room].terminal.pos.findInRange(FIND_MY_STRUCTURES, 1, {filter: {structureType: STRUCTURE_LAB}})[0]
                    // Memory.gl_var.myRooms[room].labs.boostLab = { id: boostLab.id}
                    labObject.boostLab = { id: boostLab.id}
                    
                    if (Memory.gl_var.myRooms[room].structures.lab.length >= 6) {
                        let reactLabs = []
                        for (lab of Memory.gl_var.myRooms[room].structures.lab) {
                            if (!boostLab || lab.id != boostLab.id) { // если не бустлаба
                                reactLabs.push(lab)
                            }
                        }
                        
                        // if (room == "W41N47" && thisLab.id == "619968e0633f33ce45c8619c") {
                        //     console.log(thisLab.pos.findInRange(FIND_MY_STRUCTURES, 2, {filter: {structureType: STRUCTURE_LAB}}).length, Memory.gl_var.myRooms[room].structures.lab.length - 1);
                        // }
                        let inputLabs = []
                        for (lab of reactLabs) {
                            const thisLab = Game.getObjectById(lab.id)
                            if (thisLab.pos.findInRange(FIND_MY_STRUCTURES, 2, {filter: {structureType: STRUCTURE_LAB}}).length >= Memory.gl_var.myRooms[room].structures.lab.length - 1) {
                                inputLabs.push({id: lab.id})
                            }
                            if (inputLabs.length == 2) {
                                break;
                            }
                        }
                        if (inputLabs.length == 2) {
                            labObject.inputLabs = inputLabs
                            
                            let outputLabs = []
                            for (lab of reactLabs) {
                                if (lab.id != inputLabs[0].id && lab.id != inputLabs[1].id) {
                                    outputLabs.push({id: lab.id})
                                }
                            }
                            labObject.outputLabs = outputLabs
                        }
                    }
                    
                    Memory.gl_var.myRooms[room].labs = labObject
                    
                }
                
                //логика лабораторий
                if (Memory.gl_var.myRooms[room].structures.lab.length >= 6) {
                    labs.checkLabs(room)
                }
            }
            
            //powerSpawn
            let pSpawn = null
            if (Memory.gl_var.myRooms[room].structures["powerSpawn"]) {
                pSpawn = Game.getObjectById(Memory.gl_var.myRooms[room].structures["powerSpawn"][0].id)
            }
            if (Game.cpu.bucket > 8500 && pSpawn && pSpawn.store["energy"] > 50 && pSpawn.store["power"] >= 1) {
                pSpawn.processPower()
            }
            
            //запись прямого объекта в память для наглыдности
            // delete Memory.roomsStructures //убрал недавно
            // Memory.roomsStructures[room] = roomsStructures[room]
            
            //после долгого обстрела на 1 тик башни и крипы перестали атаковать врага, потом снова (gl_i не была == 1)
            if (Game.time % 2 == 0 || Memory.gl_var.myRooms[room].enemyFound == true) {
                const enemies = Game.rooms[room].find(FIND_HOSTILE_CREEPS)
                if (enemies && enemies.length > 0) {
                    // console.log(enemy);
                    roomsStructures[room].enemyFound = true
                    roomsStructures[room].enemy = enemies[0]//это убрать
                    
                    Memory.gl_var.myRooms[room].enemyFound = true
                    Memory.gl_var.myRooms[room].enemy = enemies[0]// это оставить
                } else {
                    roomsStructures[room].enemyFound = false
                    roomsStructures[room].enemy = null//это убрать
                    
                    Memory.gl_var.myRooms[room].enemyFound = false
                    Memory.gl_var.myRooms[room].enemy = null// это оставить
                }
            }
            const containersSorted = Memory.gl_var.myRooms[room].containersSorted
            
        }
        
    }
    

    
    mainFuncs.rolesCountZeroing() //обнуление счетчиков в памяти
    mainFuncs.rolesMaxModifier(population, roomsMaxCreeps)  //корректировка максимального числа каждой роли
    economy.marketLogic(constants) 
    observers.obsMain(constants)
    
    
    
    for (let powerCreep in Game.powerCreeps) {
        if (Game.powerCreeps[powerCreep].ticksToLive) { // если живой, то управлять им
            const creepCpuStart = Game.cpu.getUsed()
            rolePowerCreep.run(Game.powerCreeps[powerCreep]) 
            const creepCpuEnd = Game.cpu.getUsed() - creepCpuStart
            new RoomVisual(Game.powerCreeps[powerCreep].room.name).text(creepCpuEnd.toFixed(2) , Game.powerCreeps[powerCreep].pos.x, Game.powerCreeps[powerCreep].pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
        } else if (!Game.powerCreeps[powerCreep].ticksToLive) {
            // console.log(Object.keys(Game.powerCreeps[powerCreep]));
            const powerRoom = Memory.constants.powerRooms[powerCreep]
            if (powerRoom) {
                let powerSpawn = null
                if (Memory.gl_var.myRooms[powerRoom].structures.powerSpawn) {
                    powerSpawn = Game.getObjectById(Memory.gl_var.myRooms[powerRoom].structures.powerSpawn[0].id)
                }
                if (powerSpawn) {
                    if(!(Game.powerCreeps[powerCreep].spawnCooldownTime > Date.now())) {
                        Game.powerCreeps[powerCreep].spawn(powerSpawn);
                    }
                }
            }
        }
        
        
    }
    
    Memory.roomsMaxCreeps = roomsMaxCreeps
    
    for (var name in Game.creeps) { // ---CREEPS---
        const creepCpuStart = Game.cpu.getUsed()
        Memory.gl_var.creeps_number++
        const creep = Game.creeps[name]
        if (!creep.spawning) {
            Memory.gl_var.myRooms[creep.memory.startRoom].screepsCounts[creep.memory.role]++
            mainFuncs.activateCreep(creep, roomsStructures, creepFuncs)
        }
        const creepCpuEnd = Game.cpu.getUsed() - creepCpuStart
        new RoomVisual(creep.room.name).text(creepCpuEnd.toFixed(2) , creep.pos.x, creep.pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
    
    //очистка памяти крипов
    if (Game.time % 1000 == 0) {
        for (let name in Memory.creeps) {
            if (!Game.creeps[name]) {
                delete Memory.creeps[name]
            }
        }
    }
    
    let minSpawnLevel = 8 
    for (let room in myRooms) { // --ROOMS 3-- для спавна крипов
        // if (Memory.gl_var.myRooms[room].labs) {
        //     console.log(room, Game.getObjectById(Memory.gl_var.myRooms[room].labs.boostLab.id).mineralType);
        // }
        const controllerLevel = Game.rooms[room].controller.level
        const spawnLevel = population.getSpawnLevel(room)
        if (spawnLevel < minSpawnLevel) { //для чистки ниже
            minSpawnLevel = spawnLevel
        }
        // console.log(spawnLevel, room);
        const screepsCounts = Memory.gl_var.myRooms[room].screepsCounts
        for (let role in Memory.constants.roomMaxCreeps[room][spawnLevel]) { //проход по необходимому максимуму крипов кажддой роли
            let correctQueue = true // спавнить duoHealer после его duoAttacker
            complexRoles = ["duoHealer", "duoAttacker","duoMedic", "duoDismandler"]
            if (complexRoles.includes(role)) {
                const maxCreepsRole = Memory.constants.roomMaxCreeps[room][spawnLevel][role]
                if (role == "duoHealer") { //проверка на duoAttacker
                    for (let i = 1; i <= maxCreepsRole; i++) {
                        const healerCreepName = `${room}_duoHealer_${i}`
                        const healerCreep = Game.creeps[healerCreepName]
                        if (!healerCreep) {
                            const attackerCreepName = `${room}_duoAttacker_${i}`
                            const attackerCreep = Game.creeps[attackerCreepName]
                            if (!attackerCreep) {
                                correctQueue = false
                            }
                        }
                    }
                } 
                else if (role == "duoMedic") { //проверка на duoDismandler
                    for (let i = 1; i <= maxCreepsRole; i++) {
                        // console.log('------------');
                        // console.log("correctQueue: ", correctQueue);
                        const medicCreepName = `${room}_duoMedic_${i}`
                        // console.log("medicCreepName: ", medicCreepName);
                        const medicCreep = Game.creeps[medicCreepName]
                        // console.log("medicCreep: ", medicCreep);
                        if (!medicCreep) {
                            const dismandlerCreepName = `${room}_duoDismandler_${i}`
                            // console.log("dismandlerCreepName: ", dismandlerCreepName);
                            const dismandlerCreep = Game.creeps[dismandlerCreepName]
                            // console.log("dismandlerCreep: ", dismandlerCreep);
                            if (!dismandlerCreep) {
                                correctQueue = false
                            } 
                            // console.log("correctQueue: ", correctQueue);
                        }
                    }
                } 
                else if (role == "duoAttacker") { // проверка на бусты и bucket
                    const terminal = Game.rooms[room].terminal
                    const boostInStock = 
                        terminal.store["XGHO2"] > 900 &&
                        terminal.store["XKH2O"] > 120 &&
                        terminal.store["ZHO2"] > 720 &&
                        terminal.store["XLHO2"] > 660 &&
                        terminal.store["XKHO2"] > 600
                    // Memory.constants.creepBoosts[]
                    if (Game.cpu.bucket < 3000 && boostInStock) {
                        correctQueue = false
                    }
                } 
                else if (role == "duoDismandler") { // проверка на бусты и bucket
                    const terminal = Game.rooms[room].terminal
                    const boostInStock = 
                        terminal.store["XGHO2"] > 900 &&
                        terminal.store["XKH2O"] > 120 &&
                        terminal.store["ZHO2"] > 720 &&
                        terminal.store["XLHO2"] > 660 &&
                        terminal.store["XZHO2"] > 600
                    // Memory.constants.creepBoosts[]
                    if (Game.cpu.bucket < 3000 && boostInStock) {
                        correctQueue = false
                    }
                }
                
            }
            
            if (Memory.constants.roomMaxCreeps[room][spawnLevel][role] > screepsCounts[role] && correctQueue) {
            //сделать проверку если крип уже печатается. они не учитываются screepsCounts[role] + сколько печатаются
                let foundsInSpawns = 0
                let foundSpawningSpawns = 0
                
                const spawnsMem = Memory.gl_var.myRooms[room].structures.spawn
                let spawnsNow = []
                if (spawnsMem) {
                    for (spawn of spawnsMem) { // проходим по спавнам
                        const spawnNow = Game.getObjectById(spawn.id)
                        spawnsNow.push(spawnNow)
                        if (spawnNow.spawning) { //если где-то спавнится
                            foundSpawningSpawns++
                            const spawningRole = spawnNow.spawning.name.split("_")[1]
                            if (spawningRole == role) { //если нашли что уже спавнится, то добавить к существующим
                                foundsInSpawns++
                            }
                        }
                    }
                
                    //если в спавнах спавнится недостаточно таких и остались спавны, то спавнить еще
                    if (spawnsMem.length > foundSpawningSpawns && Memory.constants.roomMaxCreeps[room][spawnLevel][role] > screepsCounts[role] + foundsInSpawns) {
                        population.spawnCreep(room, role, spawnsNow)
                        // if (room == "W49N34") { 
                        //     console.log("spawn", role);
                        // }
                        break; //остановка на первом же нужном крипе
                    }
                }
                
            }
        }
    }
    
    //очистка лишней инфы по частям тела крипов лоу лвл (2-3 кб) не эффективно
    if (Memory.gl_var.gl_i == 1) {
        for (let body in Memory.constants.creepBody) {
            for (let lvl in Memory.constants.creepBody[body]) {
                if (lvl < minSpawnLevel) {
                    delete Memory.constants.creepBody[body][lvl]
                }
            }
        }
    }
    
    
    // const cpu1 = Game.cpu.getUsed()
    
    visualization.roomLevels()
    
    // console.log("Memory: ", (Game.cpu.getUsed() - cpu1).toFixed(2));
    // const test123 = Game.market.getAllOrders(order => //5
    //     order.resourceType == "energy" &&
    //     order.type == ORDER_BUY &&
    //     order.remainingAmount >= 20000)
    // const test123 = Game.market.getAllOrders({type: ORDER_BUY, resourceType: "energy"  })
    

    //показ сколько турели жрут    
    // if (Game.time % 8 == 0) {
    //     if (Game.cpu.bucket > 8500) {
    //         console.log('--turrets--');
    //     } else if (Game.time % 16 == 0) {
    //         console.log('--turrets--');
    //     }
    // }
    // console.log( Game.cpu.getUsed().toFixed(2));
    
    
    
    // if (Game.cpu.bucket == 10000 && Game.cpu.getUsed() < 16 && Memory.gl_var.gl_i > 3 && Memory.gl_var.gl_i <= 30) {
    //     Game.cpu.generatePixel() 
    // }
    // if (Game.time === 31514320) {
    //     Memory.gl_var.gl_i = 190
    // }
    
}


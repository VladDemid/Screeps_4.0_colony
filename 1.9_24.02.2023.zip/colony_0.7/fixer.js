let target_fix;

var roleFixer = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --roleFixer logic start--
        creep.say("🕋");
        
        const myStorage = creep.room.storage
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        let targetToFix = null
        needRescan = false
        if (creep.memory.targetId) {
            targetToFix = Game.getObjectById(creep.memory.targetId);
        }
        
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            let needToBoost = false
            // for (let pCreepRoom in Memory.constants.powerRooms) {
            //     if (Memory.constants.powerRooms[pCreepRoom] == creep.memory.startRoom && Game.powerCreeps[pCreepRoom].ticksToLive) {
            //         needToBoost = true
            //     }
            // }
            if (Game.rooms[creep.memory.startRoom].controller.level == 8 ) {
                needToBoost = true
            }
            creep.memory.needToBoost = needToBoost
        }
        
        if (creep.memory.needToBoost) {
            creepFuncs.boostCreep(creep, boostLab)
        }
        
        const creepIndex = creep.name.split('_')[2] - 1
        
        
        if (creep.memory.rescanCooldown && creep.memory.rescanCooldown > 0) {
            creep.memory.rescanCooldown--
        } else {
            creep.memory.rescanCooldown = 0
        }
        
        // creep.drop(Object.keys(creep.store)[0])
        const targetMaxHits = Memory.constants.wallsHitsMin[Memory.gl_var.myRooms[creep.memory.startRoom].spawnLevel]
        if (targetToFix) {
            if ( targetToFix.hits > targetMaxHits * 1.5 || targetToFix.hits > targetMaxHits + 500000  ) {  
                needRescan = true //значит эту цель починил и надо искать новую
            }
        }
        
        
        if (creep.ticksToLive == 1499 || Game.time % (250 + (creepIndex * 50)) == 0 || !creep.memory.targetId || needRescan || !targetToFix) {
            if (creep.memory.rescanCooldown == 0) {
                creep.memory.repairLevel = Memory.gl_var.myRooms[creep.memory.startRoom].spawnLevel
                
                
                // ближние
                const allWallsRamps = creep.room.find(FIND_STRUCTURES, {filter: (o) => 
                                        o.structureType == "constructedWall"
                                    || o.structureType == "rampart"
                });
                const lowestWallRamp = _.min(allWallsRamps, 'hits')
                
                if (lowestWallRamp.hits < targetMaxHits * 0.3) { //если лоу объекты есть, то чинить сначала их
                    // console.log(, creep.memory.startRoom);
                    creep.memory.targetId = lowestWallRamp.id 
                } else { //если нет лоу, то чинить ближние
                    const lowWallRamp = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => (i.structureType == "constructedWall" && i.hits <= targetMaxHits * 1.2)
                                    || (i.structureType == "rampart" && i.hits <= targetMaxHits * 1.2)
                    });
                    // lowWallsRamps.sort((a,b) => a.hits - b.hits);
                    if (lowWallRamp) {
                        creep.memory.targetId = lowWallRamp.id 
                    } else {
                        //сбросить активную цель ради починки storage (можно проверять, если апгрейднут, то не надо сбрасывать)
                        creep.memory.targetId = null 
                    }
                }
                
                creep.memory.rescanCooldown = 20
            }
        }
        
        //вместе с ресканом идет куда-то в сторону storage
        
        if (!creep.memory.full && creep.memory.needToBoost == false) {
            if (creep.ticksToLive > 60) {
                if (myStorage && myStorage.store["energy"] > Memory.constants.energyThresholds.energyReserveForSpawning) {
                    if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(myStorage)) {
                            creep.moveTo(myStorage, {reusePath: 12});
                        }
                    } 
                }
            } else {
                creep.suicide()
            }
        } else if (creep.memory.full && creep.memory.needToBoost == false) {
            if (creep.memory.targetId && targetToFix && targetToFix.hits < targetToFix.hitsMax && targetToFix.hits < targetMaxHits * 1.5) {
                if (creep.repair(targetToFix) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(targetToFix, {reusePath: 12});
                }
            } else {
                let storageRamp = null
                if (Memory.gl_var.myRooms[creep.memory.startRoom].strgRmpId) {
                    storageRamp = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].strgRmpId.id)
                }
                
                if (storageRamp && storageRamp.hits < (targetMaxHits * 2) + 1000000 ) {
                    if (creep.repair(storageRamp) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(storageRamp, {reusePath: 12});
                    }
                } else {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage, {reusePath: 8});
                    } 
                }
            }
            
            if (creep.ticksToLive == 1 && creep.pos.isNearTo(myStorage)) {
                creep.transfer(myStorage, RESOURCE_ENERGY)
            }
        }
        
        // --roleFixer logic end--
        
    }
};

module.exports = roleFixer;
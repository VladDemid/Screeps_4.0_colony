
var roleHelper = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --helper logic start--
        const myStorage = creep.room.storage
        const spawns = roomsStructures[creep.memory.startRoom]["spawn"]
        const spawn0 = Game.getObjectById(spawns[0].id) 
        const extensions = roomsStructures[creep.memory.startRoom]["extension"]
        // const extensions = Memory.gl_var.myRooms[creep.memory.startRoom].structures["extension"]
        // не сортируются через память
        const extension0 = Game.getObjectById(extensions[0].id)
        const towers = Memory.gl_var.myRooms[creep.memory.startRoom].structures["tower"]
        let tower0 = null
        if (towers && towers.length) {
            tower0 = Game.getObjectById(towers[0].id)
        }
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        
        // if (creep.name == "W49N34_helper_1") {
        //     console.log(towers.length);
        // }
        
        creep.say("🧰");
        if (creep.store["energy"] < 50) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        
        if (creep.ticksToLive == 1500) {
            creep.memory.foundMyTomb = 0;
        } else if (creep.ticksToLive == 1499) {
            myPowerCreep = creep.pos.findInRange(FIND_POWER_CREEPS, 25)[0];
            if (myPowerCreep) {
                creep.memory.myPowerCreepId = myPowerCreep.id
            }
            myTomb = creep.pos.findInRange(FIND_TOMBSTONES, 6, {
                filter: (item) => item.store["energy"] >= creep.store.getCapacity()*0.3   
            })[0];
            if (myTomb) {
                creep.memory.foundMyTomb = 1;
                creep.memory.myTombId = myTomb.id;
            }
        } else if (creep.ticksToLive == 1489) {
            delete creep.memory.foundMyTomb
            delete creep.memory.myTombId
        }
        // console.log(sources[0].pos);
        if (!creep.memory.full) {
            if (creep.ticksToLive >= 1490 && creep.memory.foundMyTomb && creep.store["energy"] == 0 && creep.memory.myTombId) {
                const tomb = Game.getObjectById(creep.memory.myTombId);
                if(creep.withdraw(tomb, "energy") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb);
                }
            } else if (myStorage && myStorage.store["energy"] > 0) {
                if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage, {reusePath: 15});
                    }
                }
            }
            
        } else if (creep.memory.full) {
            // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
            if (spawn0.store["energy"] < 300) {
                if(creep.transfer(spawn0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(spawn0, {reusePath: 10});
                }
            } else if (extension0 && extension0.store.getFreeCapacity("energy") > 0) {
                let myPowerCreep = null
                if (creep.memory.myPowerCreepId) {
                    myPowerCreep = Game.getObjectById(creep.memory.myPowerCreepId)
                }
                if (!myPowerCreep) {
                    
                    // let transferThisTick = false
                    // let moveThisTick = false
                    let actionThisTick = false
                    // const lowExt0 = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                    //         filter: (i) => (i.structureType == STRUCTURE_EXTENSION 
                    //                      && i.energy < i.energyCapacity)
                    //     })[0];
                    // if (lowExt0) { //если по пути нашелся другой пустой, то заполнить его
                    //     creep.transfer(lowExt0, RESOURCE_ENERGY); 
                    //     creep.moveTo(extension0, {reusePath: 10, maxOps: 200}); //move к самому незаполненному (потому что можно)
                    // } 
                    const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1, {filter: {structureType: STRUCTURE_EXTENSION}}); //найти все структуры рядом
                    if  (range_1_str) { //проходиться по каждому и искать
                        for (var y = 0; y < range_1_str.length;y++) {
                            //range_1_str[y].structureType == STRUCTURE_EXTENSION &&
                            if ( range_1_str[y].energy < range_1_str[y].energyCapacity) {
                                let iWillEmpty = false
                                //если после наполнения не останется энергии, то домой
                                if (range_1_str[y].store.getFreeCapacity("energy") + 49 >= creep.store["energy"]) {
                                    iWillEmpty = true
                                }
                                creep.transfer(range_1_str[y], RESOURCE_ENERGY); //заполнять рандомный ext рядом
                                if (!iWillEmpty) {
                                    if (!creep.pos.isNearTo(extension0)) { //если не рядом, то идти
                                        creep.moveTo(extension0, {reusePath: 10, maxOps: 200});
                                    }
                                    // creep.moveTo(extension0, {reusePath: 10, maxOps: 200}); //move к самому незаполненному (потому что можно)
                                } else {
                                    creep.moveTo(myStorage, {reusePath: 15, maxOps: 200}); 
                                }
                                actionThisTick = true
                                break;
                            }
                        }
                    } else if(creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(extension0, {reusePath: 10, maxOps: 200});
                    }
                    //если вокруг есть ext, но они все полны тогда это
                    if(!actionThisTick && creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) { 
                        creep.moveTo(extension0, {reusePath: 10, maxOps: 200});
                    }
                } else {
                    if (boostLab && boostLab.store["energy"] < 500) {
                        if(creep.transfer(boostLab, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(boostLab, {reusePath: 15});
                        }
                    }
                }
            } else if (towers && towers.length > 0 && tower0 && tower0.store["energy"] < 700) {
                if(creep.transfer(tower0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower0, {reusePath: 15});
                }
            } else if (creep.store.getFreeCapacity() > 0) {
                creep.memory.full = false;
            } else {
                if (!creep.pos.isNearTo(spawn0)) {
                    creep.moveTo(spawn0, {reusePath: 10});
                }
            }
            
            
        } 
        // --helper logic end--
    }
};

module.exports = roleHelper;
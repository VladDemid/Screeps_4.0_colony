funcs = require("funcs");

var roleDuoAttacker = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myActionName = creep.name.split("_")[1]
        const myNumber = creep.name.split("_")[2]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        let targetPos = null
        let targetRoom = null 
        const myHealerCreepName = creep.name.replace("Attacker", "Healer")
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            creep.memory.needBoost = false //если флага нет, то ничего не делать
        }
        
        let myHealerCreep = null
        if (creep.memory.myHealerCreepId) {
            myHealerCreep = Game.getObjectById(creep.memory.myHealerCreepId)
        } else {
            myHealerCreep = Game.creeps[myHealerCreepName]
        }
        
        if (!creep.memory.myHealerCreepId && myHealerCreep) {
            creep.memory.myHealerCreepId = myHealerCreep.id
        }
        
        // creep.memory.needBoost = false
        if (creep.memory.needBoost == undefined || creep.memory.needBoost === true) {
            creepFuncs.boostCreepMass(creep)
        } else {
            if (Game.cpu.bucket > 1000) {
                if (creep.memory.targetRoomMem && creep.pos.roomName != creep.memory.targetRoomMem) {
                    const isAtTheEdges = creepFuncs.isAtTheVeryEdges(creep)
                    if (isAtTheEdges || myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) {
                        creepFuncs.myRoutes(creep, creep.memory.targetRoomMem)
                        // creepFuncs.goCorridors(creep, creep.memory.targetRoomMem)
                        creep.say("🥾💤");
                    }
                } else {
                    // creep.say("💤");
                    let targetsIds = ["63f4d7a2510b6968f8728d28","63f24acebc2f4b65ed025ffb","63f2de7835b1cc4de86b0ef1","63f38db44667742fc28ef612", "63f262db221538cefa2fba82","63f2558395671c4907a823bb", "63ec1bb195671c2cc5a6947f"] //W32N45
                    
                    
                    // if (creep.memory.startRoom === "W49N43") {
                    //     targetsIds = ["6225d3ef4cff2f574430793e","627f13171a02854b67eeb3d0","6281f963d9142a518ff01f47", "627681889edb183975f00249", "627f41ac78227075badd96a3", "627798eedd2d661170cac9e4"]
                    // } else if (creep.memory.startRoom === "W47N45" ) {
                    //     if (myNumber <= 2) {
                    //         targetsIds = ["627690a123625d4651d3cf98","622951b9367b9f04d60185e6", "6220e28c093566b0327ccf9a", "623f5a5c76cf3aaa0ef6b6d2"]
                    //     } else {
                    //         targetsIds = ["62794311bf05bad551299e79","629a2dfda7c973ed09277dab","62295b755a44eb942847ee7d", "629a0a3e7be6284799838b82", "6275b64611aa5eb33732701e"]
                    //     }
                    // } else if (creep.memory.startRoom === "W48N47") {
                    //     targetsIds = ["627684700c3de0711b2063d0","627690a123625d4651d3cf98","62767dd83d6bfc1191c4a12b", "6281f963d9142a518ff01f47", "627681889edb183975f00249"]
                    // }
                    let enemy_low_ramparts_near;
                    enemy_low_ramparts_near = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 3, {
                        filter: (i) => (i.structureType == "rampart" 
                                     && i.hits < 3000000)
                    });
                    
                    let currentTarget = null
                    for (let targetId of targetsIds) {
                        const target = Game.getObjectById(targetId)
                        if (target) {
                            currentTarget = target
                            break;
                        }
                    }
                    
                    if (!currentTarget && enemy_low_ramparts_near.length) {
                        currentTarget = enemy_low_ramparts_near[0]
                    }
                    
                    // if (founded_str1) { currentTarget = founded_str1 }
                    // if (founded_str2) { currentTarget = founded_str2 }
                    // if (creep.name == "W47N45_duoAttacker_2") {
                    //     console.log(targetsIds);  
                    // }
                    
                    let retreatMode = false
                    const healthGood =  creep.hits > creep.hitsMax * 0.95
                    if (!healthGood) {
                        retreatMode = true
                    } else if (healthGood && Game.time % 6 === 0) {
                        retreatMode = false
                    }
                    
                    
                    // const target_by_id = Game.getObjectById("628c70ea0a952e1fdbe592cc")
                    let needRangedMassAttack = false
                    const enemy_creep_nearest = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                    const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
                    // const construction_site_near = creep.pos.findInRange(FIND_CONSTRUCTION_SITES, 3)[0];
                    const enemy_build_near = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 3)
                    const enemy_build_nearest = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES)
                    const enemy_extension_near = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                        filter: (i) => i.structureType == "extension" 
                    });
                    
                    if (enemy_creeps_near[0] || enemy_build_near[0]) {
                        needRangedMassAttack = true
                    }
                    if ( (myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1))  || creepFuncs.isAtTheVeryEdges(creep)) {
                        if (!retreatMode) {
                            // if (construction_site_near) {
                            //     creep.moveTo(construction_site_near)
                            // } else
                            if (currentTarget) {
                                if (creep.pos.inRangeTo(currentTarget, 1)) {
                                    needRangedMassAttack = true
                                } else if (myHealerCreep.fatigue === 0) {
                                    creep.moveTo(currentTarget)
                                }
                                // if (currentTarget.id === '63ed6b8211eed938310806cc') {
                                //     if (!creep.pos.isEqualTo(37, 31)) {
                                //         creep.moveTo(37, 37);
                                //     } else {
                                //         creep.dismantle(currentTarget)
                                //     }
                                // } else
                                // if(creep.dismantle(currentTarget) == ERR_NOT_IN_RANGE) {
                                //     creep.moveTo(currentTarget);
                                // }
                            } 
                            // else if (enemy_build_nearest) { 
                            //     if(creep.dismantle(enemy_build_nearest) == ERR_NOT_IN_RANGE) {
                            //         creep.moveTo(enemy_build_nearest);
                            //     }
                            // } 
                            // else if (true) {
                            //     creep.moveTo(22,19)
                            // }
                            // else 
                            else if (enemy_extension_near) {
                                if (creep.pos.inRangeTo(enemy_extension_near, 1)) {
                                    needRangedMassAttack = true
                                } else if (myHealerCreep.fatigue === 0) {
                                    creep.moveTo(enemy_extension_near)
                                }
                            } 
                            else if (enemy_creep_nearest && enemy_creep_nearest.pos.inRangeTo(25, 25, 22)) {
                                // if (creep.pos.inRangeTo(enemy_creep_nearest, 1)) {
                                //     needRangedMassAttack = true
                                // } else if (myHealerCreep.fatigue === 0) {
                                //     creep.moveTo(enemy_creep_nearest, {reusePath: 5, swampCost: 5})
                                // }
                                if (creep.pos.getRangeTo(enemy_creep_nearest) > 1 && myHealerCreep.fatigue == 0) {
                                    creep.moveTo(enemy_creep_nearest)
                                }
                            } 
                            else {
                                // if (targetPos && !creep.pos.inRangeTo(targetPos, 1)) {
                                //     creep.moveTo(targetPos);
                                // } else 
                                if (!creep.pos.inRangeTo(25, 25, 10)) {
                                    creep.moveTo(25, 25);
                                }
                            }
                        } else if ( !myHealerCreep || (myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) || retreatMode) {
                            // if (targetPos && targetPos.x) {
                            //     if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 1)) {
                            //         creep.moveTo(targetPos.x, targetPos.y, {reusePath: 5, swampCost: 1});
                            //     }
                            // } else {
                                if (!creep.pos.inRangeTo(25, 25, 10) && myHealerCreep.fatigue == 0) {
                                    creep.moveTo(25, 25, {reusePath: 5, swampCost: 1});
                                    
                                    
                                }
                            // }
                        }
                        
                    }
                    if (creep.fatigue === 0 && myHealerCreep.fatigue > 0 && creep.pos.getRangeTo(myHealerCreep) > 1) {
                        creep.moveTo(myHealerCreep)
                    }
                    
                    if (needRangedMassAttack) {
                        creep.rangedMassAttack();
                    }
                    
                    
                }
            }
        }
        
        
            
        
        
    }
};

module.exports = roleDuoAttacker;
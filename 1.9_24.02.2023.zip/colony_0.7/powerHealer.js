
var rolePowerHealer = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --powerHealer logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4].myActionName = 0
        }
        
        
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            creep.memory.needToBoost = true
        }
        
        if (creep.memory.needToBoost) {
            creepFuncs.boostCreep(creep, boostLab)
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("💉🥾");
        
        if (creep.memory.needToBoost === false) {
            if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
                creepFuncs.goCorridors(creep, targetRoomMem)
            } else {
                creep.say("💉");
                if (creep.hits < creep.hitsMax) {
                    creep.heal(creep)
                } else {
                    if (!creep.memory.myAttackerId) {
                        const creepNumber = creep.name.split('_')[2]
                        const myAttackerName = `${creep.memory.startRoom}_powerAttacker_${creepNumber}`
                        const myCreep = Game.creeps[myAttackerName]
                        if (myCreep) {
                            creep.memory.myAttackerId = myCreep.id
                        }
                    }
                    
                    if (Memory.obsInfo[creep.memory.startRoom].status != 'idle') {
                        if (creep.memory.myAttackerId && Memory.obsInfo[creep.memory.startRoom].status != 'idle') {
                            const myAttacker = Game.getObjectById(creep.memory.myAttackerId)
                            if (myAttacker) {
                                if (!creep.pos.isNearTo(myAttacker)) {
                                    creep.moveTo(myAttacker);
                                } else {
                                    let nearPower = false
                                    if (Game.time % 3 == 0 && Memory.obsInfo[creep.memory.startRoom].freeSpots == 3) { //иногда проверять рядом ли с powerBank
                                        const powerBankNear = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 1, {
                                            filter: (i) => i.structureType == "powerBank" 
                                        })[0];
                                        if (powerBankNear) {
                                            nearPower = true
                                            console.log(powerBankNear, !!powerBankNear);
                                        }
                                    }
                                    if (nearPower) { //отходить от powerBank
                                        creep.moveTo(25, 25)
                                    } else {
                                        if (myAttacker.hits < myAttacker.hitsMax) {
                                            creep.heal(myAttacker)
                                        }
                                    }
                                }
                            } else if (Memory.obsInfo[creep.memory.startRoom].status == 'idle') {
                                creep.suicide()
                            }
                        } else {
                            if (!creep.pos.inRangeTo(25, 25, 3)) {
                                creep.moveTo(25, 25, {reusePath: 10});
                            }
                        }
                    } else if (Memory.obsInfo[creep.memory.startRoom].status == 'idle') {
                        const myAttacker = Game.getObjectById(creep.memory.myAttackerId)
                        if (!creep.pos.inRangeTo(25, 25, 3)) {
                            creep.moveTo(25, 25);
                        }
                        if (!myAttacker) {
                            creep.suicide()
                        }
                    }
                    
                }
            }
        }
        // --powerHealer logic end--
        
    }
};

module.exports = rolePowerHealer;
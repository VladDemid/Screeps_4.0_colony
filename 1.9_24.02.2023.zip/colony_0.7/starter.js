// creepFuncs = require("creepFuncs")

var roleStarter = {
    run: function(creep, roomsStructures, creepFuncs) {
        
        // function isOdd(num) { return num % 2;}
        // --starter logic start--
        const myStorage = creep.room.storage
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        const containers = Memory.gl_var.myRooms[creep.room.name]["containers"]
        
        let containersSorted = null
        if (Memory.gl_var.myRooms[creep.room.name].containersSorted) {
            containersSorted = Memory.gl_var.myRooms[creep.room.name].containersSorted
        }
        
        const spawns = roomsStructures[creep.memory.startRoom]["spawn"]
        const spawn0 = Game.getObjectById(spawns[0].id) 
        const extensions = roomsStructures[creep.memory.startRoom]["extension"]
        let extension0 = null
        if (extensions && extensions.length) {
            extension0 = Game.getObjectById(extensions[0].id)
        }
        const constructionsSite = roomsStructures[creep.memory.startRoom]["constructionsSites"] // [0]
        const towers = Memory.gl_var.myRooms[creep.memory.startRoom].structures["tower"]
        let tower0 = null
        if (towers && towers.length) {
            tower0 = Game.getObjectById(towers[0].id)
        }
        // const construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)
        // if (roomsStructures[creep.memory.startRoom]["constructionsSites"]) {
        //     const constructionsSites0id = Game.getObjectById(roomsStructures[creep.memory.startRoom]["constructionsSites"].id) 
        // //тут возможно была ошибка
        // }
        
        const ticksToSaveController = 2000
        const rebootTicks = 30
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest_mining = creepFuncs.isOdd(creepIndex)
        
        // let dest_container = null
        // if (containers && containers.length == 2) {
        //     dest_container = Game.getObjectById(containers[dest_mining].id)
        // }
        
        creep.say("⛽️");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        
        if (!creep.memory.full) {
            
            // const drop = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES, {
            //     filter: (i) => i.resourceType == "energy" && 
            //                   i.amount > 100 
            // });
            
            // if (drop) {
            //     if(creep.pickup(drop, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
            //         if (!creep.pos.isNearTo(drop)) {
            //             creep.moveTo(drop);
            //         }
            //     }
            // } else 
            if (myStorage && myStorage.store["energy"] > 300) {
                if (myStorage.store["energy"] > creep.store.getCapacity()) {
                    if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                        creep.moveTo(myStorage, {reusePath: 10});
                    }
                } else {
                    if (!creep.pos.inRangeTo(myStorage, 2)) {
                        creep.moveTo(myStorage);
                    }
                }
            } else if ( Object.keys(containers).length == 2 && (Game.creeps[`${creep.room.name}_miner_1`] || Game.creeps[`${creep.room.name}_miner_2`])) {
                
                let dest_container = null
                if (containers && containers.length == 2) {
                    dest_container = Game.getObjectById(containers[dest_mining].id)
                }
                
                //крипы идут ко одному и тому же контейнеру (Вроде починил)
                if (containersSorted.length && containersSorted.length == 2) {
                    if (!creep.memory.destContainerId || Game.time % (100 + 20 * creepIndex) == 0) {
                        if (containersSorted[dest_mining]) {
                            creep.memory.destContainerId = containersSorted[dest_mining].id //!!!!!!
                        }
                    }
                }
                
                const constainerFromMem = Game.getObjectById(creep.memory.destContainerId)
                
                
                //тут поменял все constainerFromMem на dest_container
                if (constainerFromMem && constainerFromMem.store["energy"] > 0) { 
                    if (creep.withdraw(constainerFromMem, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(constainerFromMem)) {
                            creep.moveTo(constainerFromMem, {reusePath: 10});
                        }
                    }
                } else if (constainerFromMem) {
                    if (!creep.pos.inRangeTo(constainerFromMem, 3)) {
                        creep.moveTo(constainerFromMem);
                    }
                }
                // if (dest_container && dest_container.store["energy"] > 0) { 
                //     if (creep.withdraw(dest_container, "energy") == ERR_NOT_IN_RANGE) {
                //         if (!creep.pos.isNearTo(dest_container)) {
                //             creep.moveTo(dest_container, {reusePath: 10});
                //         }
                //     }
                // }
                
                //доставать из source
            } else if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[dest_mining]);
            }
        } else if (creep.memory.full) {
            // console.log(spawns[0].store["energy"], creep.name);
            if (creep.room.controller.ticksToDowngrade < ticksToSaveController) {
                if (creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(creep.room.controller, {reusePath: 10});
                }
            } else if (extension0 && extension0.store.getFreeCapacity("energy") > 0) {
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extension0, {reusePath: 10}); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extension0);
                }
                if(creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extension0);
                }
            } else if (spawn0.store["energy"] < 300) {
                if(creep.transfer(spawn0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(spawn0, {reusePath: 10});
                }
            } else if (towers && towers.length > 0 && tower0.store["energy"] < 800) {
                if(creep.transfer(tower0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower0, {reusePath: 10});
                }
            } else if (constructionsSite) {
                if(creep.build(constructionsSite) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(constructionsSite);
                }
            } else if (creep.room.controller) {
                if (creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(creep.room.controller, {reusePath: 10});
                }
            }
            
        }
        
        
        // --starter logic end--
        
    }
};

module.exports = roleStarter;
var dest_mining,
    mining_parts;

var roleMiner = {
//my_spawns, sources, link_to, link_from, laborant_max
    run: function(creep, roomsStructures, creepFuncs) {
        // --starter logic start--
        function isOdd(num) { return num % 2;}
        
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            let needToBoost = false
            for (let pCreepRoom in Memory.constants.powerRooms) {
                if (Memory.constants.powerRooms[pCreepRoom] == creep.memory.startRoom && Game.powerCreeps[pCreepRoom].ticksToLive && Game.rooms[creep.memory.startRoom].controller.level == 8 ) {
                    needToBoost = true
                    break;
                }
                // console.log(Memory.constants.powerRooms[pCreepRoom] == creep.memory.startRoom);
            }
            creep.memory.needToBoost = needToBoost
        }
        
        if (creep.memory.needToBoost) {
            creepFuncs.boostCreep(creep, boostLab)
        }
        
        
        
        creep.say("⛏");
        
        if (!creep.memory.fullMax || creep.ticksToLive == 1450) { 
            let oneMine = 2
            if (creep.memory.boosted) {
                oneMine = 6
            }
            mining_parts = creep.getActiveBodyparts(WORK);
            creep.memory.fullMax = creep.store.getCapacity() - (mining_parts*oneMine) + 1
        }
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] >= creep.memory.fullMax || creep.ticksToLive == 1) {
            creep.memory.full = true;
        } 
        
        
        // dest_mining = creep.name.split('Miner')[1] - 1;
        creepIndex = creep.name.split('_')[2] - 1
        const dest_mining = isOdd(creepIndex)
        
        if (!creep.memory.mySourceId) {
            creep.memory.mySourceId = sources[dest_mining].id
        }        
        const mySource = Game.getObjectById(creep.memory.mySourceId)
        
        //проверка после выкапывания последнего возможного source чтобы новый miner успел возродиться и дойти до source
        if ( creep.ticksToLive <= 120 && mySource.energy == 0 && mySource.ticksToRegeneration > creep.ticksToLive ) {
            if (creep.store["energy"] > 0) {
                creep.memory.full = true
            } else {
                creep.suicide()
            }
        }
        // creep.drop('energy')
        if (!creep.memory.full && creep.memory.needToBoost == false) {
            if (Game.cpu.bucket > 1000) { //на всякий случай
                if (creep.harvest(mySource) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(mySource);
                } else if (!creep.pos.isNearTo(mySource)) { //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    creep.moveTo(mySource, {reusePath: 15});
                }
            }
        } else if (creep.memory.full) {
            
            //один раз за жизнь искать линк
            if (!creep.memory.myLinkId) {
                const myLink = creep.pos.findInRange(FIND_MY_STRUCTURES, 1, {filter: {structureType: STRUCTURE_LINK}})[0]
                if (creep.name == "W49N34_miner_1") {
                    // console.log(myLink);
                }
                if (myLink) {
                    creep.memory.myLinkId = myLink.id
                } else {
                    creep.memory.myLinkId = null //возможна ошибка
                }
            }
            
            // if (creep.name == "W49N34_miner_1") {
            //     creep.repair(Game.getObjectById('60cad343beaaeb595ec8cc16'))
            // } else {
            if (creep.memory.myLinkId && Memory.gl_var.myRooms[creep.room.name].spawnLevel >= 6 ) {
                
                const myLink = Game.getObjectById(creep.memory.myLinkId)
                if (myLink && myLink.store["energy"] < 800) {
                    creep.transfer(myLink, "energy");
                }
            } else {
                const near_container = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                    filter: (i) => i.structureType == STRUCTURE_CONTAINER &&
                                   i.store[RESOURCE_ENERGY] < 2000
                })[0];
                // console.log(near_container.pos);
                const building = creep.pos.findInRange(FIND_CONSTRUCTION_SITES, 1)[0];
                if (near_container) {
                    if (near_container.store["energy"] < 2000) {
                        creep.transfer(near_container, "energy");
                    } else if (near_container.hits < near_container.hitsMax) {
                        creep.repair(near_container)
                    }
                } else if (building) {
                    creep.build(building);
                } 
            }
            
                
            
            
        }
        
        // --starter logic end--
        
    }
};

module.exports = roleMiner;
funcs = require("funcs");

var roleDuoDismandler = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myActionName = creep.name.split("_")[1]
        const myNumber = creep.name.split("_")[2]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        let targetPos = null
        let targetRoom = null 
        // const myHealerCreepName = creep.name.replace("Attacker", "Healer")
        const myHealerCreepName = creep.name.replace("Dismandler", "Medic")
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            creep.memory.needBoost = false //если флага нет, то ничего не делать
        }
        
        const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
        
        let needRangedMassAttack = false
        if (enemy_creeps_near[0]) {
            needRangedMassAttack = true
        }
        
        let myHealerCreep = null
        if (creep.memory.myHealerCreepId) {
            myHealerCreep = Game.getObjectById(creep.memory.myHealerCreepId)
        } else {
            myHealerCreep = Game.creeps[myHealerCreepName]
        }
        
        if (!creep.memory.myHealerCreepId && myHealerCreep) {
            creep.memory.myHealerCreepId = myHealerCreep.id
        }
        
        // creep.memory.needBoost = false
        if (creep.memory.needBoost == undefined || creep.memory.needBoost === true) {
            creepFuncs.boostCreepMass(creep)
        } else {
            if (Game.cpu.bucket > 1000) {
                if (creep.memory.targetRoomMem && creep.pos.roomName != creep.memory.targetRoomMem) {
                    const isAtTheEdges = creepFuncs.isAtTheVeryEdges(creep)
                    if (isAtTheEdges || myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) {
                        creepFuncs.myRoutes(creep, creep.memory.targetRoomMem)
                        // creepFuncs.goCorridors(creep, creep.memory.targetRoomMem)
                        creep.say("🥾💤");
                    }
                } else {
                    // creep.say("💤");
                    let targetsIds = ['63f5af69abbaf9c3465fed1a']
                    if (creep.memory.startRoom == 'W41N39') {
                        targetsIds = ["63eab66176cf62248962f6d9"] 
                    } else if (creep.memory.startRoom == 'W38N41') {
                        targetsIds = ["63f8424acb01e4f2cb83408c", "63f8021ecd98a86485caeadb", "63f881f0f0dd456ce8c873ce", "63f881f9f39ee12ab498aa19", "63f881f9f39ee12ab498aa19"] 
                    }
                    
                    
                    // if (creep.memory.startRoom === "W49N43") {
                    //     targetsIds = ["6225d3ef4cff2f574430793e","627f13171a02854b67eeb3d0","6281f963d9142a518ff01f47", "627681889edb183975f00249", "627f41ac78227075badd96a3", "627798eedd2d661170cac9e4"]
                    // } else if (creep.memory.startRoom === "W47N45" ) {
                    //     if (myNumber <= 2) {
                    //         targetsIds = ["627690a123625d4651d3cf98","622951b9367b9f04d60185e6", "6220e28c093566b0327ccf9a", "623f5a5c76cf3aaa0ef6b6d2"]
                    //     } else {
                    //         targetsIds = ["62794311bf05bad551299e79","629a2dfda7c973ed09277dab","62295b755a44eb942847ee7d", "629a0a3e7be6284799838b82", "6275b64611aa5eb33732701e"]
                    //     }
                    // } else if (creep.memory.startRoom === "W48N47") {
                    //     targetsIds = ["627684700c3de0711b2063d0","627690a123625d4651d3cf98","62767dd83d6bfc1191c4a12b", "6281f963d9142a518ff01f47", "627681889edb183975f00249"]
                    // }
                    let enemy_low_ramparts_near;
                    enemy_low_ramparts_near = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 3, {
                        filter: (i) => (i.structureType == "rampart" 
                                     && i.hits < 3000000)
                    });
                    
                    let currentTarget = null
                    for (let targetId of targetsIds) {
                        const target = Game.getObjectById(targetId)
                        if (target) {
                            currentTarget = target
                            break;
                        }
                    }
                    
                    // if (!currentTarget && enemy_low_ramparts_near.length) {
                    //     currentTarget = enemy_low_ramparts_near[0]
                    // }
                    
                    // if (founded_str1) { currentTarget = founded_str1 }
                    // if (founded_str2) { currentTarget = founded_str2 }
                    // if (creep.name == "W47N45_duoAttacker_2") {
                    //     console.log(targetsIds);  
                    // }
                    
                    let retreatMode = false
                    const healthGood =  creep.hits > creep.hitsMax * 0.97
                    if (!healthGood) {
                        retreatMode = true
                    } else if (healthGood && Game.time % 6 === 0) {
                        retreatMode = false
                    }
                    
                    
                    // const target_by_id = Game.getObjectById("628c70ea0a952e1fdbe592cc")
                    // let needRangedMassAttack = false
                    // const enemy_creep_nearest = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                    // const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
                    // const construction_site_near = creep.pos.findInRange(FIND_CONSTRUCTION_SITES, 3)[0];
                    const enemy_build_main = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                        filter: (i) => i.structureType == "spawn" 
                                    || i.structureType == "storage" 
                                    || i.structureType == "terminal" 
                    });
                    const enemy_extension_near = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                        filter: (i) => i.structureType == "extension" 
                    });
                    const enemy_build_secondary = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                        filter: (i) => i.structureType == "factory" 
                                    || i.structureType == "tower" 
                                    || i.structureType == "powerBank" 
                                    || i.structureType == "tower" 
                                    || i.structureType == "lab" 
                                    || i.structureType == "link" 
                                    && i.structureType != "rampart" 
                                    && i.structureType != "constructedWall" 
                    });
                    // rampart_wall_near
                    const other_structures = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == "rampart" 
                                    || i.structureType == "constructedWall" 
                                    || i.structureType == "road" 
                                    && i.hits 
                    });
                    // const all_str_nearest = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    //     filter: (i) => i.structureType != "road" 
                    //                 && i.structureType != "controller" 
                    // });
                    const container = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                        filter: (i) => i.structureType == "container" 
                    });
                    const construction_site_near = creep.pos.findClosestByRange(FIND_HOSTILE_CONSTRUCTION_SITES);
                    let centralRoads = null
                    if (construction_site_near) {
                        centralRoads = construction_site_near.pos.findInRange(FIND_STRUCTURES, 5,  {
                            filter: (i) => i.structureType == "road" 
                        });
                    }
                    
                    if ( (myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1))  || creepFuncs.isAtTheVeryEdges(creep)) {
                        if (!retreatMode) {
                            // if (construction_site_near) {
                            //     creep.moveTo(construction_site_near)
                            // } else
                            if (currentTarget) {
                                creep.say("i");
                                // if (creep.pos.inRangeTo(currentTarget, 1)) {
                                //     needRangedMassAttack = true
                                // } else if (myHealerCreep.fatigue === 0) {
                                //     creep.moveTo(currentTarget)
                                // }
                                if (currentTarget.id === '63ed6b8211eed938310806cc') {
                                    if (!creep.pos.isEqualTo(37, 31)) {
                                        creep.moveTo(37, 37);
                                    } else {
                                        creep.dismantle(currentTarget)
                                    }
                                } else
                                if(creep.dismantle(currentTarget) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(currentTarget);
                                }
                            } else
                            if (enemy_extension_near) {
                                creep.say("ex");
                                if(creep.dismantle(enemy_extension_near) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(enemy_extension_near);
                                }
                            } else 
                            if (enemy_build_main) {
                                creep.say("m");
                                if(creep.dismantle(enemy_build_main) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(enemy_build_main);
                                }
                            } else
                            if (enemy_build_secondary) {
                                creep.say("s");
                                if(creep.dismantle(enemy_build_secondary) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(enemy_build_secondary);
                                }
                            } else 
                            if (container) {
                                creep.say("c");
                                if(creep.dismantle(container) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(container);
                                }
                            } else
                            if (centralRoads && centralRoads.length) {
                                creep.say("r");
                                if(creep.dismantle(centralRoads[0]) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(centralRoads[0]);
                                }
                            } else
                            if (other_structures) {
                                creep.say("..");
                                if(creep.dismantle(other_structures) == ERR_NOT_IN_RANGE) {
                                    creep.moveTo(other_structures);
                                }
                            }
                            // else if (enemy_extension_near) {
                            //     if (creep.pos.inRangeTo(enemy_extension_near, 1)) {
                            //         needRangedMassAttack = true
                            //     } else if (myHealerCreep.fatigue === 0) {
                            //         creep.moveTo(enemy_extension_near)
                            //     }
                            // }
                            else {
                                if (targetPos && !creep.pos.inRangeTo(targetPos, 1)) {
                                    creep.moveTo(targetPos);
                                } else if (!creep.pos.inRangeTo(25, 25, 10)) {
                                    creep.moveTo(25, 25);
                                }
                            }
                        } else if ( !myHealerCreep || (myHealerCreep && myHealerCreep.pos.inRangeTo(creep.pos, 1)) || retreatMode) {
                            if (targetPos && targetPos.x) {
                                if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 1)) {
                                    creep.moveTo(targetPos.x, targetPos.y, {reusePath: 5, swampCost: 1});
                                }
                            } else {
                                if (!creep.pos.inRangeTo(25, 25, 10)) {
                                    creep.moveTo(25, 25, {reusePath: 5, swampCost: 1});
                                    
                                    
                                }
                            }
                        }
                        
                    }
                    
                    // if (needRangedMassAttack) {
                    //     creep.rangedMassAttack();
                    // }
                    
                    
                }
            }
        }
        
        
        if (needRangedMassAttack) {
            creep.rangedMassAttack();
        }
        
        
    }
};

module.exports = roleDuoDismandler;
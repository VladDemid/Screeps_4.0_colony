funcs = require("funcs");

var roleAttackerTeam = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --scout logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499 || !targetRoom || !creep.memory.targetRoomMem) {
                // || creep.pos.roomName == creep.memory.startRoom
                creep.memory.targetRoomMem = targetRoom
                creep.memory.teamReady = false
                creep.memory.iAmReady = false
                creep.memory.waitingRoom = null
                
                creep.memory.waitingCount = myFlagAction.flagCount
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4][myActionName] = 0
            //если вышли, но флага уже нет
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("🥾⚔️");
        
        
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            let needToBoost = false
            if (Game.rooms[creep.memory.startRoom].controller.level >= 7 ) {
                needToBoost = true
            }
            creep.memory.needToBoost = needToBoost
        }
        
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        if (creep.memory.needToBoost) {
            creepFuncs.boostCreep(creep, boostLab)
        }
        
        if (creep.memory.needToBoost == false) {
            if (targetRoomMem && creep.pos.roomName != targetRoomMem ) {
                creepFuncs.myRoutesTeam(creep, targetRoomMem)
            } else {
                creep.say("⚔️");
                
                const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 2);
                const enemy_build = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType != "controller" 
                                && i.structureType != "storage" 
                                && i.structureType != "terminal" 
                });
                const enemy_tower = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "tower" 
                                // && i.structureType != "rampart" 
                });
                const enemy_spawn = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "spawn" 
                                // && i.structureType != "rampart" 
                });
                const enemy_container = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    filter: (i) => i.structureType == "container" 
                                // && i.structureType != "rampart" 
                });
                const creepIndex = creep.name.split('_')[2]
                let target_by_id = Game.getObjectById("610acfed93e8c44b4d118ba0")
                
                let targetsIds = ["627fcccba7540587b61ddcca","627fcd0007b1fd90abdba9c4", "627f16dbdda3348d1f7e8e03", "627f1a30a6bb7084345d93f0"]
                let currentTarget = null
                for (let targetId of targetsIds) {
                    const target = Game.getObjectById(targetId)
                    if (target) {
                        currentTarget = target
                        break;
                    }
                }
                // if (creep.name == "W49N43_attackerTeam_13" || creep.name == "W49N43_attackerTeam_12" || creep.name == "W49N43_attackerTeam_9") {
                //     target_by_id = Game.getObjectById("61092912ebacec8c567b531f")
                // } 
                // else {
                //     target_by_id = Game.getObjectById("610987e47ba7156c6949f13d")
                // }
                
                // const walls = creep.pos.findClosestByRange(FIND_STRUCTURES,
                //     {filter: {structureType: STRUCTURE_WALL}});
                const enemy_creeps = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                if (enemy_container) {
                    creep.say("⚔️B");
                    if(creep.attack(enemy_container) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_container)) {
                            creep.moveTo(enemy_container);
                        }
                    } 
                } else
                if (enemy_creeps_near[0]) {
                    creep.say("⚔️C");
                    if(creep.attack(enemy_creeps_near[0]) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_creeps_near[0])) {
                            creep.moveTo(enemy_creeps_near[0]);
                        }
                    }
                } else 
                if (currentTarget) {
                    creep.say("⚔️i");
                    if(creep.attack(currentTarget) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(currentTarget)) {
                            const range = creep.pos.getRangeTo(currentTarget)
                            if (range > 5) {
                                creep.moveTo(currentTarget, {ignoreCreeps: true});
                            } else {
                                creep.moveTo(currentTarget);
                            }
                        }
                    }
                } else 
                if (enemy_tower) {
                    creep.say("⚔️T");
                    if(creep.attack(enemy_tower) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_tower)) {
                            const range = creep.pos.getRangeTo(enemy_tower)
                            if (range > 3) {
                                creep.moveTo(enemy_tower, {ignoreCreeps: true});
                            } else {
                                creep.moveTo(enemy_tower);
                            }
                        }
                    } 
                } else 
                if (enemy_spawn) {
                    creep.say("⚔️S");
                    if(creep.attack(enemy_spawn) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_spawn)) {
                            creep.moveTo(enemy_spawn);
                        }
                    } 
                } else 
                if (enemy_build) {
                    creep.say("⚔️B");
                    if(creep.attack(enemy_build) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_build)) {
                            creep.moveTo(enemy_build);
                        }
                    } 
                } else if (enemy_creeps) {
                    creep.say("⚔️c");
                    if(creep.attack(enemy_creeps) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_creeps)) {
                            creep.moveTo(enemy_creeps);
                        }
                    } 
                } else {
                    creep.say("👀");
                    if (targetPos && targetPos.x) {
                        if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 3)) {
                            creep.moveTo(targetPos.x, targetPos.y);
                        }
                    } else {
                        if (!creep.pos.inRangeTo(25, 25, 10)) {
                            creep.moveTo(25, 25);
                        }
                    }
                }
                // creep.move(TOP)
            }
        }
        // --scout logic end--
        
    }
};

module.exports = roleAttackerTeam;
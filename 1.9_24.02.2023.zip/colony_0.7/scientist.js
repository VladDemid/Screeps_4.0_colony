var roleScientist = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --Scientist logic start--
        
        const myStorage = creep.room.storage  
        const myTerminal = creep.room.terminal  
        
        
        creep.say("🔬");
        
        if (creep.store.getUsedCapacity() == 0) {
            creep.memory.full = false;
        } else if (creep.store.getUsedCapacity() == creep.store.getCapacity() ) {
            creep.memory.full = true;
        }
        
        
        if (!creep.memory.myHomePos && Memory.gl_var.myRooms[creep.room.name].labs && Memory.gl_var.myRooms[creep.room.name].labs.inputLabs) {
            const inputLab1 = Game.getObjectById(Memory.gl_var.myRooms[creep.room.name].labs.inputLabs[0].id)
            creep.memory.myHomePos = inputLab1.pos;
        }
        const HomePos = creep.memory.myHomePos
        
        if (!creep.memory.labs && Memory.gl_var.myRooms[creep.room.name].labs) {
            creep.memory.labs = Memory.gl_var.myRooms[creep.room.name].labs
        }
        const labs = creep.memory.labs
        
        
        if (Game.time % 1 == 0) { //если реакция только началась, а крип решит еще принести
            if (Memory.synthesis[creep.room.name]) {
                creep.memory.synthesis = Memory.synthesis[creep.room.name]
            } else {
                creep.memory.synthesis = null
            }
        }
        const synthesis = creep.memory.synthesis
        
        
        
        
        
        
        
        if (synthesis && synthesis.action != "idle") {
            if (synthesis.action == "reverse") {
                
                // const targetAmmount = (labs.outputLabs.length) * 1000
                if (synthesis.status == "waiting") { //подготовка 
                    let needToBring = false
                    for (lab in labs.outputLabs) {
                        const outputLab = Game.getObjectById(labs.outputLabs[lab].id)
                        if (outputLab && outputLab.store[synthesis.components[0]] < 400 && myTerminal.store[synthesis.components[0]] >= 0) { // в каждой по 1000 надо
                            // console.log(outputLab.store[synthesis.components[0]], synthesis.components[0]);
                            creepFuncs.bringSome(creep, synthesis.components[0], 400, myTerminal, outputLab)
                            needToBring = true
                            break;
                        }
                    }
                    if (!needToBring) {
                        Memory.synthesis[creep.room.name].status = "active"
                    }
                } else if (synthesis.status == "active") {
                    creep.say("⚗️");
                    if (!creep.pos.isNearTo(HomePos.x, HomePos.y)) {
                        creep.moveTo(HomePos.x, HomePos.y, {reusePath: 10});
                    }
                } else if (synthesis.status == "ready") {
                    let allLabs = []
                    for (lab in labs.outputLabs) {
                        allLabs.push(Game.getObjectById(labs.outputLabs[lab].id))
                    }
                    for (lab in labs.inputLabs) {
                        allLabs.push(Game.getObjectById(labs.inputLabs[lab].id))
                    }
                    
                    creepFuncs.cleanAllNew(creep, allLabs, myTerminal)
                }
            } else if (synthesis.action == "synthesis") {
                if (synthesis.status == "waiting") { //подготовка 
                    let needToBring = false
                    for (lab in labs.inputLabs) {
                        // складывать в  лабу1 - компонент1, в лабу2 - компонент2
                        const inputLab = Game.getObjectById(labs.inputLabs[lab].id)
                        if (inputLab && inputLab.store[synthesis.components[lab]] < 3000 && myTerminal.store[synthesis.components[lab]] >= 0) { // в каждой по 1000 надо
                            // console.log(outputLab.store[synthesis.components[0]], synthesis.components[0]);
                            creepFuncs.bringSome(creep, synthesis.components[lab], 3000, myTerminal, inputLab)
                            needToBring = true
                            break;
                        }
                    }
                    if (!needToBring) {
                        Memory.synthesis[creep.room.name].status = "active"
                    }
                } else if (synthesis.status == "active") {
                    creep.say("⚗️");
                    if (!creep.pos.isNearTo(HomePos.x, HomePos.y)) {
                        creep.moveTo(HomePos.x, HomePos.y, {reusePath: 10});
                    }
                    // const boostLab = Game.getObjectById(creep.memory.labs.boostLab.id)
                    // creepFuncs.cleanAllNew(creep, [boostLab], myTerminal)
                    
                } else if (synthesis.status == "ready") {
                    let allLabs = []
                    for (lab in labs.outputLabs) {
                        allLabs.push(Game.getObjectById(labs.outputLabs[lab].id))
                    }
                    for (lab in labs.inputLabs) {
                        allLabs.push(Game.getObjectById(labs.inputLabs[lab].id))
                    }
                    
                    creepFuncs.cleanAllNew(creep, allLabs, myTerminal)
                }
            }
        } else {
            thisRoom = creep.room.name
            
            let nuker = null
            if (Memory.gl_var.myRooms[thisRoom].structures["nuker"]) {
                nuker = Game.getObjectById(Memory.gl_var.myRooms[thisRoom].structures["nuker"][0].id) 
            }
            let pSpawn = null
            if (Memory.gl_var.myRooms[thisRoom].structures["powerSpawn"]) {
                pSpawn = Game.getObjectById(Memory.gl_var.myRooms[thisRoom].structures["powerSpawn"][0].id)
            }
                
            let nukerIsFull = true //по умолчанию типа заполнена, даже если её нет
            if (nuker) {
                nukerIsFull = !!(nuker.store["G"] == 5000)
            }
            let pSpawnIsFull = true //по умолчанию типа заполнен, даже если её нет
            if (pSpawn) {
                pSpawnIsFull = !!(pSpawn.store["power"] > 0)
            }
            
            if (nuker && !nukerIsFull && myTerminal && (myTerminal.store["G"] + creep.store["G"] + nuker.store["G"]) >= 5000 ) {
                creepFuncs.bringSome(creep, "G", 5000, myTerminal, nuker)
            } else if (nuker && !nukerIsFull && myTerminal && (myTerminal.store["G"] + creep.store["G"] + nuker.store["G"]) >= 3000 ) {
                creepFuncs.bringSome(creep, "G", 3000, myTerminal, nuker)
            } else if (pSpawn && !pSpawnIsFull && myStorage && (myStorage.store["power"] + creep.store["power"] + pSpawn.store["power"]) >= 100 ) {
                creepFuncs.bringSome(creep, "power", 100, myStorage, pSpawn)
            } else if (pSpawn && !pSpawnIsFull && myTerminal && (myTerminal.store["power"] + creep.store["power"] + pSpawn.store["power"]) >= 100 ) {
                creepFuncs.bringSome(creep, "power", 100, myTerminal, pSpawn)
            } else {
                if (pSpawn) {
                    if (!creep.pos.isNearTo(pSpawn)) {
                        creep.moveTo(pSpawn, {reusePath: 10});
                    }
                } else if (HomePos) {
                    if (!creep.pos.isNearTo(HomePos.x, HomePos.y)) {
                        creep.moveTo(HomePos.x, HomePos.y, {reusePath: 10});
                    }
                }
            }
        }
        
        // if (creep.name == "W48N49_scientist_1") {
        //     const target = Game.getObjectById("6173ef4546872395bc79ca2b")
        //     // creep.withdraw(target, "O")
        //     // creep.pickup(target)
        //     // creep.drop("O")
        //     // creep.moveTo(target)
        //     creepFuncs.bringSome(creep, "Z", 8400, target, myTerminal)
        // }
        
        // console.log(creep.pos.isNearTo(creep.memory.myHomePos));
        
    } 
         
        // --Scientist logic end--
        
}

module.exports = roleScientist;
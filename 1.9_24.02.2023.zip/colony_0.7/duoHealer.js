var roleDuoHealer = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --scout logic start--
        const myNameSplit = creep.name.split("_")
        const myActionName = myNameSplit[1]
        const myAttackerCreepName = creep.name.replace("Healer", "Attacker")
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let myAttackerCreep = null
        if (creep.memory.myAttackerCreepId) {
            myAttackerCreep = Game.getObjectById(creep.memory.myAttackerCreepId)
        } else {
            myAttackerCreep = Game.creeps[myAttackerCreepName]
        }
        
        if (!creep.memory.myAttackerCreepId && myAttackerCreep) {
            creep.memory.myAttackerCreepId = myAttackerCreep.id
        }
        
        if (Game.time % 10 === 0 && !myAttackerCreep) { //если прошлый был убит, то заменить на нового
            myAttackerCreep = Game.creeps[myAttackerCreepName]
            if (myAttackerCreep) {
                creep.memory.myAttackerCreepId = myAttackerCreep.id
            }
        }
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            creep.memory.needBoost = false //если флага нет, то ничего не делать
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("🥾");
        //добавить автоследование myCreepFollowName
        
        // creep.memory.needBoost = false
        if (creep.memory.needBoost == undefined || creep.memory.needBoost === true) {
            creepFuncs.boostCreepMass(creep)
        } else {
            if (myAttackerCreep) {
                creep.say("💉");
                // if (creep.pos.x > 45) {
                //     console.log("_______________");
                //     console.log("healer: ", creep.pos.x, creep.pos.roomName,"| attacker: ", myAttackerCreep.pos.x, myAttackerCreep.pos.roomName);
                // }
                
                if (myAttackerCreep.pos.roomName !== creep.pos.roomName) {
                    creepFuncs.myRoutes(creep, myAttackerCreep.pos.roomName)
                    
                } else {
                    const _move = myAttackerCreep.memory._move
                    let myAttackerTargetPos = null
                    if (_move) {
                        myAttackerTargetPos = new RoomPosition(_move.dest.x, _move.dest.y, _move.dest.room)
                    }
                    // (_move && !_move.dest(myAttackerCreep.pos)
                    if (!creep.pos.isNearTo(myAttackerCreep.pos) || !myAttackerCreep.pos.isNearTo(myAttackerTargetPos)  ) {
                        creep.moveTo(myAttackerCreep.pos);
                        // console.log(!creep.pos.isNearTo(myAttackerCreep.pos), !myAttackerCreep.pos.isNearTo(myAttackerTargetPos), "move");
                    }
                    const manualMove = creepFuncs.isNearEdges(creep) 
                    // if (creep.pos.x > 45) {
                    //     console.log(manualMove, creep.pos.roomName !== targetRoomMem, manualMove, creepFuncs.isAtTheEdges(myAttackerCreep));
                    // }
                    if (creep.pos.roomName !== targetRoomMem && manualMove && creepFuncs.isAtTheEdges(myAttackerCreep)) { 
                        if (manualMove) {
                            // console.log("manualMove:", manualMove, creep.pos.roomName, myAttackerCreep.pos.roomName);
                            // creep.move(manualMove)
                            creep.moveTo(myAttackerCreep.pos);
                            // console.log(creep.move(manualMove));
                        }
                    }
                    const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 5);
                    const enemy_build_near = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 5)
                    
                    // if (enemy_creeps_near[0] || enemy_build_near[0]) {
                    //     needRangedMassAttack = true
                    // }
                    if (creep.hits < creep.hitsMax * 0.94) {
                        creep.heal(creep)
                    } else if (myAttackerCreep.hits < myAttackerCreep.hitsMax || (creep.pos.roomName === targetRoomMem && (enemy_creeps_near[0] || enemy_build_near[0]) ) || creep.pos.roomName === "W48N46") {
                        creep.heal(myAttackerCreep)
                    }
                    
                }
            } else {
                creep.suicide()
            }
            // if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
                // creepFuncs.myRoutes(creep, targetRoomMem)
            //     creepFuncs.goCorridors(creep, targetRoomMem)
            // } else {
                
            //     const myDamagedCreep = creep.pos.findClosestByRange(FIND_MY_CREEPS, {
            //         filter: function(object) {
            //             return object.hits < object.hitsMax;
            //         }
            //     });
            //     if(myDamagedCreep) {
            //         if(creep.heal(myDamagedCreep) == ERR_NOT_IN_RANGE) {
            //             creep.moveTo(myDamagedCreep);
            //         }
            //     } else if (targetPos) {
            //         if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 4)) {
            //             creep.moveTo(targetPos.x, targetPos.y);
            //         }
            //     } else {
            //         if (!creep.memory.myAttacker) {
                        
            //         }
            //         if (!creep.pos.inRangeTo(25, 25, 3)) {
            //             creep.moveTo(25, 25);
            //         }
            //     }
            // }
        }
        
        
    }
};

module.exports = roleDuoHealer;
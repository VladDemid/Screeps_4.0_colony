
var rolePowerAttacker = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --powerAttacker logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4].myActionName = 0
        }
        
        if (!creep.memory.powerId) {
            if (Memory.obsInfo[creep.memory.startRoom] && Memory.obsInfo[creep.memory.startRoom].status == 'active') {
                creep.memory.powerId = Memory.obsInfo[creep.memory.startRoom].powerId
            }
        }
        
        
        
        
        if (!creep.memory.powerId) {
            if (Memory.obsInfo[creep.memory.startRoom]) {
                creep.memory.powerId = Memory.obsInfo[creep.memory.startRoom].powerId
            }
        }
        
        if (!creep.memory.mode) {
            creep.memory.mode = "toPower"
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        const powerInfo = Memory.obsInfo[creep.memory.startRoom]
        // console.log(creep.room.name);
        
        creep.say("📦🥾");
        
        if (creep.memory.mode == "toPower") {
            if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
                creepFuncs.goCorridors(creep, targetRoomMem)
            } else {
                creep.say("📦");
                if (creep.store["power"] > 0) {
                    creep.memory.mode = "toHome"
                }
                
                if (powerInfo.status == 'carryersGoing' || powerInfo.status == 'almostDone' || powerInfo.status == 'taking' || powerInfo.status == 'idle') {
                    const powerBank = Game.getObjectById(creep.memory.powerId)
                    if (powerBank) {
                        if (!creep.pos.inRangeTo(powerBank, 4)) {
                            creep.moveTo(powerBank);
                        }
                        // console.log(creep.pos.getRangeTo(25, 25));
                        if (!creep.pos.inRangeTo(25, 25, 22)) {
                            creep.moveTo(25, 25);
                        }
                    } else {
                        
                        const drop = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES, {
                            filter: (i) => i.resourceType == "power" && 
                                           i.amount > 1
                        });
                        const ruina = creep.pos.findClosestByRange(FIND_RUINS, {
                            filter: (i) => i.store["power"] >= 1
                        });
                        
                        if (ruina) {
                            if(creep.withdraw(ruina, "power") == ERR_NOT_IN_RANGE) {
                                if (!creep.pos.isNearTo(ruina)) {
                                    creep.moveTo(ruina, {reusePath: 2});
                                }
                            }
                        } else if(drop) {
                            if(creep.pickup(drop) == ERR_NOT_IN_RANGE) {
                                creep.moveTo(drop, {reusePath: 3});
                            }
                        }
                    }
                } else {
                    if (!creep.pos.inRangeTo(25, 25, 3)) {
                        creep.moveTo(25, 25);
                    }
                }
                
                // creep.move(TOP)
            }
        } else if (creep.memory.mode == "toHome") {
            const startRoom = creep.memory.startRoom
            if (startRoom && creep.pos.roomName != startRoom) {
                creepFuncs.goCorridors(creep, startRoom)
            } else if (creep.pos.roomName == startRoom) {
                if (creep.store["power"] > 0) {
                    
                    const myStorage = creep.room.storage
                    const myTerminal = creep.room.terminal
                    
                    let rangeToStorage = null
                    if (myStorage) {
                        rangeToStorage = creep.pos.getRangeTo(myStorage)
                    }
                    let rangeToTerminal = null
                    if (myTerminal) {
                        rangeToTerminal = creep.pos.getRangeTo(myTerminal)
                    }
                    
                    if (myTerminal && myTerminal.store["power"] < 20000) {
                        if (rangeToTerminal > 7) {
                            creep.moveTo(myTerminal, {reusePath: 10, ignoreCreeps: false});
                        } else {
                            if(creep.transfer(myTerminal, "power") == ERR_NOT_IN_RANGE) {
                                if (!creep.pos.isNearTo(myTerminal)) {
                                    creep.moveTo(myTerminal, {reusePath: 8});
                                }
                            }
                        }
                    } else if (myStorage && myStorage.store["power"] < 200000) {
                        if (rangeToStorage > 7) {
                            creep.moveTo(myStorage, {reusePath: 10, ignoreCreeps: false});
                        } else {
                            if(creep.transfer(myStorage, "power") == ERR_NOT_IN_RANGE) {
                                if (!creep.pos.isNearTo(myStorage)) {
                                    creep.moveTo(myStorage, {reusePath: 8});
                                }
                            }
                        }
                    }
                } else {
                    creep.suicide()
                }
                
            }
        }
        
        // --powerAttacker logic end--
        
    }
};

module.exports = rolePowerAttacker;
funcs = require("funcs");

var roleHarasser = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --harasser logic start--
        ratRooms = {
            W38N41: ["W33N43", "W33N45"],
            W41N39: ["W29N39", "W30N39"],
            W42N41: ["W33N41", "W32N40"],
            W38N41: ["W29N39", "W29N40"],
        }
        
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        let targetPos = null
        let targetRoom = null 
        const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
        let needHeal = false
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
                creep.memory.ratMode = false
                creep.memory.heroMode = false
            }
        }
        // console.log(creep.room.name);
        
        creep.say("🥾🐽");
        
        if (creep.hits < creep.hitsMax) {
            needHeal = true
            if (creep.hits < creep.hitsMax * 0.7) {
                creep.memory.ratMode = true
            }
        }
        
        
        //буст
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            let needToBoost = false
            if (Game.rooms[creep.memory.startRoom].controller.level >= 7 ) {
                needToBoost = true
            }
            creep.memory.needToBoost = needToBoost
        }
        
        // let boostLab = null
        // if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
        //     boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        // }
        
        // if (creep.memory.needToBoost) {
        //     creepFuncs.boostCreep(creep, boostLab)
        // }
        
        if (creep.memory.ratMode) {
            creep.memory.targetRoomMem = ratRooms[creep.memory.startRoom][1]
        }
        
        if (creep.memory.needBoost == undefined || creep.memory.needBoost === true) {
            creepFuncs.boostCreepMass(creep)
        } else {
            if (creep.memory.targetRoomMem && creep.pos.roomName != creep.memory.targetRoomMem) {
                creepFuncs.myRoutes(creep, creep.memory.targetRoomMem)
                // creepFuncs.goCorridors(creep, creep.memory.targetRoomMem)
                creep.say("🥾🐽");
            } else {
                // const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
                const enemy_build = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "spawn" 
                                || i.structureType == "storage" 
                                || i.structureType == "terminal" 
                                || i.structureType == "tower"
                                || i.structureType == "link" 
                });
                // const enemy_extension_near = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                //     filter: (i) => i.structureType == "extension" 
                // });
                // const enemy_build_secondary = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                //     filter: (i) => i.structureType == "factory" 
                //                 || i.structureType == "tower" 
                //                 || i.structureType == "powerBank" 
                //                 || i.structureType == "tower" 
                //                 || i.structureType == "lab" 
                //                 || i.structureType == "link" 
                //                 || i.structureType == "container" 
                //                 && i.structureType != "rampart" 
                //                 && i.structureType != "constructedWall" 
                // });
                const construction_site_near = creep.pos.findClosestByRange(FIND_HOSTILE_CONSTRUCTION_SITES, {
                    filter: (i) => i.progress > 0
                });
                const enemy_creep_nearest = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                const enemy_build_near = creep.pos.findInRange(FIND_HOSTILE_STRUCTURES, 3)
                // const enemy_build = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                //     filter: (i) => i.structureType != "controller" 
                //                 && i.structureType != "storage" 
                //                 && i.structureType != "terminal" 
                //                 && i.structureType != "factory" 
                //                 && i.structureType != "powerBank" 
                // });
                // const enemy_tower = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, { //enemy_tower, enemy_creep_nearest, enemy_container, 
                //     filter: (i) => i.structureType == "tower" 
                //                 // && i.structureType != "rampart" 
                // });
                // const enemy_spawn = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                //     filter: (i) => i.structureType == "spawn" 
                //                 // && i.structureType != "rampart" 
                // });
                const invaderCore = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "invaderCore" 
                                // && i.structureType != "rampart" 
                });
                const enemy_container = creep.pos.findClosestByRange(FIND_STRUCTURES, {
                    filter: (i) => i.structureType == "container" 
                                // && i.structureType != "rampart" 
                });
                const enemy_extension_near = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "extension" 
                });
                const target_by_id = Game.getObjectById("63f2a1ff13a890b335f672e5")
                
                let needRangedMassAttack = false
                
                if (enemy_creeps_near[0] || enemy_build_near[0]) {
                    needRangedMassAttack = true
                }
                
                if (enemy_creeps_near[0]) {
                    needHeal = true
                }
                
                
                if (target_by_id) {
                    creep.say("🐽i");
                    if (creep.pos.inRangeTo(target_by_id, 1)) {
                         needRangedMassAttack = true
                    } else if (!creep.pos.inRangeTo(target_by_id, 1)) {
                        creep.moveTo(target_by_id, {reusePath: 10});
                    }
                } else 
                if (enemy_build) {
                    creep.say("🐽b");
                    if (creep.pos.inRangeTo(enemy_build, 1)) {
                         needRangedMassAttack = true
                    } else if (!creep.pos.inRangeTo(enemy_build, 1)) {
                        creep.moveTo(enemy_build, {reusePath: 10});
                    }
                } else 
                if (enemy_creep_nearest) {
                    if (creep.pos.roomName == "W29N39") {
                        creep.memory.heroMode = true
                    }
                    if (enemy_creep_nearest.body[0].type === "ranged_attack" && (enemy_creep_nearest.body[0].boost && enemy_creep_nearest.body[0].boost != "KHO2") && creep.pos.inRangeTo(enemy_creep_nearest, 14) && !creep.memory.heroMode) {
                        // console.log(enemy_creep_nearest.body[0].boost);
                        creep.memory.ratMode = true
                    }
                    creep.say("🐽");
                    if (creep.pos.inRangeTo(enemy_creep_nearest, 1)) {
                         needRangedMassAttack = true
                    } else {
                        creep.moveTo(enemy_creep_nearest, {reusePath: 10, swampCost: 3});
                    }
                } else 
                // if (enemy_container && enemy_container.id != "63f4d23596b6110027bea244" && enemy_container.id != "63f4d1cdd7932a17235e6969") {
                //     creep.say("🐽◽️");
                //     if (creep.pos.inRangeTo(enemy_container, 3)) {
                //         //  needRangedMassAttack = true
                //         creep.rangedAttack(enemy_container)
                //     } else if (!creep.pos.inRangeTo(enemy_container, 3)) {
                //         creep.moveTo(enemy_container, {reusePath: 10, swampCost: 3});
                //     }
                // } else 
                if (enemy_extension_near ) {
                    creep.say("🐽");
                    if (creep.pos.inRangeTo(enemy_extension_near, 1)) {
                         needRangedMassAttack = true
                        // creep.rangedAttack(enemy_extension_near)
                    } else if (!creep.pos.inRangeTo(enemy_extension_near, 1)) {
                        creep.moveTo(enemy_extension_near, {reusePath: 10, swampCost: 3});
                    }
                } else 
                if (construction_site_near) {
                    creep.say("🐽cs");
                    creep.moveTo(construction_site_near)
                    // let inRampart = false 
                    // const look = creep.room.lookAt(construction_site_near);
                    // look.forEach(function(lookObject) {
                    //     if(lookObject.type == "structure") {
                    //         inRampart = true
                    //     }
                    // });
                    // if (!inRampart) {
                    //     creep.moveTo(construction_site_near)
                    // } 
                    // else {
                    //     if (!creep.pos.inRangeTo(construction_site_near, 1) {
                    //         creep.moveTo(construction_site_near)
                    //     }
                    // }
                } else
                if (enemy_container ) {
                    creep.say("🐽");
                    if (creep.pos.inRangeTo(enemy_container, 3)) {
                         needRangedMassAttack = false
                        creep.rangedAttack(enemy_container)
                    } else if (!creep.pos.inRangeTo(enemy_container, 3)) {
                        creep.moveTo(enemy_container, {reusePath: 10, swampCost: 5});
                    }
                } else 
                // if (enemy_spawn) {
                //     creep.say("🐽");
                //     if (creep.pos.inRangeTo(enemy_spawn, 1)) {
                //          needRangedMassAttack = true
                //         // creep.rangedAttack(enemy_spawn)
                //     } else if (!creep.pos.inRangeTo(enemy_spawn, 1)) {
                //         creep.moveTo(enemy_spawn, {reusePath: 10, swampCost: 3});
                //     }
                // } else 
                {
                    if (targetPos && targetPos.x) {
                        if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 3)) {
                            creep.moveTo(targetPos.x, targetPos.y);
                        }
                    } else {
                        if (!creep.pos.inRangeTo(25, 25, 10)) {
                            creep.moveTo(25, 25, {reusePath: 10, swampCost: 1});
                        }
                    }
                }
                
                if (needRangedMassAttack) {
                    creep.rangedMassAttack();
                }
                
            }
            
            
            
            // creep.rangedMassAttack();
            // creep.heal(creep)
            // if (!creep.pos.inRangeTo(33, 28, 1)) {
            //     creep.moveTo(33, 28);
            // }
            
        }
        
        if (needHeal || creep.hits < creep.hitsMax || enemy_creeps_near[0]) {
            creep.heal(creep)
        }
        if (creep.memory.ratMode && creep.pos.roomName == ratRooms[creep.memory.startRoom][1]) {
            creep.memory.ratMode = false
            creep.memory.targetRoomMem = ratRooms[creep.memory.startRoom][0]
        }
        
        if (creep.memory.ratMode) {
            creep.say("🐀")
        }
        
        // if ( creep.hits < creep.hitsMax || enemy_creeps_near[0]) {
        //     needRangedMassAttack = true
        // }
        
        
        // if (needRangedMassAttack) {
        //     creep.rangedMassAttack();
        // }
        
        // if (creep.memory.ratMode && ) {
            
        // }
        // --harasser logic end--
        
    }
};

module.exports = roleHarasser;
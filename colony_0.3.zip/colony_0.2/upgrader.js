// creepFuncs = require("creepFuncs")

var construction;
// когда 4 link`а, один поставить к контроллеру и держать там крипов
var roleUpgrader = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myStorage = creep.room.storage
        const myController = creep.room.controller
        const containers = Memory.gl_var.myRooms[creep.room.name]["containers"]
        let containersSorted = null
        if (Memory.gl_var.myRooms[creep.room.name].containersSorted) {
            containersSorted = Memory.gl_var.myRooms[creep.room.name].containersSorted
        }
        
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        
        // const ticksToSaveController = 2000
        const energyContainerReservation = 500 //оставить для остальных важных процессов
        
        const energyStoreReservation = Memory.constants.energyThresholds.upgradersTakeEnergyFromStore //оставить для остальных важных процессов
        const ticksToLive = creep.ticksToLive
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest = creepFuncs.isOdd(creepIndex)
        
        
        creep.say("🔋");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        // var sources = creep.room.find(FIND_SOURCES);
        
        if (!creep.memory.full) {
            if (ticksToLive > 40) {
                if (myStorage && myStorage.store["energy"] > 0) {
                    if (myStorage.store["energy"] > energyStoreReservation) {
                        if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(myStorage)) {
                                creep.moveTo(myStorage, {reusePath: 10});
                            } 
                        }
                    } else {
                        if (!creep.pos.isNearTo(myStorage)) {
                            creep.moveTo(myStorage, {reusePath: 10});
                        } 
                    }
                } else if (containersSorted.length && containersSorted.length == 2) {
                    if (!creep.memory.targetContainerId || Game.time % (40 + creepIndex*20) == 0) {
                        creep.memory.targetContainerId = containersSorted[1].id
                    }
                    const targetContainer = Game.getObjectById(creep.memory.targetContainerId)
                    if (targetContainer.store["energy"] > energyContainerReservation) {
                        if(creep.withdraw(targetContainer, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(targetContainer)) {
                                creep.moveTo(targetContainer, {reusePath: 8});
                            }
                        }
                    } else {
                        if (!creep.pos.inRangeTo(targetContainer, 4)) {
                            creep.moveTo(targetContainer);
                        } 
                        if (creep.pos.x == targetContainer.pos.x && creep.pos.y == targetContainer.pos.y) {
                            
                        }
                        
                    }
                } else {
                    // var sources = creep.room.find(FIND_SOURCES);
                    
                    const creepIndex = creep.name.split('_')[2] - 1
                    const dest_mining = creepFuncs.isOdd(creepIndex)
                    const target_source = sources[dest_mining];
                    
                    
                    if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_source);
                    }
                    
                }
            } else if (ticksToLive <= 40) {
                creep.suicide()
            }
                
        } else if (creep.memory.full) {
            // creep.repair(Game.getObjectById("60cad343beaaeb595ec8cc16"))
            if (Game.time % 20 == 0) {
                construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    creep.memory.building = 1;
                } else { creep.memory.building = 0; }
            }
            // console.log(my_controller);
            
            if (creep.memory.building) {
                const newConstruction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                // console.log(creep.name, " building", construction);
                if(creep.build(newConstruction) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(newConstruction);
                }
            } else if (myController.level < 8 || myController.ticksToDowngrade < 199000) {
                if (creep.upgradeController(myController) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(myController, {reusePath: 10});
                }
            }
        }
        // --starter logic end--
        
    }
};

module.exports = roleUpgrader;
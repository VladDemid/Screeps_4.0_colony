var funcs = require("funcs");

var roleTowner = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --towner logic start--
        
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499 || !creep.memory.targetRoomMem) {
                creep.memory.targetRoomMem = targetRoom
            }
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        
        creep.say("🧱");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest = creepFuncs.isOdd(creepIndex)
        
        
        
        // console.log(creep.room.controller.reservation.username);
        if (creep.pos.roomName != creep.memory.targetRoomMem ) {
            creep.say("🥾🧱");
            creepFuncs.myRoutes(creep, targetRoomMem)
        } else {
            // creep.moveTo(25,25);
            if (!creep.memory.full ) {
                // const drop = null
                const drop = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES, {
                    filter: (i) => i.resourceType == "energy" && 
                                   i.amount > 100 
                });
                const ruina = creep.pos.findClosestByRange(FIND_RUINS, {
                    filter: (i) => i.store["energy"] >= 100 
                });
                if (drop) {
                    if(creep.pickup(drop, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(drop)) {
                            creep.moveTo(drop);
                        }
                    }
                } else if (ruina) {
                    if(creep.withdraw(ruina, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(ruina)) {
                            creep.moveTo(ruina);
                        }
                    }
                } else {
                    const sources = creep.room.find(FIND_SOURCES);
                    let target_source;
                    
                    if (sources[dest]) {
                        target_source = sources[dest];
                    } else {
                        target_source = sources[0];
                    }
                    if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_source);
                    } else {
                        if (!creep.pos.inRangeTo(target_source, 2)) {
                            creep.moveTo(target_source);
                        }
                    }
                }
                creepFuncs.moveFromEdge(creep)
                // if (!creep.pos.inRangeTo(25,25, 3)) {
                //     creep.moveTo(25,25);
                // }
                
            } else if (creep.memory.full) {
                const construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    if(creep.build(construction) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(construction);
                    }
                } else if (creep.room.controller.level <= 6) {
                    const controllerr = creep.room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTROLLER}})[0];
                    if (creep.upgradeController(controllerr) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(controllerr);
                    }
                } else {
                    if (!creep.pos.inRangeTo(25,25, 3)) {
                        creep.moveTo(25,25);
                    }
                }
            }
        }
        
        
        // --towner logic end--
        
    }
};

module.exports = roleTowner;
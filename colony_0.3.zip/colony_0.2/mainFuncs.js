starter = require("starter");
defender = require("defender");
miner = require("miner");
upgrader = require("upgrader");
carryer = require("carryer");
helper = require("helper");
scout = require("scout");
scoutTeam = require("scoutTeam");
attacker = require("attacker");
claimer = require("claimer");
towner = require("towner");

module.exports.rolesCountZeroing = function rolesCountZeroing() {
    for (let key in Memory.gl_var.myRooms) {
        Memory.gl_var.myRooms[key].screepsCounts = {}
        Memory.gl_var.myRooms[key].screepsCounts.total = 0
        for (let role of Memory.constants.roles) {
            Memory.gl_var.myRooms[key].screepsCounts[role] = 0
        }
    }
    // Memory.constants.triggers.countsZeroing = 1
};

module.exports.rolesMaxModifier = function rolesMaxModifier(population, roomsMaxCreeps) {
    for (let room in Memory.gl_var.myRooms) {
        const roomSpawnLevel = population.getSpawnLevel(room)
        const roomMemInfo = Memory.gl_var.myRooms[room]
        
        if (roomSpawnLevel <= 3) {
            if (roomMemInfo.containersSorted) {
                if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1] && roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 1700) { //тут была ошибка 
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 4
                    if (Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter == 2) {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 3 //чтобы не заглохло
                    }
                }
            }
        }
        
        if (Memory.gl_var.myRooms[room].structures.storage && Memory.gl_var.myRooms[room].structures.storage.length && roomSpawnLevel >= 4) {
            
            //upgrader's
            if (Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.increaseUpgradersNumber1) {
                // console.log(room, "upgraders = 4");
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 4
            }
            
            //carryer's
            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 1
            if (roomMemInfo.containersSorted) {
                if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 1700) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 3
                } else if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 500) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 2
                }
            }
            
            //helper
            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].helper = 1
            
            //starter's 
            const helperName = `${room}_helper_1`
            const helperCreep = Game.creeps[helperName]
            if (Memory.gl_var.gl_i == 1 || Memory.gl_var.gl_i % 20 == 0) { // чтобы каждый тик не считать countAmountToSpawn("starter")
                if (helperCreep || Game.rooms[room].energyAvailable >= population.countAmountToSpawn("helper", roomSpawnLevel)) {
                    //наверно надо еще проверять майнеров
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 0
                } else {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 2
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].helper = 0
                }
            }
            
            //ФЛАГИ 
            const flagEvents = Memory.gl_var.myRooms[room].flagEvents
            if (flagEvents && Object.keys(flagEvents).length != 0) {
                // console.log(room, Object.keys(flagEvents).length);
                for (let actionName in flagEvents) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel][actionName] = flagEvents[actionName].flagCount
                    // Memory.constants.roomMaxCreeps[room][roomSpawnLevel]["test"] = flagEvents[actionName].flagCount
                    // ---!!!!!!!!!!!!!---
                }
            }
        }
        
        //модификации из флагов
        // if (Memory.flagsInfo && Memory.flagsInfo[room]) {
        //     for (let actionName in Memory.flagsInfo[room]) {
        //         // console.log(room, actionName);
        //     }
        //     // Memory.constants.roomMaxCreeps[room][roomSpawnLevel][]
        // }
        
    }
};

module.exports.checkHealth = function checkHealth(creep) {
    // console.log(creep.hits, creep.hitsMax);
    if (creep.hits < creep.hitsMax && creep.pos.roomName == creep.memory.startRoom) {
        const room = creep.memory.startRoom
        const creepToHeal = {
                creepName: creep.name,
                creepRoom: creep.room.name, //где сейчас
            }
        Memory.gl_var.myRooms[room].needHeal = creepToHeal
        // console.log(Memory.gl_var.myRooms[room].needHeal);
    }
};

module.exports.activateCreep = function activateCreep(creep, roomsStructures) {
    this.checkHealth(creep)
    Memory.gl_var.myRooms[creep.memory.startRoom].screepsCounts.total++;
    eval(creep.memory.role).run(creep, roomsStructures, creepFuncs)
    // starter.run(creep)
};







/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('creepFuncs');
 * mod.thing == 'a thing'; // true
 */
 
const routeConstants2 = {
    W49N34: {
        W49N46: ["W50N34","W50N46"],
        W47N31: ["W50N34","W50N30","W47N30"],
        W48N31: ["W50N34","W50N30","W48N30"],
        W45N41: ["W50N34","W50N40","W45N40"],
        W48N46: ["W50N34","W50N46"],
        W42N28: ["W50N34","W50N30","W40N30","W40N29"],
        W41N37: ["W50N34","W50N40","W40N40","W40N37"],
        W49N39: ["W50N34","W50N40","W49N40"],
        W49N37: ["W50N34","W50N37"],
    }
}

module.exports.transferCreep = function (creep) {
    
};


module.exports.isOdd = function isOdd(num) { // возвращает 0 если четное, 1 если нечетное
    return num % 2
}

module.exports.travel = function travel(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room);
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit, {reusePath: 15}); 
    }    
}

module.exports.myRoutes = function myRoutes(creep, target_room) {
    
    const routeConstants = {
        W49N34: {
            W49N46: ["W50N34","W50N46"],
            W47N31: ["W50N34","W50N30","W47N30"],
            W48N31: ["W50N34","W50N30","W48N30"],
            W45N41: ["W50N34","W50N40","W45N40"],
            W48N46: ["W50N34","W50N46"],
            W42N28: ["W50N34","W50N30","W40N30","W40N29"],
            W41N37: ["W50N34","W50N40","W40N40","W40N37"],
            W49N39: ["W50N34","W50N40","W49N40"],
            W49N37: ["W50N34","W50N37"],
        }
    }
    
    if (creep.ticksToLive == 1499 || (creep.ticksToLive == 599 && !creep.memory.stop)) {
        
        if (routeConstants[creep.memory.startRoom] && routeConstants[creep.memory.startRoom][creep.memory.targetRoomMem]) {
            creep.memory.stops = routeConstants[creep.memory.startRoom][creep.memory.targetRoomMem]
            creep.memory.stop = creep.memory.stops[0]
        }
        
    }
    if (creep.memory.stop) {
        if (creep.pos.roomName != creep.memory.stop) {
            // console.log("no");
            const route = Game.map.findRoute(creep.room, creep.memory.stop);
            if(route.length > 0) {
                const exit = creep.pos.findClosestByRange(route[0].exit);
                creep.moveTo(exit, {reusePath: 15}); 
            }
        } else if (creep.pos.roomName == creep.memory.stop) {
            // console.log("yes");
            creep.memory.stops.splice(0, 1)
            if (creep.memory.stops[0]) {
                creep.memory.stop = creep.memory.stops[0]
            } else {
                creep.memory.stop = null
            }
        }
    } else {
        // creep.memory.teamReady = false
        // creep.memory.waitingCount = myFlagAction.flagCount
        if (!creep.memory.teamReady) {
            
            if ( Game.time % 10 == 0) {
                
            }
            
        }
        
        const route = Game.map.findRoute(creep.room, target_room);
        if(route.length > 0) {
            const exit = creep.pos.findClosestByRange(route[0].exit);
            creep.moveTo(exit, {reusePath: 15}); 
        }    
    }
}

module.exports.myRoutesTeam = function myRoutes(creep, target_room) {
    
    if (creep.ticksToLive == 1499 || (creep.ticksToLive == 599 && !creep.memory.stop)) {
        
        if (routeConstants2[creep.memory.startRoom] && routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]) {
            creep.memory.stops = routeConstants2[creep.memory.startRoom][creep.memory.targetRoomMem]
            creep.memory.stop = creep.memory.stops[0]
            creep.memory.waitingRoom = creep.memory.stops[creep.memory.stops.length - 1]
        }
        
    }
    if (creep.memory.stop) {
        if (creep.pos.roomName != creep.memory.stop) {
            // console.log("no");
            const route = Game.map.findRoute(creep.room, creep.memory.stop);
            if(route.length > 0) {
                const exit = creep.pos.findClosestByRange(route[0].exit);
                creep.moveTo(exit, {reusePath: 15}); 
            }
        } else if (creep.pos.roomName == creep.memory.stop) {
            // console.log("yes");
            creep.memory.stops.splice(0, 1)
            if (creep.memory.stops[0]) {
                creep.memory.stop = creep.memory.stops[0]
            } else {
                creep.memory.stop = null
            }
        }
    } else if (creep.memory.waitingRoom) {
        const myActionName = creep.name.split("_")[1]
        if (!creep.memory.teamReady) {
            if (creep.pos.roomName != creep.memory.waitingRoom) {
                const route = Game.map.findRoute(creep.room, creep.memory.waitingRoom);
                if(route.length > 0) {
                    const exit = creep.pos.findClosestByRange(route[0].exit);
                    creep.moveTo(exit, {reusePath: 15}); 
                } 
            } else {
                if (!creep.pos.inRangeTo(25, 25, 5)) {
                    creep.moveTo(25, 25);
                } else {
                    creep.memory.iAmReady = true
                    if (Game.time % 5 == 0) {
                        const teamCreeps = creep.room.find(FIND_MY_CREEPS, {
                            filter: (creep) => (creep.name.split("_")[1] == myActionName) 
                                            && (Game.creeps[creep.name].memory.iAmReady)
                        })
                        if (teamCreeps.length == creep.memory.waitingCount) {
                            // console.log("we are ready");
                            creep.say(creep.memory.waitingCount)
                            creep.memory.teamReady = true
                        }
                        // console.log("waiting", teamCreeps.length, creep.memory.waitingCount);
                    }    
                }
            }
        } else if (creep.memory.teamReady) {
            const route = Game.map.findRoute(creep.room, target_room);
            if(route.length > 0) {
                const exit = creep.pos.findClosestByRange(route[0].exit);
                creep.moveTo(exit, {reusePath: 15}); 
            }    
        }
    }
}





module.exports.moveFromEdge = function moveFromEdge(creep) {
    if (creep.pos.y >= 47) {creep.move(TOP)}  
}
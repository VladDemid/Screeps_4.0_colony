

var roleCarryer = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --carryer logic start--
        
        const myStorage = creep.room.storage
        // const start = Game.cpu.getUsed()
        // const end = Game.cpu.getUsed() - start
        // console.log(end.toFixed(3));
        
        let containersSorted = null
        if (Memory.gl_var.myRooms[creep.room.name].containersSorted) {
            containersSorted = Memory.gl_var.myRooms[creep.room.name].containersSorted
        }
        
        const creepIndex = creep.name.split('_')[2] - 1 // 1|2
        const dest = creepFuncs.isOdd(creepIndex)
        
        creep.say("📦");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        creep.memory.dest = creep.name.split('Carryer')[1] - 1;
        
        
        
        if (!creep.memory.full) {
            if (creep.ticksToLive > 50) {
                if (containersSorted.length && containersSorted.length == 2) {
                    if (!creep.memory.targetContainerId) {
                        creep.memory.targetContainerId = containersSorted[1].id
                    }
                    const targetContainer = Game.getObjectById(creep.memory.targetContainerId)
                    if (targetContainer && targetContainer.store["energy"] >= creep.store.getCapacity()) { //!!!creep.store.getCapacity()!!!
                        if(creep.withdraw(targetContainer, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(targetContainer)) {
                                creep.moveTo(targetContainer, {reusePath: 8});
                            }
                        }
                    } else {
                        if (!creep.pos.inRangeTo(targetContainer, 4)) {
                            creep.moveTo(targetContainer);
                        }
                    }
                }
            } else if (creep.ticksToLive <= 50) {
                creep.suicide()
            }
        } else if (creep.memory.full) {
            if (Game.time % (40 + creepIndex*20) == 0) {
                creep.memory.targetContainerId = containersSorted[1].id
            }
            if (myStorage && myStorage.store["energy"] < 400000) {
                if(creep.transfer(myStorage, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage, {reusePath: 8});
                    }
                }
            } else if (myStorage) {
                if (!creep.pos.inRangeTo(myStorage, 2)) {
                    creep.moveTo(myStorage);
                }
            }
        } 
    } 
         
        // --carryer logic end--
        
}


module.exports = roleCarryer;


module.exports = {
    
    maxCreeps: {
        1: { //начинают стартеры и все делают до 2 лвл
            starter: 6,
            defender: 2
        },
        2: { //
            starter: 4,
            miner: 2,
            defender: 2,
            upgrader: 2
        },
        3: { // появляется турель
            starter: 2,
            miner: 2,
            defender: 2,
            upgrader: 2
        },
        4: { //
            starter: 0,
            helper: 1,
            miner: 2,
            defender: 3,
            upgrader: 2,
            carryer: 1,
            
        }
    },
    roomMaxCreeps: {},
    triggers: {
        countsZeroing: 0
    },
    roles: ["starter", "miner", "upgrader", "helper", "defender",
            "carryer", "helper", "scout", "attacker", "claimer",
            "towner", "scoutTeam"],
    spawnLevels: {
        1: 300,
        2: 550,
        3: 800,
        4: 1300,
        5: 1800,
        6: 2300,
        7: 5300,
        8: 12300
    },
    creepBody: {
        starter: { //универсальные рабочие пока все плохо
            1: { WORK: 1, CARRY: 1, MOVE: 2 },
            2: { WORK: 2, CARRY: 2, MOVE: 4 },
            3: { WORK: 2, CARRY: 6, MOVE: 4 },
            4: { WORK: 1, CARRY: 2, MOVE: 2 },
        },
        defender: { //ближний бой на всякий случай пока нет турелей
            1: {MOVE: 2, ATTACK: 2},
            2: {TOUGH: 1, MOVE: 4, ATTACK: 3},
            3: {TOUGH: 1, MOVE: 4, ATTACK: 3},
            4: {TOUGH: 1, MOVE: 4, ATTACK: 3},
        },
        miner: { //статичные копатели (строят вокруг себя||скидывают в ближайшие контейнеры/линки)
            2: { WORK: 3, CARRY: 2, MOVE: 2},
            3: { WORK: 5, CARRY: 2, MOVE: 3},
            4: { WORK: 6, CARRY: 2, MOVE: 3},
        },
        upgrader: {//строят и улучшают контроллер
            2: { WORK: 2, CARRY: 4, MOVE: 3 },
            3: { WORK: 4, CARRY: 4, MOVE: 4 },
            4: { WORK: 5, CARRY: 5, MOVE: 5 },
        },
        carryer: {//переносят энергию от контейнеров в склад пока нет линков
            4: { CARRY: 10, MOVE: 5 },
        },
        helper: {//переносят энергию по спавнерам и extension
            4: { CARRY: 10, MOVE: 5 },
        },
        scout: {
            4: { MOVE: 1 }
        },
        scoutTeam: {
            4: { MOVE: 1 }
        },
        attacker: {
            4: { ATTACK: 4, MOVE: 4 }
        },
        claimer: {
            4: { CLAIM: 1, MOVE: 3 }
        },
        towner: { 
            4: { WORK: 5, CARRY: 5, MOVE: 5 }
        },
    },
    energyThresholds: {
        upgradersTakeEnergyFromStore: 5000,
        increaseUpgradersNumber1: 100000
    }

    
    
};

var roleHelper = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --helper logic start--
        const myStorage = creep.room.storage
        const spawns = roomsStructures[creep.memory.startRoom]["spawn"]
        const spawn0 = Game.getObjectById(spawns[0].id) 
        const extensions = roomsStructures[creep.memory.startRoom]["extension"]
        const extension0 = Game.getObjectById(extensions[0].id)
        const towers = Memory.gl_var.myRooms[creep.memory.startRoom].structures["tower"]
        const tower0 = Game.getObjectById(towers[0].id)
        
        creep.say("🧰");
        if (creep.store["energy"] < 50) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        if (creep.ticksToLive == 1500) {
            creep.memory.foundMyTomb = 0;
        } else if (creep.ticksToLive == 1499) {
            myTomb = creep.pos.findInRange(FIND_TOMBSTONES, 3, {
                filter: (item) => item.store["energy"] >= creep.store.getCapacity()*0.3   
            })[0];
            if (myTomb) {
                creep.memory.foundMyTomb = 1;
                creep.memory.myTombId = myTomb.id;
            }
        }
        // console.log(sources[0].pos);
        if (!creep.memory.full) {
            if (creep.ticksToLive >= 1490 && creep.memory.foundMyTomb && creep.store["energy"] == 0 && creep.memory.myTombId) {
                const tomb = Game.getObjectById(creep.memory.myTombId);
                if(creep.withdraw(tomb, "energy") == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tomb);
                }
            } else if (myStorage && myStorage.store["energy"] > 0) {
                if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(myStorage)) {
                        creep.moveTo(myStorage, {reusePath: 8});
                    }
                }
            } 
            
            //брать из контейнеров
            
            // else {
            //     const near_container = creep.pos.findInRange(FIND_STRUCTURES, 3, {filter: {structureType: STRUCTURE_CONTAINER}})[0];
            //     if (near_container && near_container.store["energy"] > 600) {
            //         if(creep.withdraw(near_container, "energy") == ERR_NOT_IN_RANGE) {
            //             if (!creep.pos.isNearTo(near_container)) {
            //                 creep.moveTo(near_container);
            //             } 
            //         }
            //     } else {
            //         const my_container = containers_mass[containers_mass.length - 1]
            //         if (my_container && my_container.store["energy"] > 0) {
            //             if(creep.withdraw(my_container, "energy") == ERR_NOT_IN_RANGE) {
            //                 if (!creep.pos.isNearTo(my_container)) {
            //                     creep.moveTo(my_container);
            //                 } 
            //             }
            //         }
            //     }
            // }
            
            //???
            
            // if (creep.store["energy"] > 50) { //если одновременно новый спавн и "creep.memory.have_energy = false" то по пути на склад заполнять ext
            //     const range_1_ext = creep.pos.findInRange(FIND_STRUCTURES, 1, {
            //         filter: (i) => i.structureType == STRUCTURE_EXTENSION &&
            //                           i.store[RESOURCE_ENERGY] < i.store.energyCapacity
            //         }); 
            //     if  (range_1_ext && range_1_ext.length > 0) {
            //         creep.transfer(range_1_ext[0], RESOURCE_ENERGY);
            //     }
            // }
        } else if (creep.memory.full) {
            // console.log(my_spawns[0].store["energy"], my_spawns[0].store.getCapacity());
            if (spawn0.store["energy"] < 300) {
                if(creep.transfer(spawn0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(spawn0, {reusePath: 7});
                }
            } else if (extension0 && extension0.store.getFreeCapacity("energy") > 0) {
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extension0, {reusePath: 10}); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extension0);
                }
                if(creep.transfer(extension0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extension0);
                }
            } else if (towers && towers.length > 0 && tower0.store["energy"] < 800) {
                if(creep.transfer(tower0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower0, {reusePath: 10});
                }
            } else if (creep.store.getFreeCapacity() > 0) {
                creep.memory.full = false;
            } else {
                if (!creep.pos.isNearTo(spawn0)) {
                    creep.moveTo(spawn0);
                }
            }
            
            
        } 
        // --helper logic end--
    }
};

module.exports = roleHelper;
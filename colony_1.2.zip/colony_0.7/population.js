/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('population');
 * mod.thing == 'a thing'; // true
 */

module.exports.spawnCreep = function spawnCreep(room, role, spawnsNow) {
    
    const spawnMem = this.chooseSpawn(room, spawnsNow)
    // const spawner = Game.getObjectById(spawnMem.id)
    const spawner = spawnMem
    
    
    if (spawner && !spawner.spawning) {
        
        const spawnLevel = this.getSpawnLevel(room)
        const maxRoleCreeps = Memory.constants.roomMaxCreeps[room][spawnLevel][role]
        const newCreepName = this.createCreepName2(room, role, maxRoleCreeps)
        const newCreepBody = this.createCreepBody(role, spawnLevel, room)
        const energyNeedToSpawn = this.countAmountToSpawn(role, spawnLevel, room)
        const testCreepMemory = {
                role: role,
                startRoom: room 
            }
        // console.log(room, spawnLevel);
        // console.log(role, energyNeedToSpawn);
        const helperName = `${room}_helper_1`
        const helperCreep = Game.creeps[helperName]
        
        
        let helperIsSpawning = false
        for (spawn in spawnsNow) {
            // console.log(spawn);
            if (spawnsNow[spawn].spawning) {
                const spawningRole = spawnsNow[spawn].spawning.name.split("_")[1]
                if (spawningRole == "helper") {
                    helperIsSpawning = true
                }
            }
        }
        
        if (spawnLevel < 4 || (spawnLevel >= 4 && !helperCreep) || (spawnLevel >= 4 && helperCreep && helperCreep.ticksToLive > 30) || helperIsSpawning) {
            if (!spawner.spawning && Game.rooms[room].energyAvailable >= energyNeedToSpawn) {
                const creepMemory = {
                    memory: {
                        role: role,
                        startRoom: room 
                    }
                }
                spawner.spawnCreep(newCreepBody, newCreepName, creepMemory)
                // console.log(spawner.spawnCreep(newCreepBody, newCreepName, creepMemory));
            }
        }
        
    }
    
};

module.exports.chooseSpawn = function chooseSpawn(room, spawnsNow) {
    // return Memory.gl_var.myRooms[room].structures.spawn[0]
    for (spawn in spawnsNow) {
        if (!spawnsNow[spawn].spawning) {
            return spawnsNow[spawn]
            break;
        }
        
    }
};

module.exports.getSpawnLevel = function getSpawnLevel(room) {
    let spawnLevel = 8
    // for (let level in Memory.constants.spawnLevels) {}
    for (spawnLevel; Game.rooms[room].energyCapacityAvailable < Memory.constants.spawnLevels[spawnLevel]; spawnLevel--) {}
    
    return spawnLevel
    
    // console.log("spawn chosen");
};

module.exports.createCreepName2 = function create_name2(room, role, maxRoleCreeps) {
    let newCreepName;
    
    for (let i = 1; i <= maxRoleCreeps; i++) {
        newCreepName = room + "_" + role + "_" + i;
        // console.log(newCreepName);
        if (!Game.creeps[newCreepName]) {
            return newCreepName
        }
    }
    
    // console.log("----------");
}

module.exports.createCreepName = function create_name(room, role, maxRoleCreeps) {
    let newCreepName;
    do {
        newCreepName = room + "_" + role + "_" + this.random_Integer(1, maxRoleCreeps);
    } while (Game.creeps[newCreepName]);
    return newCreepName;
}

module.exports.createCreepBody = function createCreepBody(role, spawnLevel, room) {
    const bodyObj = Memory.constants.creepBody[role][spawnLevel]
    let newCreepBody = []
    
    for (let bodyType in bodyObj) {
        for (let i = 1; i <= bodyObj[bodyType]; i++) {
            newCreepBody.push(bodyType.toLowerCase())
        }
    }
    if (role == "starter" && Memory.gl_var.myRooms[room].screepsCounts.total < 3) { //на случай сбоев/апокалипсиса
        return [WORK, CARRY, CARRY, MOVE, MOVE]
    }
    return newCreepBody
}

module.exports.countAmountToSpawn = function countAmountToSpawn(role, spawnLevel, room) {  //сколько нужно энергии для спавна
    const bodyObj = Memory.constants.creepBody[role][spawnLevel]
    let amountToSpawn = 0;
    
    if (role == "starter" && Memory.gl_var.myRooms[room].screepsCounts.total < 3) { //на случай сбоев/апокалипсиса
        return 300
    }
    
    for (let bodyType in bodyObj) {
        for (let i = 1; i <= bodyObj[bodyType]; i++) {
            amountToSpawn += BODYPART_COST[bodyType.toLowerCase()]
            // console.log(bodyType, bodyType.toLowerCase());
        }
    }
    
    return amountToSpawn;
}

module.exports.random_Integer = function random_Integer(min, max) {
  // случайное число от min до (max+1)
  let rand = min + Math.random() * (max + 1 - min); //утечка!!!!!!
  return Math.floor(rand);
} 

var roleScout = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --scout logic start--
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        } else {
            // Memory.constants.roomMaxCreeps[creep.memory.startRoom][4].myActionName = 0
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        // console.log(creep.room.name);
        
        creep.say("🥾");
        
        
        if (targetRoomMem && creep.pos.roomName != targetRoomMem) {
            creepFuncs.goCorridors(creep, targetRoomMem)
        } else {
            creep.say("👀");
            if (targetPos) {
                if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 4)) {
                    creep.moveTo(targetPos.x, targetPos.y);
                }
            } else {
                if (!creep.pos.inRangeTo(25, 25, 3)) {
                    creep.moveTo(25, 25);
                }
            }
            // creep.move(TOP)
        }
        // --scout logic end--
        
    }
};

module.exports = roleScout;


var rolePowerCreep = {

    run: function(pCreep) {
    
        // console.log(Object.keys(pCreep.powers));
        
        ticksToRenew = 500
        const startRoom = pCreep.room.name
        const startRoomEnergyAvailable = Game.rooms[startRoom].energyAvailable
        const startRoomEnergyCapacity = Game.rooms[startRoom].energyCapacityAvailable
        
        memSources = Memory.gl_var.myRooms[startRoom].sources
        mySources = [] //запоминание здешних sources
        for (let memSource in memSources) {
            const thisSource = Game.getObjectById(memSources[memSource].id)
            mySources[memSource] = thisSource
        }
        
        let needPowerSource = null //необходимо ли апгрейдить source и какой
        for (let thisSource of mySources) {
            // console.log(Object.keys(thisSource.effects) );
            if ( !thisSource.effects || !thisSource.effects[0]  || (thisSource.effects[0] && thisSource.effects[0].ticksRemaining < 20) ) {
                needPowerSource = thisSource
                break
            }
        }
        
        if ( (!pCreep.memory.labToUsePowerId || Game.time % 10 == 0) && pCreep.powers[PWR_OPERATE_LAB] && Memory.synthesis[startRoom] && (Memory.synthesis[startRoom].status == "active" || Memory.synthesis[startRoom].status == "waiting")) {
            pCreep.memory.labToUsePowerId = null //заглушка
            const allLabs = Memory.gl_var.myRooms[startRoom].labs
            let outputLabs = []
            
            if (allLabs && allLabs.outputLabs) {
                for (lab of allLabs.outputLabs) {
                    outputLabs.push(Game.getObjectById(lab.id))
                }
            }
            
            for (lab of outputLabs) {
                if (!lab.effects || !lab.effects[0]) {
                    pCreep.memory.labToUsePowerId = lab.id
                    break;
                }
            }
        }
        let labToUsePower = null
        if (pCreep.memory.labToUsePowerId) {
            labToUsePower = Game.getObjectById(pCreep.memory.labToUsePowerId)
        }
        // console.log(needPowerSource);
        const thisStorage = pCreep.room.storage
        
        if (!pCreep.room.controller.isPowerEnabled) {
            if (pCreep.enableRoom(pCreep.room.controller) == ERR_NOT_IN_RANGE) {
                pCreep.moveTo(pCreep.room.controller)
            }
        } else if (pCreep.ticksToLive > ticksToRenew) {
            if (pCreep.powers[PWR_GENERATE_OPS] && pCreep.powers[PWR_GENERATE_OPS].cooldown == 0) {
                pCreep.usePower(PWR_GENERATE_OPS)
            } 
            if (pCreep.powers[PWR_OPERATE_EXTENSION] && startRoomEnergyAvailable < startRoomEnergyCapacity * 0.75 && pCreep.powers[PWR_OPERATE_EXTENSION].cooldown == 0) {
                if(pCreep.usePower(PWR_OPERATE_EXTENSION, thisStorage) == ERR_NOT_IN_RANGE) {
                    pCreep.moveTo(thisStorage, {reusePath: 10, ignoreRoads: true});
                }
            } else if (needPowerSource && pCreep.powers[PWR_REGEN_SOURCE] && pCreep.powers[PWR_REGEN_SOURCE].cooldown < 20) {
                if (pCreep.powers[PWR_REGEN_SOURCE].cooldown == 0) {
                    if(pCreep.usePower(PWR_REGEN_SOURCE, needPowerSource) == ERR_NOT_IN_RANGE) {
                        pCreep.moveTo(needPowerSource, {reusePath: 10, ignoreRoads: true});
                    }
                } else if (pCreep.powers[PWR_REGEN_SOURCE].cooldown < 20) {
                    if (!pCreep.pos.inRangeTo(needPowerSource, 3)) {
                        pCreep.moveTo(needPowerSource, {reusePath: 10, ignoreRoads: true});
                    }
                }
            //тут тупит (надо либо в конец либо хз)
            } else if (pCreep.powers[PWR_OPERATE_LAB] && pCreep.powers[PWR_OPERATE_LAB].cooldown == 0 && labToUsePower && Memory.synthesis[startRoom] && (Memory.synthesis[startRoom].status == "active" || Memory.synthesis[startRoom].status == "waiting") ) {
                const allLabs = Memory.gl_var.myRooms[startRoom].labs
                // let inputLabs = []
                let outputLabs = []
                // console.log('hgffgh');
                
                if (allLabs.outputLabs) {
                    for (lab of allLabs.outputLabs) {
                        outputLabs.push(Game.getObjectById(lab.id))
                    }
                }
                
                for (lab of outputLabs) {
                    if (!lab.effects || !lab.effects[0]) {
                        if(pCreep.usePower(PWR_OPERATE_LAB, lab) == ERR_NOT_IN_RANGE) {
                            pCreep.moveTo(lab, {reusePath: 10, ignoreRoads: true});
                        }
                        break;
                    }
                }
            } else if (pCreep.powers[PWR_OPERATE_EXTENSION] && thisStorage && startRoomEnergyAvailable < startRoomEnergyCapacity * 0.9 && pCreep.powers[PWR_OPERATE_EXTENSION].cooldown == 0) {
                if(pCreep.usePower(PWR_OPERATE_EXTENSION, thisStorage) == ERR_NOT_IN_RANGE) {
                    pCreep.moveTo(thisStorage, {reusePath: 10, ignoreRoads: true});
                }
            } else {
                if (thisStorage) {
                    if (!pCreep.pos.inRangeTo(thisStorage, 6)) {
                        pCreep.moveTo(thisStorage, {reusePath: 10, ignoreRoads: true});
                    }
                }
            }
        } else if (pCreep.ticksToLive <= ticksToRenew) {
            const thisTerminal = pCreep.room.terminal
            if (thisTerminal && thisTerminal.store["ops"] < 10000 && pCreep.store["ops"] > 0) {
                if (pCreep.transfer(thisTerminal, "ops") == ERR_NOT_IN_RANGE) {
                    pCreep.moveTo(thisTerminal, {reusePath: 10, ignoreRoads: true});
                }
                // console.log(pCreep.transfer(thisTerminal, "ops"));
            } else {
                powerSpawn = Game.getObjectById(Memory.gl_var.myRooms[startRoom].structures.powerSpawn[0].id)
                if (powerSpawn) {
                    if (pCreep.renew(powerSpawn) == ERR_NOT_IN_RANGE) {
                        pCreep.moveTo(powerSpawn, {reusePath: 10, ignoreRoads: true})
                    }
                }
            }
        }
        
        // else {
        //     if (Memory.gl_var.myRooms[startRoom].structures.powerSpawn) {
        //         const powerSpawn = Game.getObjectById(Memory.gl_var.myRooms[startRoom].structures.powerSpawn[0].id) 
        //         if (!pCreep.pos.isNearTo(powerSpawn)) {
        //             pCreep.moveTo(powerSpawn, {reusePath: 15});
        //         }
        //     }
        // }
        
        
        // if (needPowerSource && pCreep.powers[PWR_GENERATE_OPS] && pCreep.powers[PWR_GENERATE_OPS].cooldown == 0) {
        //     pCreep.usePower(PWR_GENERATE_OPS)
        //     console.log(pCreep.usePower(PWR_GENERATE_OPS));
        // }        
        
        // pCreep.move(TOP)
        
    }
};

module.exports = rolePowerCreep;
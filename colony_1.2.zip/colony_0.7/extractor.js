
var roleExtractor = {

    run: function(creep, roomsStructures, creepFuncs) {
        creep.say("☢️");
        
        const myStorage = creep.room.storage
        const myTerminal = creep.room.terminal
        
        if (!creep.memory.mineralId) { 
            creep.memory.mineralId = Memory.gl_var.myRooms[creep.room.name].sciense.mineral.mineralId
        }
        
        if (!creep.memory.mineralType) { 
            creep.memory.mineralType = Memory.gl_var.myRooms[creep.room.name].sciense.mineral.mineralType
        }
    
        
        if (!creep.memory.extractorId) { 
            creep.memory.extractorId = Memory.gl_var.myRooms[creep.room.name].structures.extractor[0].id
        }
        
        if (!creep.memory.fullMax || creep.ticksToLive == 1450) { 
            let oneMine = 1
            if (creep.memory.boosted) {
                oneMine = 3
            }
            mining_parts = creep.getActiveBodyparts(WORK);
            creep.memory.fullMax = (creep.store.getCapacity() - (mining_parts*oneMine)) + 1
        }
        
        if (creep.store.getUsedCapacity() >= creep.memory.fullMax) {creep.memory.full = true;}
        if (creep.store.getFreeCapacity() == creep.carryCapacity) {creep.memory.full = false;}
                
        const mineral = Game.getObjectById(creep.memory.mineralId)
        const extractor = Game.getObjectById(creep.memory.extractorId)
        const myMineralType = creep.memory.mineralType
        
        let boostLab = null
        if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
            boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
        }
        
        
        if (!creep.memory.needToBoost && creep.memory.needToBoost != false) {
            let needToBoost = false
            if (Game.rooms[creep.memory.startRoom].controller.level >= 7 || Memory.gl_var.myRooms[creep.memory.startRoom].sciense.mineral.mineralType == "U") {
                needToBoost = true
            }
            creep.memory.needToBoost = needToBoost
        }
        
        if (creep.memory.needToBoost) {
            creepFuncs.boostCreep(creep, boostLab)
        }
        
        if (creep.ticksToLive > 50) {
            if (creep.memory.needToBoost == false) {
                if (!creep.memory.full) {
                    if (!creep.pos.isNearTo(mineral)) {
                        creep.moveTo(mineral, {reusePath: 15});
                    } else if (extractor && extractor.cooldown == 0) {
                        creep.harvest(mineral)
                    }
                } else if (creep.memory.full ) {
                    if (myTerminal && myTerminal.store.getFreeCapacity() > 10000) {
                        if(creep.transfer(myTerminal, myMineralType) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(myTerminal, {reusePath: 15});
                        }
                    } 
                    // else {
                    //     if (myStorage && myStorage.store[my_mineral_type] < 300000) {
                    //         if(creep.transfer(myStorage, my_mineral_type) == ERR_NOT_IN_RANGE) {
                    //             creep.moveTo(myStorage);
                    //         }
                    //     }
                    // }
                } 
            }
        } else {
            if (creep.store[myMineralType] > 0 ) {
                if (myTerminal) {
                    if(creep.transfer(myTerminal, myMineralType) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(myTerminal, {reusePath: 15});
                    }
                } else {
                    if (myStorage && myStorage.store[myMineralType] < 300000) {
                        if(creep.transfer(myStorage, myMineralType) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(myStorage, {reusePath: 15});
                        }
                    }
                }
            } else {
                creep.suicide();
            }
        }
        
    } 
         
        
}

module.exports = roleExtractor;
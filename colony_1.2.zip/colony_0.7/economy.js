//Game.market.getAllOrders видимо тратит 3-4 cpu, так что надо юзать сразу для всех товаров 
//1 крип (10W 10C 10M) = 2000 energy = 800cr (по 0.4). Он добывает 2к-2.2к минерала => если минерал стоит больше 0.4 или энергия стоит меньше 0.4, то продавать выгодно 
//не продавать "U" (нужно для добычи)
module.exports.marketLogic = function marketLogic(constants) {
    
    if (Game.time % 10000 == 0) { //раз в 10 часов примерно собирать статистику
        this.checkPriceHistory()
    }
    
    if (Game.time % 300 == 0) { //раз в 15 минут распределять ресурсы
        this.deliveryToAllTerminals(constants) 
    }
    
    if (Game.time % 1000 == 250) { //раз в 1 час (другое время) закупать недостающие ресурсы
        // this.buyMissingResources(constants) //почему-то закупал L
    }
    
    
    // const cpu1 = Game.cpu.getUsed()
    if (Game.time % 200 == 0) {
        // this.buyPixels() //очень затратная функция (видимо при скане всех ордеров)
    }
    // console.log((Game.cpu.getUsed() - cpu1).toFixed(2));
    
    if (Game.time % 500 == 10) { //продать 174 cirquit
        this.sellCirquit(constants) 
    }
}

module.exports.checkPriceHistory = function checkPriceHistory() {
    
    // const cpu1 = Game.cpu.getUsed()
    let allMinerals = Object.keys(MINERAL_MIN_AMOUNT) // H,O,L,K,Z,U,X
    const moreGoods = ["pixel", "energy", "power", "GO", "G", "OH"]
    const allGoods = allMinerals.concat(moreGoods)
    const maxPrices = {
        pixel: 2300,
        energy: 0.7,
    }
    
    let marketPricesStats = {}
    marketPricesStats.allGoods = {}
    
    
    for (let g in allGoods) {
        const good = allGoods[g]
        let avgPrice = 0
        let history = Game.market.getHistory(good)
        const daysOfAvgPrice = 7
        let day = 0
        let dayOfStatistic = history.length - 1
        while (day < daysOfAvgPrice) {
            avgPrice += history[dayOfStatistic].avgPrice
            dayOfStatistic--
            day++
        }
        avgPrice /= 7
        if (maxPrices[good] && maxPrices[good] < avgPrice) {
            // console.log(`${good}: OVERPRICE (${good}: ${maxPrices[good]} ${avgPrice})`);
            
            // marketPricesStats[good] = { // запись
            //     avgPrice: null
            // }
        } else {
            // console.log(`${good}: ${avgPrice.toFixed(2)}`);
            
            // marketPricesStats[good] = { // запись
            //     avgPrice: avgPrice.toFixed(3)
            // }
            marketPricesStats.allGoods[good] = avgPrice.toFixed(3) 
        }
    }
    
    
    Memory.marketStats = {}
    if (!Memory.marketStats) {
        Memory.marketStats = {}
    }
    
    Memory.marketStats.prices = marketPricesStats
    
    
}

module.exports.buyPixels = function buyPixels() {
    
    const pixelsLowPrice = 1700
    const pixelsAvgPrice = 2000
    const lowestCreditAmount = 180000000
    
    if (Game.market.credits > lowestCreditAmount) {
        currentOffers = Game.market.getAllOrders(order => order.resourceType == "pixel" &&
        order.type == ORDER_SELL)
        bestOrder = _.min(currentOffers, 'price')
        if (bestOrder.price < pixelsAvgPrice) { //пока поставил pixelsAvgPrice потом надо Low
            // console.log(bestOrder.price);
            console.log(`SALE! (pixel: ${bestOrder.price.toFixed(2)})`);
        } else {
            // console.log(`дорого (pixel: ${bestOrder.price.toFixed(2)})`);
        }
    }
    
}

module.exports.deliveryToAllTerminals = function deliveryToAllTerminals(constants) {
    
    //куда будет направляться помощь (если отправлен хоть один ресурес, то будет удален до следующего цикла)
    let targetRooms = Object.keys(Memory.gl_var.myRooms) 
    
    //откуда брать
    const fromRooms = Object.keys(Memory.gl_var.myRooms) 
    
    for (let room of fromRooms) { // откуда
        if (Game.rooms[room].terminal) {
            const resourses = Object.keys(Game.rooms[room].terminal.store) // все что есть в данной комнате
            const thisMineral = Memory.gl_var.myRooms[room].sciense.mineral.mineralType
            // console.log(thisMineral);
            for (let resourse of resourses) { //проход по всем ресам этой комнаты
                //🔆🔆🔆  энергия
                if (resourse == "energy") { 
                    if (Game.rooms[room].terminal.store["energy"] >= constants.economyThresholds.energyTerminalMax && Game.rooms[room].controller.level === 8) {
                        for (let targetRoom of targetRooms) {
                            if (targetRoom !== "W42N28" && targetRoom !== "W49N26" && Game.rooms[targetRoom].terminal && Game.rooms[targetRoom].controller.level <= 7 && Game.rooms[targetRoom].terminal.store[resourse] < constants.economyThresholds.energyTerminalMin + 1000 && Game.rooms[targetRoom].storage && Game.rooms[targetRoom].storage.store["energy"] < 160000) {
                                const requiredAmount = constants.economyThresholds.energyTerminalMax - constants.economyThresholds.energyTerminalMin
                                if (Game.rooms[room].terminal.cooldown == 0) {
                                    Game.rooms[room].terminal.send(resourse, requiredAmount, targetRoom)
                                    // console.log(room, resourse, requiredAmount, targetRoom);
                                }
                                //удаление из массива куда отправлять
                                const index = targetRooms.indexOf(targetRoom)
                                targetRooms.splice(index, 1) //удаление целевой комнаты, чтобы 2 раза за тик не отправить одно и то же
                                break;  
                            }
                        }
                    }
                // 💠💠💠 главный ресурс этой комнаты
                } else if (resourse == thisMineral && Game.rooms[room].terminal.store[resourse] > constants.economyThresholds.myMineralMin) { 
                    // console.log(thisMineral, Game.rooms[room].terminal.store[resourse]);
                    for (let targetRoom of targetRooms) {
                        if (targetRoom !== "W42N28" && targetRoom !== "W49N26" && Game.rooms[targetRoom].terminal && Game.rooms[targetRoom].terminal.store[resourse] < constants.economyThresholds.otherMineralNeed - 1500) {
                            
                            //проверяем сколько надо отправить
                            const requiredAmount = constants.economyThresholds.otherMineralNeed - Game.rooms[targetRoom].terminal.store[resourse]
                            // console.log(targetRoom, resourse, Game.rooms[targetRoom].terminal.store[resourse] );
                            
                            //тут отправка
                            // console.log(room, '->', targetRoom, resourse, requiredAmount);
                            if (Game.rooms[room].terminal.cooldown == 0) {
                                Game.rooms[room].terminal.send(resourse, requiredAmount, targetRoom)
                            }
                            //удаление из массива куда отправлять
                            const index = targetRooms.indexOf(targetRoom)
                            targetRooms.splice(index, 1) //удаление целевой комнаты, чтобы 2 раза за тик не отправить одно и то же
                            break;   
                            // console.log(Game.market.calcTransactionCost(5000, room, targetRoom));
                            
                        }
                    }
                // ♻️♻️♻️  остальные ресурсы   (бусты)
                } else if (resourse != "ops" && resourse != "UL" && resourse != "ZK" && resourse != "GO" && (resourse.length > 1 || resourse == "G") && Game.rooms[room].terminal.store[resourse] >= constants.economyThresholds.boostsAmountMax) { //но не вручную купленные U, L..
                    for (let targetRoom of targetRooms) {
                        if (targetRoom !== "W42N28" && targetRoom !== "W49N26" && Game.rooms[targetRoom].terminal && Game.rooms[targetRoom].terminal.store[resourse] < constants.economyThresholds.boostsAmountNeed - 1500) {
                            const requiredAmount = constants.economyThresholds.boostsAmountNeed - Game.rooms[targetRoom].terminal.store[resourse]
                            
                            if (Game.rooms[room].terminal.cooldown == 0) {
                                Game.rooms[room].terminal.send(resourse, requiredAmount, targetRoom)
                            }
                            //удаление из массива куда отправлять
                            const index = targetRooms.indexOf(targetRoom)
                            targetRooms.splice(index, 1) //удаление целевой комнаты, чтобы 2 раза за тик не отправить одно и то же
                            break;  
                            
                        }
                    }
                }
            }
            
        }
    }
}

module.exports.buyMissingResources = function buyMissingResources(constants) {
    const maxMineralPrice = 1
    
    let allMinerals = Object.keys(MINERAL_MIN_AMOUNT) // H,O,L,K,Z,U,X для последующего удаления
    const fromRooms = Object.keys(Memory.gl_var.myRooms)
    
    for (let room of fromRooms) {
        if (Game.rooms[room].terminal) { //удалить из списка существующие минералы
            const index = allMinerals.indexOf(Memory.gl_var.myRooms[room].sciense.mineral.mineralType)
            if (index != -1) {
                allMinerals.splice(index, 1)
            }
        }
    }
    //найдены все ресы которые не добываются 
    
    //запоминание цен
    let missingResourcesOrders = {}
    for (let resource of allMinerals) { //проход по оставшимся
        const thisAvgPrice = Memory.marketStats.prices.allGoods[resource]
        let currentResourceOrders = Game.market.getAllOrders({type: ORDER_SELL, resourceType: resource}) //все ордеры на данный ресурс
        if (currentResourceOrders.length) { //если ордеры есть
            currentResourceOrders.sort( (a,b) => a.price - b.price ) //сортировка по цене
            
            finalPricesArray = []
            const maxOrdersCheck = 10
            for (let i = 0; i <= maxOrdersCheck && currentResourceOrders[i]; i++) {
                if (currentResourceOrders[i].price < thisAvgPrice * 1.7) { //отсеивание супердорогих предложений
                    finalPricesArray.push(currentResourceOrders[i]) 
                }
                //createdTimestamp,type,amount,remainingAmount,resourceType,price,roomName,created,id
                    
            }
            
            missingResourcesOrders[resource] = finalPricesArray
            // console.log(finalPricesArray);
        }
    }
    
    //проход по румам и покупка
    
    if (missingResourcesOrders && Object.keys(missingResourcesOrders)[0] ) {
        this.buyResource(constants, fromRooms, missingResourcesOrders, allMinerals)
    }
    
    
    // console.log("--------------");    
}


module.exports.buyResource = function buyResources(constants, myRooms, missingResourcesOrders, missingMinerals) {
    
    for (let room of myRooms) { //комнаты
        if (Game.rooms[room].terminal) { //в которых есть терминал
            for (let missingResourse of missingMinerals) { //проход по ресурсам
                const amount = constants.economyThresholds.otherMineralNeed - Game.rooms[room].terminal.store[missingResourse]
                if (Game.rooms[room].terminal.store[missingResourse] < constants.economyThresholds.otherMineralNeed) { //если мало этого ресурса
                    //выбор ордера
                    let ordersFinalPricesArray = []
                    for (let order of missingResourcesOrders[missingResourse]) {
                        const transactionCost = Game.market.calcTransactionCost(amount, room, order.roomName)
                        let thisPrice = order.price * amount + transactionCost
                        // console.log(amount, Game.market.calcTransactionCost(amount, room, order.roomName));
                        // console.log(order.price * amount,' + ', transactionCost,' = ', thisPrice );
                        ordersFinalPricesArray.push(thisPrice)
                    }
                    //сортировка по итоговой цене
                    const bestFinalOrder = ordersFinalPricesArray.sort((a,b) => a - b)[0]
                    const bestIndexOrder = ordersFinalPricesArray.indexOf(bestFinalOrder)
                    // console.log(missingResourcesOrders[missingResourse][bestIndexOrder].price)
                    //покупка комнатой
                    const selectedOrder = missingResourcesOrders[missingResourse][bestIndexOrder]
                    if (selectedOrder) {
                        Game.market.deal(selectedOrder.id, amount, room)
                    }
                    // console.log(amount, room, missingResourse);
                    return
                }
            }
        } 
    }
}

module.exports.sellCirquit = function sellCirquit(constants) {
    room = "W43N41"
    myTerminal = Game.getObjectById("613b79cd265c444125d36993")
    thisOrders = Game.market.getAllOrders({type: ORDER_BUY, resourceType: "circuit"});
    // console.log(orders[0]);
    if (thisOrders.length && myTerminal.store['circuit'] > 0) {
        bestOrder = _.max(thisOrders, 'price')
        if (bestOrder.price > 325000) {
            // console.log(Game.market.deal(bestOrder.id, 1, room));
            Game.market.deal(bestOrder.id, 1, room)
        }
    }
    
    
}



    // economyThresholds: {
    //     energyTerminalMin: 20000,
    //     energyTerminalMax: 40000,
    //     myMineralMin: 30000,
    //     myMineralMax: 60000,
    //     otherMineralNeed: 5000,
    //     boostsAmountNeed: 5000,

module.exports.obsMain = function obsMain() {
    //константы (из каких комнат и куда сканить)
    roomsFromScan = ["W49N34"]
    roomsToScan = {
        W45N41: ["W50N40","W49N40","W48N40","W47N40","W46N40","W45N40","W44N40","W43N40","W42N40","W41N40","W40N40"],
    }
    roomsExits = ["W50N34"]
    //скан корридоров
    
    if (!Memory.obsInfo) {
        Memory.obsInfo = {}
    }
    
    // Memory.obsInfo["W49N34"].status = "idle"
    let foundPower = false
    for (let room in Memory.obsInfo) {
        if (room && Memory.obsInfo[room] && Memory.obsInfo[room].status != "idle") {
            foundPower = true
        }
    }
    
    if (Game.cpu.bucket > 9200 && !foundPower) {
        this.obsScan(roomsToScan)
    }
};

module.exports.obsScan = function obsScan(roomsToScan) {
        const maxRooms = 15
        const timerInterval = 101 //Лучше нечетное до 300
        const i = Game.time % timerInterval
        if (Game.time % timerInterval < maxRooms) { //скан от observer
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                    const isMy = Game.rooms[fromRoom] && Game.rooms[fromRoom].controller.my 
                    if (isMy && Game.rooms[fromRoom].controller.level == 8 && Memory.gl_var.myRooms[fromRoom].structures.observer) {
                        const observer = Game.getObjectById(Memory.gl_var.myRooms[fromRoom].structures.observer[0].id)
                        const targetRoom = roomsToScan[fromRoom][i]
                        // const targetRoom = "W50N28"
                        observer.observeRoom(targetRoom)
                    }
                }
            }
        }
        
    if (Memory.gl_var.gl_i != 1) { //на случай сохранений 
        if (Game.time % timerInterval > 0 && Game.time % timerInterval < maxRooms + 1) { //скан комнаты на предметы (следующий тик)
            const prevI = (Game.time % timerInterval) - 1
            const i = Game.time % timerInterval
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                    const targetRoom = roomsToScan[fromRoom][i-1]
                    if (targetRoom && Game.rooms[targetRoom]) {
                        const powerBank = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "powerBank"}})[0]
                        //powerBank.hits == powerBank.hitsMax && нет Walls (на случай respawn area)
                        if (powerBank && powerBank.hits == powerBank.hitsMax) { //если нашел powerBank 
                        
                            const powerAmount = powerBank.power
                            const powerAmountNeed = 4400
                            const timeToDecay = powerBank.ticksToDecay
                            const timeToDecayNeed = 2250
                            const carryersNeed = Math.trunc(powerAmount / 1250) + 1    
                            const distance = Game.map.getRoomLinearDistance(fromRoom, targetRoom) + 1
                            const carryComeTime = distance * 50 + 175 * (Math.trunc(carryersNeed / 3) + 1)
                            
                            let freeSpots = 0
                            const targetX = powerBank.pos.x
                            const targetY = powerBank.pos.y
                            
                            const thisTerminal = Game.rooms[fromRoom].terminal 
                            const haveBoosts = thisTerminal && thisTerminal.store["LO"] > 2000
                            
                            const thisStorage = Game.rooms[fromRoom].storage 
                            const haveEnergy = thisStorage && thisStorage.store["energy"] > 50000
                            // if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
                            //     boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
                            // }
                            
                            if (haveBoosts && powerAmount > powerAmountNeed && timeToDecay > timeToDecayNeed) {
                                const lookTerrain = Game.rooms[targetRoom].lookAtArea(targetY-1, targetX-1, targetY+1, targetX+1, {asArray: true})
                                for (let i = 1; i <= 9; i++) {
                                    if (lookTerrain[i].terrain == "plain") {
                                        freeSpots++
                                    }
                                }
                                if (freeSpots >= 3) { //финальная проверка
                                    const flagAttackerName = `${fromRoom}_powerAttacker_3_${targetRoom}`
                                    const flagHealerName = `${fromRoom}_powerHealer_3_${targetRoom}`
                                    const flagCarryerName = `${fromRoom}_powerCarryer_${carryersNeed}_${targetRoom}`
                                    Memory.obsInfo[fromRoom] = {
                                        status: "active",
                                        targetRoom: targetRoom,
                                        amount: powerAmount,
                                        powerId: powerBank.id,
                                        carryersNeed: carryersNeed,
                                        freeSpots: freeSpots,
                                        distance: distance,
                                        carryComeTime: carryComeTime,
                                        time: Game.time,
                                        flags: {
                                          attackersFlag: flagAttackerName,
                                          healerFlag: flagHealerName,
                                          carryerFlag: flagCarryerName,
                                        },
                                            
                                    }
                                    
                                    Game.rooms[targetRoom].createFlag(25, 25, flagAttackerName)
                                    Game.rooms[targetRoom].createFlag(25, 25, flagHealerName)
                                    console.log(flagAttackerName);
                                    break; //если нашел из какой-то румы, то все
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
};


module.exports.obsScanInfo = function obsScanInfo(roomsToScan) {
        const maxRooms = 13
        const timerInterval = 101 //Лучше нечетное до 300
        const i = Game.time % timerInterval
        if (Game.time % timerInterval < maxRooms) { //скан от observer
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                    const isMy = Game.rooms[fromRoom] && Game.rooms[fromRoom].controller.my 
                    if (isMy && Game.rooms[fromRoom].controller.level == 8 && Memory.gl_var.myRooms[fromRoom].structures.observer) {
                        const observer = Game.getObjectById(Memory.gl_var.myRooms[fromRoom].structures.observer[0].id)
                        const targetRoom = roomsToScan[fromRoom][i]
                        // const targetRoom = "W50N28"
                        observer.observeRoom(targetRoom)
                    }
                }
            }
        }
        
    if (Memory.gl_var.gl_i != 1) { //на случай сохранений 
        if (Game.time % timerInterval > 0 && Game.time % timerInterval < maxRooms + 1) { //скан комнаты на предметы (следующий тик)
            const prevI = (Game.time % timerInterval) - 1
            const i = Game.time % timerInterval
            for (let fromRoom of Object.keys(roomsToScan)) {
                if (!Memory.obsInfo[fromRoom] || (Memory.obsInfo[fromRoom] && Memory.obsInfo[fromRoom].status == "idle") ) {
                    const targetRoom = roomsToScan[fromRoom][i-1]
                    if (targetRoom) {
                        const powerBank = Game.rooms[targetRoom].find(FIND_STRUCTURES, {filter: {structureType: "powerBank"}})[0]
                        if (powerBank) { //если нашел powerBank
                        
                            const powerAmount = powerBank.power
                            const powerAmountNeed = 4000
                            const timeToDecay = powerBank.ticksToDecay
                            const timeToDecayNeed = 3000
                            const carryersNeed = Math.trunc(powerAmount / 1250) + 1    
                            const distance = Game.map.getRoomLinearDistance(fromRoom, targetRoom) + 1
                            const carryComeTime = distance * 50 + 175 * (Math.trunc(carryersNeed / 3) + 1)
                            
                            let freeSpots = 0
                            const targetX = powerBank.pos.x
                            const targetY = powerBank.pos.y
                            
                            const thisTerminal = Game.rooms[fromRoom].terminal 
                            const haveBoosts = thisTerminal && thisTerminal.store["LO"] > 2000
                            
                            const thisStorage = Game.rooms[fromRoom].storage 
                            const haveEnergy = thisStorage && thisStorage.store["energy"] > 50000
                            // if (Memory.gl_var.myRooms[creep.memory.startRoom].labs && Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab) {
                            //     boostLab = Game.getObjectById(Memory.gl_var.myRooms[creep.memory.startRoom].labs.boostLab.id)
                            // }
                            
                            if (haveBoosts && powerAmount > powerAmountNeed && timeToDecay > timeToDecayNeed) {
                                const lookTerrain = Game.rooms[targetRoom].lookAtArea(targetY-1, targetX-1, targetY+1, targetX+1, {asArray: true})
                                for (let i = 1; i <= 9; i++) {
                                    if (lookTerrain[i].terrain == "plain") {
                                        freeSpots++
                                    }
                                }
                                if (freeSpots >= 3) { //финальная проверка
                                    console.log(`${targetRoom} - power`);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
};



funcs = require("funcs");

var roleAttacker = {

    run: function(creep, roomsStructures, creepFuncs) {
        
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        let targetPos = null
        let targetRoom = null 
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499) {
                creep.memory.targetRoomMem = targetRoom
            }
        }
        
        if (Game.cpu.bucket > 1000) {
            if (creep.memory.targetRoomMem && creep.pos.roomName != creep.memory.targetRoomMem) {
                creepFuncs.myRoutes(creep, creep.memory.targetRoomMem)
                creep.say("🥾⚔️");
            } else {
                creep.say("⚔️");
                
                const enemy_creeps_near = creep.pos.findInRange(FIND_HOSTILE_CREEPS, 3);
                const enemy_build = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType != "controller" 
                                && i.structureType != "storage" 
                                && i.structureType != "terminal" 
                                && i.structureType != "factory" 
                });
                const enemy_tower = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "tower" 
                                // && i.structureType != "rampart" 
                });
                const enemy_spawn = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "spawn" 
                                // && i.structureType != "rampart" 
                });
                const invaderCore = creep.pos.findClosestByRange(FIND_HOSTILE_STRUCTURES, {
                    filter: (i) => i.structureType == "invaderCore" 
                                // && i.structureType != "rampart" 
                });
                const target_by_id = Game.getObjectById("5fc6eb74d1b2cc0a421e8a8c")
                
                const walls = creep.pos.findClosestByRange(FIND_STRUCTURES,
                    {filter: {structureType: STRUCTURE_WALL}});
                    
                const container = null
                
                const enemy_creeps = creep.pos.findClosestByRange(FIND_HOSTILE_CREEPS);
                let rangeCreep = null
                if (enemy_creeps) {
                    if(creep.attack(enemy_creeps) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_creeps)) {
                            creep.moveTo(enemy_creeps);
                        }
                    }
                } else
                if (target_by_id) {
                    creep.say("⚔️i");
                    if(creep.attack(target_by_id) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(target_by_id)) {
                            creep.moveTo(target_by_id);
                        }
                    }
                } else 
                if (invaderCore) {
                    creep.say("⚔️i");
                    if(creep.attack(invaderCore) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(invaderCore)) {
                            creep.moveTo(invaderCore);
                        }
                    }
                } else 
                if (enemy_creeps_near[0] && rangeCreep < 23) {
                    creep.say("⚔️C");
                    if(creep.attack(enemy_creeps_near[0]) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_creeps_near[0])) {
                            creep.moveTo(enemy_creeps_near[0]);
                        }
                    }
                } else 
                if (enemy_spawn) {
                    creep.say("⚔️S");
                    if(creep.attack(enemy_spawn) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_spawn)) {
                            creep.moveTo(enemy_spawn);
                        }
                    } 
                } 
                // else if (enemy_tower) {
                //     creep.say("⚔️T");
                //     if(creep.attack(enemy_tower) == ERR_NOT_IN_RANGE) {
                //         if (!creep.pos.isNearTo(enemy_tower)) {
                //             creep.moveTo(enemy_tower);
                //         }
                //     } 
                // } 
                else if (enemy_build) {
                    creep.say("⚔️B");
                    if(creep.attack(enemy_build) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_build)) {
                            creep.moveTo(enemy_build);
                        }
                    } 
                } 
                else if (enemy_creeps && rangeCreep < 23 && enemy_creeps.owner.username != "hattu") {
                    creep.say("⚔️c");
                    // console.log(rangeCreep, enemy_creeps.pos.x, enemy_creeps.pos.y);
                    if(creep.attack(enemy_creeps) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(enemy_creeps)) {
                            creep.moveTo(enemy_creeps);
                        }
                    } 
                } else if (container) {
                    creep.say("⚔️");
                    if(creep.attack(container) == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(container)) {
                            creep.moveTo(container);
                        }
                    } 
                } else {
                    creep.say("👀");
                    if (targetPos && targetPos.x) {
                        if (!creep.pos.inRangeTo(targetPos.x, targetPos.y, 3)) {
                            creep.moveTo(targetPos.x, targetPos.y);
                        }
                    } else {
                        if (!creep.pos.inRangeTo(25, 25, 10)) {
                            creep.moveTo(25, 25);
                        }
                    }
                }
                // creep.moveTo(17, 37, {visualizePathStyle:{fill: 'transparent',stroke: '#fff',lineStyle: 'dashed',strokeWidth: .15,opacity: .1}})
                // creepFuncs.moveFromEdge(creep)
            }
        }
        
        
            
        
        // --attacker logic end--
        
    }
};

module.exports = roleAttacker;
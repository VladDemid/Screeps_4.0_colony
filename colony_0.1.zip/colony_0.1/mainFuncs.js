starter = require("starter");
defender = require("defender");
miner = require("miner");
upgrader = require("upgrader");

module.exports.rolesCountZeroing = function rolesCountZeroing() {
    for (let key in Memory.gl_var.myRooms) {
        Memory.gl_var.myRooms[key].screepsCounts = {}
        Memory.gl_var.myRooms[key].screepsCounts.total = 0
        for (let role of Memory.constants.roles) {
            Memory.gl_var.myRooms[key].screepsCounts[role] = 0
        }
    }
    // Memory.constants.triggers.countsZeroing = 1
};

module.exports.checkHealth = function checkHealth(creep) {
    // console.log(creep.hits, creep.hitsMax);
    if (creep.hits < creep.hitsMax) {
        const room = creep.memory.startRoom
        const creepToHeal = {
                creepName: creep.name,
                creepRoom: creep.room.name, //где сейчас
            }
        Memory.gl_var.myRooms[room].needHeal = creepToHeal
        // console.log(Memory.gl_var.myRooms[room].needHeal);
    }
};

module.exports.activateCreep = function activateCreep(creep, roomsStructures) {
    this.checkHealth(creep)
    Memory.gl_var.myRooms[creep.memory.startRoom].screepsCounts.total++;
    eval(creep.memory.role).run(creep, roomsStructures, creepFuncs)
    // starter.run(creep)
};







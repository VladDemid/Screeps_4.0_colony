/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('creepFuncs');
 * mod.thing == 'a thing'; // true
 */

module.exports.transferCreep = function (creep) {
    creep.say("123")
};


module.exports.isOdd = function isOdd(num) { // возвращает 0 если четное, 1 если нечетное
    return num % 2
}

module.exports.travel = function travel(creep, target_room) {
    const route = Game.map.findRoute(creep.room, target_room);
    if(route.length > 0) {
        const exit = creep.pos.findClosestByRange(route[0].exit);
        creep.moveTo(exit);
    }    
}
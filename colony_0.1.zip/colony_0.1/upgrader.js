// creepFuncs = require("creepFuncs")

var construction;
// когда 4 link`а, один поставить к контроллеру и держать там крипов
var roleUpgrader = {

    run: function(creep, roomsStructures, creepFuncs) {
        myStorage = null
        // --starter logic start--
        const myController = creep.room.controller
        const containers = Memory.gl_var.myRooms[creep.room.name]["containers"]
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        
        // const ticksToSaveController = 2000
        const energyContainerReservation = 500 //оставить для остальных важных процессов
        
        
        
        
        creep.say("🔋");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        // var sources = creep.room.find(FIND_SOURCES);
        
        if (!creep.memory.full) {
            if (myStorage && spawning_lvl >= 4) {
                if (myStorage.store["energy"] > 20000) {
                    if(creep.withdraw(myStorage, "energy") == ERR_NOT_IN_RANGE) {
                        if (!creep.pos.isNearTo(myStorage)) {
                            creep.moveTo(myStorage, {reusePath: 10});
                        } 
                    }
                }
            } else {
                
                creepIndex = creep.name.split('_')[2] - 1
                const dest = creepFuncs.isOdd(creepIndex)
                // console.log(creep.name, dest_mining);
                let targetContainer = null
                if (containers && containers.length == 2) {
                    targetContainer = Game.getObjectById(containers[dest].id)
                }
                
                // var target_container;
                // if (containers_mass[creep.name.split('Upgrader')[1]-1]) {
                //     target_container = containers_mass[creep.name.split('Upgrader')[1]-1];
                // } else {
                //     target_container = containers_mass[0];
                // }
                
                // if (creep.name.split('Upgrader')[1] >= 3) {
                //     if (creep.name.split('Upgrader')[1] % 2 == 0) {
                //         target_container = containers_mass[0];
                //     } else {
                //         target_container = containers_mass[containers_mass.length - 1];
                //     }
                // }
                
                if (targetContainer) {
                    if (targetContainer.store["energy"] >= energyContainerReservation) {
                        if(creep.withdraw(targetContainer, "energy") == ERR_NOT_IN_RANGE) {
                            if (!creep.pos.isNearTo(targetContainer)) {
                                creep.moveTo(targetContainer);
                            } 
                        }
                    } else {
                        if (!creep.pos.isNearTo(targetContainer)) {
                            creep.moveTo(targetContainer);
                        }
                    }
                } else {
                    // var sources = creep.room.find(FIND_SOURCES);
                    
                    const creepIndex = creep.name.split('_')[2] - 1
                    const dest_mining = creepFuncs.isOdd(creepIndex)
                    const  target_source = sources[dest_mining];
                    
                    
                    if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(target_source);
                    }
                }
            }
            
                
        } else if (creep.memory.full) {
            // creep.repair(Game.getObjectById("60cad343beaaeb595ec8cc16"))
            if (Game.time % 20 == 0) {
                construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                if (construction) {
                    creep.memory.building = 1;
                } else { creep.memory.building = 0; }
            }
            // console.log(my_controller);
            
            if (creep.memory.building) {
                const newConstruction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                // console.log(creep.name, " building", construction);
                if(creep.build(newConstruction) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(newConstruction);
                }
            } else if (myController.level < 8 || myController.ticksToDowngrade < 199000) {
                if (creep.upgradeController(myController) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(myController, {reusePath: 10});
                }
            }
        }
        // --starter logic end--
        
    }
};

module.exports = roleUpgrader;
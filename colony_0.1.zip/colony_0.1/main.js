constants = require("constants")
mainFuncs = require("mainFuncs")
population = require("population")
flagsFuncs = require("flags")
creepFuncs = require("creepFuncs")
roleTower = require("tower")



Memory.gl_var = {
    gl_i: 0, //глобальный счетчик
    myRooms: {}
    
}

//каждый RoomVisual расходует 0.02 CPU

Memory.constants = constants
// Memory.compound_fusion = {}
// Memory.army = {}
// Memory.creeps = {}

let roomsStructures = {} // nameRoom->strName->Obj to use

module.exports.loop = function () {
    Memory.gl_var.creeps_number = 0
    Memory.gl_var.gl_i_max = 50
    Memory.gl_var.gl_i++
    
    const myRooms = Memory.gl_var.myRooms
    
    if (Memory.gl_var.gl_i > Memory.gl_var.gl_i_max) {Memory.gl_var.gl_i = 1}
    
    if (Memory.gl_var.gl_i == 1) {
        const myRooms = Game.rooms
        for (let key in myRooms) { // --ROOMS 1--
            if (Game.rooms[key].controller && Game.rooms[key].controller.my) {//мои комнаты с контроллером
                roomsStructures[key] = {} // для будущего наполнения зданиями и прямого использования крипами
                let roomObj = {} //объект в память gl_var->myRooms->...
                roomObj = {roomName: key}
                
                roomObj.structuresRaw = Game.rooms[key].find(FIND_MY_STRUCTURES) // найти все здания (0:.., 1:.., 2:..,)
                roomObj.structures = {} 
                
                for (str of roomObj.structuresRaw) { // --STRUCTURES-- сортировка зданий по типу
                
                    if (roomObj.structures[str.structureType]) { //наполнение зданий по комнатам в память
                        roomObj.structures[str.structureType].push(str)
                    } else {
                        roomObj.structures[str.structureType] = []
                        roomObj.structures[str.structureType].push(str)
                    }
                    
                    if (roomsStructures[key][str.structureType]) { //наполнение зданий по комнатам в прямой объект
                        roomsStructures[key][str.structureType].push(str)
                    } else {
                        roomsStructures[key][str.structureType] = []
                        roomsStructures[key][str.structureType].push(str)
                    }
                    // console.log(roomsStructures[key], key);
                }
                
                roomsStructures[key]["source"] = Game.rooms[key].find(FIND_SOURCES)
                
                
                roomObj.sources = roomsStructures[key]["source"]
                roomObj.constructionsSites = roomsStructures[key]["constructionsSites"]
                roomObj.containers = Game.rooms[key].find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTAINER}})
                
                
                // const sources = Game.rooms[my_rooms[i]].find(FIND_SOURCES)
                
                Memory.gl_var.myRooms[key] = roomObj
                
                Memory.gl_var.myRooms[key].enemyFound = false
                Memory.gl_var.myRooms[key].enemy = null //перейти на это
                
                roomsStructures[key].enemyFound = false
                roomsStructures[key].enemy = null // это убрать
                
                
                
            }
        }
        // Memory.gl_var.my_structures = Game.rooms[my_rooms[i]].find(FIND_MY_STRUCTURES)
        // console.log(Memory.gl_var.my_structures)
        // console.log(Game.rooms[0])
        const myFlags = Game.flags
        flagsFuncs.sortFlags(myFlags)
        
    }
    
    // const spawn1 = Game.getObjectById("60c93c4071e3e01e3b385a3d")
    // new RoomVisual("W49N34").text(`spawn: ${spawn1.store["energy"]} ${roomsStructures["W49N34"]["spawn"][0].energy}` , 25, 33, {color: "grey", font: 0.6, stroke: "black", strokeWidth: 0.1});
    
    for (let room in myRooms) { // --ROOMS 2--
        if (roomsStructures[room].extension.length > 0) {
            if (Game.rooms[room].energyAvailable < Game.rooms[room].energyCapacityAvailable) { // && roomsStructures[room].extension[0].store.getFreeCapacity("energy") == 0
                // обновление данных, т.к. объекты запоминаются не ссылками, а в моменте gl_i==1
                //проход по "extensions"
                for (let i in roomsStructures[room].extension) {
                    roomsStructures[room].extension[i] = Game.getObjectById(roomsStructures[room].extension[i].id)  
                }
                roomsStructures[room].extension.sort((a,b) => a.energy - b.energy);
                
                //проход по "spawns"
                for (let i in roomsStructures[room].spawn) {
                    roomsStructures[room].spawn[i] = Game.getObjectById(roomsStructures[room].spawn[i].id)  
                }
                roomsStructures[room].spawn.sort((a,b) => a.energy - b.energy);
                
            }
        }
        // проход по контейнерам
        for (let i in Memory.gl_var.myRooms[room].containers) {
            Memory.gl_var.myRooms[room].containers[i] = Game.getObjectById(Memory.gl_var.myRooms[room].containers[i].id)
        }
        Memory.gl_var.myRooms[room].containers.sort((a,b) => a.id - b.id);
        
        Memory.gl_var.myRooms[room].containersSorted = Memory.gl_var.myRooms[room].containers
        Memory.gl_var.myRooms[room].containersSorted.sort((a,b) => a.store["energy"] - b.store["energy"])
        
        //проход по стройкам
        //переделать (при постройке, хочет продолжать строить его, а уже такого объекта нет)
        //чекнуть сколько cpu когда нет строек
        roomsStructures[room]["constructionsSites"] = Game.rooms[room].find(FIND_MY_CONSTRUCTION_SITES)[0] 
        
        //турели
        const towers = Memory.gl_var.myRooms[room].structures.tower
        if (towers) {
            for (let tower in towers) {
                roleTower.run(towers[tower].id, tower)
            }
        }
        
        //запись прямого объекта в память для наглыдности
        Memory.roomsStructures = {}
        Memory.roomsStructures[room] = roomsStructures[room]
        
        
        if (Game.time % 2 == 0 || Memory.gl_var.myRooms[room].enemyFound == true) {
            const enemies = Game.rooms[room].find(FIND_HOSTILE_CREEPS)
            if (enemies && enemies.length > 0) {
                // console.log(enemy);
                roomsStructures[room].enemyFound = true
                roomsStructures[room].enemy = enemies[0]//это убрать
                
                Memory.gl_var.myRooms[room].enemyFound = true
                Memory.gl_var.myRooms[room].enemy = enemies[0]// это оставить
            } else {
                roomsStructures[room].enemyFound = false
                roomsStructures[room].enemy = null//это убрать
                
                Memory.gl_var.myRooms[room].enemyFound = false
                Memory.gl_var.myRooms[room].enemy = null// это оставить
            }
        }
        const containersSorted = Memory.gl_var.myRooms[room].containersSorted
        
        // !!--костыль--!!
        if (containersSorted && containersSorted[containersSorted.length - 1].store["energy"] > 1800) {
            // console.log(containersSorted[containersSorted.length - 1].store["energy"])
            Memory.constants.maxCreeps["2"].upgrader = 4
        } else {Memory.constants.maxCreeps["2"].upgrader = 2}
    }
    

    
    mainFuncs.rolesCountZeroing() //обнуление счетчиков в памяти
    
    for (var name in Game.creeps) { // ---CREEPS---
        const creepCpuStart = Game.cpu.getUsed()
        Memory.gl_var.creeps_number++
        const creep = Game.creeps[name]
        if (!creep.spawning) {
            Memory.gl_var.myRooms[creep.memory.startRoom].screepsCounts[creep.memory.role]++
            mainFuncs.activateCreep(creep, roomsStructures, creepFuncs)
        }
        const creepCpuEnd = Game.cpu.getUsed() - creepCpuStart
        new RoomVisual(creep.room.name).text(creepCpuEnd.toFixed(2) , creep.pos.x, creep.pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
    
    
    
    for (let room in myRooms) { // --ROOMS 3-- для спавна крипов
        const controllerLevel = Game.rooms[room].controller.level
        const spawnLevel = population.getSpawnLevel(room)
        // console.log(spawnLevel, room);
        const screepsCounts = Memory.gl_var.myRooms[room].screepsCounts
        for (let role in Memory.constants.maxCreeps[spawnLevel]) { //проход по необходимому максимуму крипов кажддой роли
            // console.log(role, Memory.constants.maxCreeps[controllerLevel][role]);
            if (Memory.constants.maxCreeps[spawnLevel][role] > screepsCounts[role]) {
                population.spawnCreep(room, role)
                break; //остановка на первом же нужном крипе
            }
        }
    }
    
    
    
    if (Game.cpu.bucket == 10000) {
        Game.cpu.generatePixel() 
        // console.log("generatePixel");
    }
}


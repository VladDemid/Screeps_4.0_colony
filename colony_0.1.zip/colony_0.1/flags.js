/*
 * Module code goes here. Use 'module.exports' to export things:
 * module.exports.thing = 'a thing';
 *
 * You can import it from another modules like this:
 * var mod = require('flags');
 * mod.thing == 'a thing'; // true
 */

module.exports.sortFlags = function sortFlags(flags) {
    for(let flag in flags) {
        // console.log(flag);
        if(flag == "def") {
            roomName = flags[flag].room.name;
            position = {
                x: flags[flag].pos.x,
                y: flags[flag].pos.y,
                roomName: flags[flag].room.name,
            }
            if (!Memory.gl_var.myRooms[roomName].positions) {
                Memory.gl_var.myRooms[roomName].positions = {}
            }
            Memory.gl_var.myRooms[roomName].positions.defence = position
        }
    }
}
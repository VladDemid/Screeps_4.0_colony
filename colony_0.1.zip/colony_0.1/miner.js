var dest_mining,
    mining_parts;

var roleMiner = {
//my_spawns, sources, link_to, link_from, laborant_max
    run: function(creep, roomsStructures) {
        // --starter logic start--
        function isOdd(num) { return num % 2;}
        
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        const link_to = false
        const link_from = false
        const laborant_max = 0
        
        creep.say("⛏");
        
        if (!creep.memory.fullMax || Game.time % 120 == 0) { // !!!!чекнуть!!!!
            mining_parts = creep.getActiveBodyparts(WORK);
            creep.memory.fullMax = creep.store.getCapacity() - mining_parts*2;
        }
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] > creep.memory.fullMax || creep.ticksToLive == 1) {
            creep.memory.full = true;
        } 
        
        
        // dest_mining = creep.name.split('Miner')[1] - 1;
        creepIndex = creep.name.split('_')[2] - 1
        const dest_mining = isOdd(creepIndex)
        
        
        if (!creep.memory.full) {
            if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[dest_mining]);
            }
        } else if (creep.memory.full) {
            // if (creep.name == "W49N34_miner_1") {
            //     creep.repair(Game.getObjectById('60cad343beaaeb595ec8cc16'))
            // } else {
            if (link_to && link_from.length >= 2 && laborant_max) {
                const near_link = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                    filter: (i) => i.structureType == STRUCTURE_LINK &&
                                  i.store[RESOURCE_ENERGY] < 800
                })[0];
                if (near_link) {
                    creep.transfer(near_link, "energy");
                }
            } else {
                const near_container = creep.pos.findInRange(FIND_STRUCTURES, 1, {
                    filter: (i) => i.structureType == STRUCTURE_CONTAINER &&
                                   i.store[RESOURCE_ENERGY] < 2000
                })[0];
                // console.log(near_container.pos);
                const building = creep.pos.findInRange(FIND_CONSTRUCTION_SITES, 1)[0];
                if (near_container) {
                    if (near_container.store["energy"] < 2000) {
                        creep.transfer(near_container, "energy");
                    } else if (near_container.hits < near_container.hitsMax) {
                        creep.repair(near_container)
                    }
                } else if (building) {
                    creep.build(building);
                } 
            }
            
                
            
            
        }
        
        // --starter logic end--
        
    }
};

module.exports = roleMiner;
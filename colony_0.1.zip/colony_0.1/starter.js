// creepFuncs = require("creepFuncs")

var roleStarter = {
    run: function(creep, roomsStructures, creepFuncs) {
        
        // function isOdd(num) { return num % 2;}
        // --starter logic start--
        const sources = roomsStructures[creep.memory.startRoom]["source"]
        const containers = Memory.gl_var.myRooms[creep.room.name]["containers"]
        const spawns = roomsStructures[creep.memory.startRoom]["spawn"]
        const spawn0 = Game.getObjectById(spawns[0].id) 
        const extensions = roomsStructures[creep.memory.startRoom]["extension"]
        const extension0 = Game.getObjectById(extensions[0].id)
        const constructionsSite = roomsStructures[creep.memory.startRoom]["constructionsSites"] // [0]
        const towers = Memory.gl_var.myRooms[creep.memory.startRoom].structures["tower"]
        const tower0 = Game.getObjectById(towers[0].id)
        // const construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES)
        // if (roomsStructures[creep.memory.startRoom]["constructionsSites"]) {
        //     const constructionsSites0id = Game.getObjectById(roomsStructures[creep.memory.startRoom]["constructionsSites"].id) 
        // //тут возможно была ошибка
        // }
        
        const ticksToSaveController = 2000
        const rebootTicks = 30
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest_mining = creepFuncs.isOdd(creepIndex)
        // console.log(creep.name, dest_mining);
        let dest_container = null
        if (containers && containers.length == 2) {
            dest_container = Game.getObjectById(containers[dest_mining].id)
        }
        
        creep.say("⛽️");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        }
        
        if (!creep.memory.full) {
            //доставать из контейнера
            if (dest_container) { 
                if (creep.withdraw(dest_container, "energy") == ERR_NOT_IN_RANGE) {
                    if (!creep.pos.isNearTo(dest_container)) {
                        creep.moveTo(dest_container, {reusePath: 10});
                    }
                }
                //доставать из source
            } else if (creep.harvest(sources[dest_mining]) == ERR_NOT_IN_RANGE) {
                creep.moveTo(sources[dest_mining]);
            }
        } else if (creep.memory.full) {
            // console.log(spawns[0].store["energy"], creep.name);
            if (creep.room.controller.ticksToDowngrade < ticksToSaveController) {
                if (creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(creep.room.controller, {reusePath: 10});
                }
            } else if (extensions[0] && extensions[0].store.getFreeCapacity("energy") > 0) {
                const range_1_str = creep.pos.findInRange(FIND_MY_STRUCTURES, 1); 
                if  (range_1_str) {
                    for (var y = 0; y < range_1_str.length;y++) {
                        if (range_1_str[y].structureType == STRUCTURE_EXTENSION && range_1_str[y].energy < range_1_str[y].energyCapacity) {
                            creep.transfer(range_1_str[y], RESOURCE_ENERGY);
                            creep.moveTo(extensions[0], {reusePath: 10}); //move к самому незаполненному (потому что можно)
                        }
                    }
                } else if(creep.transfer(extensions[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                        creep.moveTo(extensions[0]);
                }
                if(creep.transfer(extensions[0], RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(extensions[0]);
                }
            } else if (spawn0.store["energy"] < 300) {
                if(creep.transfer(spawn0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(spawn0, {reusePath: 10});
                }
            } else 
            if (towers && towers.length > 0 && tower0.store["energy"] < 800) {
                if(creep.transfer(tower0, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(tower0, {reusePath: 10});
                }
            } else 
            if (constructionsSite) {
                if(creep.build(constructionsSite) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(constructionsSite);
                }
            } else if (creep.room.controller) {
                if (creep.upgradeController(creep.room.controller) == ERR_NOT_IN_RANGE) {
                    creep.moveTo(creep.room.controller, {reusePath: 10});
                }
            }
            
        }
        
        
        // --starter logic end--
        
    }
};

module.exports = roleStarter;


module.exports = {
    
    maxCreeps: {
        1: { //начинают стартеры и все делают до 2 лвл
            starter: 6,
            defender: 2
        },
        2: { //все роли распределены, стартеры удаляются
            starter: 4,
            miner: 2,
            defender: 2,
            upgrader: 2
        },
        3: {
            starter: 2,
            miner: 2,
            defender: 2,
            upgrader: 2
        }
    },
    triggers: {
        countsZeroing: 0
    },
    roles: ["starter", "miner", "upgrader", "helper", "defender"],
    spawnLevels: {
        1: 300,
        2: 550,
        3: 800,
        4: 1300,
        5: 1800,
        6: 2300,
        7: 5300,
        8: 12300
    },
    creepBody: {
        starter: { //универсальные рабочие пока все плохо
            1: { WORK: 1, CARRY: 1, MOVE: 2 },
            2: { WORK: 2, CARRY: 2, MOVE: 4 },
            3: { WORK: 2, CARRY: 6, MOVE: 4 },
        },
        defender: { //ближний бой на всякий случай пока нет турелей
            1: {MOVE: 2, ATTACK: 2},
            2: {TOUGH: 1, MOVE: 4, ATTACK: 3},
            3: {TOUGH: 1, MOVE: 4, ATTACK: 3},
        },
        miner: { //статичные копатели (строят вокруг себя||скидывают в ближайшие контейнеры/линки)
            2: { WORK: 3, CARRY: 2, MOVE: 2},
            3: { WORK: 5, CARRY: 2, MOVE: 3},
        },
        upgrader: {
            2: { WORK: 2, CARRY: 4, MOVE: 3 },
            3: { WORK: 4, CARRY: 4, MOVE: 4 },
        }
        
    }
    
    
};
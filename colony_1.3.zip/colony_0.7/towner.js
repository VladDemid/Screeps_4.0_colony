var funcs = require("funcs");

var roleTowner = {

    run: function(creep, roomsStructures, creepFuncs) {
        // --towner logic start--
        
        const myActionName = creep.name.split("_")[1]
        const myFlagAction = Memory.gl_var.myRooms[creep.memory.startRoom].flagEvents[myActionName]
        
        let targetPos = null
        let targetRoom = null
        
        if (myFlagAction) {
            targetPos = myFlagAction.flagPosition
            targetRoom = myFlagAction.flagTargetRoom
            if (creep.ticksToLive == 1499 || !creep.memory.targetRoomMem) {
                creep.memory.targetRoomMem = targetRoom
            }
        }
        
        const targetRoomMem = creep.memory.targetRoomMem
        
        creep.say("🧱");
        
        if (creep.store["energy"] == 0) {
            creep.memory.full = false;
        } else if (creep.store["energy"] == creep.store.getCapacity()) {
            creep.memory.full = true;
        } 
        
        creepIndex = creep.name.split('_')[2] - 1
        const dest = creepFuncs.isOdd(creepIndex)
        
        
        
        // console.log(creep.room.controller.reservation.username);
        if (Game.cpu.bucket > 3000) {
            if (creep.pos.roomName != creep.memory.targetRoomMem ) {
                creep.say("🥾🧱");
                creepFuncs.myRoutes(creep, targetRoomMem)
            } else {
                // creep.moveTo(25,25);
                if (!creep.memory.full ) {
                    if (creep.ticksToLive > 50) {
                        // const drop = null
                        const drop = creep.pos.findClosestByRange(FIND_DROPPED_RESOURCES, {
                            filter: (i) => i.resourceType == "energy" && 
                                           i.amount > 20
                        });
                        const ruina = creep.pos.findClosestByRange(FIND_RUINS, {
                            filter: (i) => i.store["energy"] >= 50
                        });
                        const tomb = creep.pos.findClosestByRange(FIND_TOMBSTONES, {
                            filter: (i) => i.store["energy"] >= 20
                        });
                        
                        // let targetTakeFrom = null
                        // if (drop && tomb) {
                        //     const dropRange = creep.pos.getRangeTo(drop)
                        //     const tombRange = creep.pos.getRangeTo(tomb)
                        //     if (dropRange < tombRange) {
                        //         targetTakeFrom = drop
                        //         console.log(dropRange);
                        //     } else {
                        //         targetTakeFrom = tomb
                        //         console.log('tomb');
                        //     }
                        // }
                        
                        const targetId = Game.getObjectById("615325588b0a09f867bcbe46")
                        if (targetId && targetId.room.name == creep.room.name && targetId.store["energy"] > 0) {
                            if(creep.withdraw(targetId, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                                if (!creep.pos.isNearTo(targetId)) {
                                    creep.moveTo(targetId);
                                }
                            }
                        } else 
                        if (ruina) {
                            if(creep.withdraw(ruina, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                                if (!creep.pos.isNearTo(ruina)) {
                                    creep.moveTo(ruina);
                                }
                            }
                        }
                        
                        // =============
                        else {
                            const sources = creep.room.find(FIND_SOURCES);
                            let target_source;
                            
                            if (sources[dest]) {
                                target_source = sources[dest];
                            } else {
                                target_source = sources[0];
                            }
                            if (creep.harvest(target_source) == ERR_NOT_IN_RANGE) {
                                creep.moveTo(target_source, {reusePath: 10});
                            } else {
                                if (!creep.pos.inRangeTo(target_source, 2)) {
                                    creep.moveTo(target_source, {reusePath: 10});
                                }
                            }
                        }
                        // =============
                    } else {
                        if(creep.store["energy"] > 0) {
                            creep.memory.full = true;
                        } else {
                            creep.suicide()
                        }
                    }
                    // creepFuncs.moveFromEdge(creep)
                    // if (!creep.pos.inRangeTo(25,25, 3)) {
                    //     creep.moveTo(25,25);
                    // }
                    
                } else if (creep.memory.full) {
                    
                    let lowStr = null // раз в N тиков чинить сроения рядом
                    if (Game.time % 150 == 0) {
                        lowStr = creep.pos.findInRange(FIND_STRUCTURES, 3, {
                            filter: (i) => (i.hits <= i.hitsMax)
                        })[0];
                    }
                    const construction = creep.pos.findClosestByRange(FIND_CONSTRUCTION_SITES);
                    // const targetId2 = Game.getObjectById("610d2d2ddf51c53f321b1aa9")
                    
                    if (lowStr) {
                        creep.repair(lowStr)
                    } else if (construction) {
                        if(creep.build(construction) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(construction, {reusePath: 10});
                        }
                    } else 
                    // if (targetId2 && targetId2.store["energy"] < 1000000) {
                    //     if(creep.transfer(targetId2, RESOURCE_ENERGY) == ERR_NOT_IN_RANGE) {
                    //         if (!creep.pos.isNearTo(targetId2)) {
                    //             creep.moveTo(targetId2);
                    //         }
                    //     }
                    // } else
                    if (creep.room.controller.level <= 6) {
                        const controllerr = creep.room.find(FIND_STRUCTURES, {filter: {structureType: STRUCTURE_CONTROLLER}})[0];
                        if (creep.upgradeController(controllerr) == ERR_NOT_IN_RANGE) {
                            creep.moveTo(controllerr, {reusePath: 10});
                        }
                    } else {
                        if (!creep.pos.inRangeTo(25,25, 3)) {
                            creep.moveTo(25,25);
                        }
                    }
                    
                    
                }
            }
        }
        
        
        // --towner logic end--
        
    }
};

module.exports = roleTowner;
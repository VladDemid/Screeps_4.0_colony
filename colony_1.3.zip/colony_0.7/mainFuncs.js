starter = require("starter");
defender = require("defender");
miner = require("miner");
upgrader = require("upgrader");
carryer = require("carryer");
helper = require("helper");
laborant = require("laborant");
scientist = require("scientist");
extractor = require("extractor");
scout = require("scout");
scoutTeam = require("scoutTeam");
attacker = require("attacker");
attackerTeam = require("attackerTeam");
claimer = require("claimer");
towner = require("towner");
fixer = require("fixer");
roadFixer = require("roadFixer");
healer = require("healer");
powerAttacker = require("powerAttacker");
powerHealer = require("powerHealer");
powerCarryer = require("powerCarryer");


let cpuCounter = 1;
let cpuAvg = 0;
const flagsCreepsNeedMinEnergy = Memory.constants.energyThresholds.upgradersTakeEnergyFromStore + 10000

module.exports.rolesCountZeroing = function rolesCountZeroing() {
    for (let key in Memory.gl_var.myRooms) {
        Memory.gl_var.myRooms[key].screepsCounts = {}
        Memory.gl_var.myRooms[key].screepsCounts.total = 0
        for (let role of Memory.constants.roles) {
            Memory.gl_var.myRooms[key].screepsCounts[role] = 0
        }
    }
    // Memory.constants.triggers.countsZeroing = 1
};

module.exports.cleanMemory = function cleanMemory(room, roomSpawnLevel) {
    if (Memory.gl_var.gl_i == 1) {
        // console.log(Object.keys(Memory.constants.roomMaxCreeps[room])); 
        for (let i = 1; i < roomSpawnLevel; i++) {
            delete Memory.constants.roomMaxCreeps[room][i]
            // console.log(`deleted ${room} ${i} memory`);
        }
    }
    // console.log(room);
    
};


module.exports.rolesMaxModifier = function rolesMaxModifier(population, roomsMaxCreeps) {
    for (let room in Memory.gl_var.myRooms) {
        const roomSpawnLevel = population.getSpawnLevel(room)
        const roomMemInfo = Memory.gl_var.myRooms[room]
        Memory.gl_var.myRooms[room].spawnLevel = roomSpawnLevel
        
        // console.log(room, roomSpawnLevel);
        this.cleanMemory(room, roomSpawnLevel)
        
        // Memory.constants.roomMaxCreeps[room][roomSpawnLevel] = {} //??????
        
        if (roomSpawnLevel <= 3) {
            if (roomMemInfo.containersSorted) {
                if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1] && roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 1700) { //тут была ошибка 
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 4
                    if (Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter == 2) {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 3 //чтобы не заглохло
                    }
                }
            }
        }
        
        if (Memory.gl_var.myRooms[room].structures.storage && Memory.gl_var.myRooms[room].structures.storage.length && roomSpawnLevel >= 4) {
            const myController = Memory.gl_var.myRooms[room].structures.controller[0]
            
            //miner's
            if (roomSpawnLevel == 8 &&  Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.decreaseMinersNumber) {
                // console.log(room, 'спавнить одного майнера');
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].miner = 1 // типа экономия
            } else {
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].miner = 2
            }
            
            //upgrader's
            if (myController.level < 8 || myController.ticksToDowngrade < 80000 ||  ( !!Memory.gl_var.myRooms[room].foundConstrSites && !!Memory.gl_var.myRooms[room].foundConstrSites[0] ) || Game.gcl.level < Memory.constants.targetGCL ) {
                if (Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.increaseUpgradersNumber1 && Game.cpu.bucket > 7000) {
                    // console.log(room, "upgraders = 4");
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 4
                    if (myController.level == 7) {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 2 //т.к. уже можно делать норм крипов //TEST (2)
                    }
                } else if (Game.rooms[room].storage.store["energy"] < Memory.constants.energyThresholds.decreaseUpgradersNumber1) {
                    // if (room == "W47N31") {
                    //     console.log(123);
                    // }            
                    // console.log(room, Memory.constants.roomMaxCreeps[room][roomSpawnLevel]);
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 1
                } 
            } else {
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 0 //если уже улучшено
            }
            
            // Memory.constants.roomMaxCreeps["W41N47"][8].upgrader = 3
            // Memory.constants.roomMaxCreeps["W46N39"][8].fixer = 4
            // Memory.constants.roomMaxCreeps["W49N39"][8].fixer = 7
            // Memory.constants.roomMaxCreeps["W41N47"][7].upgrader = 4
            // -------------------------------
            // Memory.constants.roomMaxCreeps["W43N29"][8].fixer = 3
            //--------------------------------
            
            if (myController.level == 8 && Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader > 1) {
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].upgrader = 1 //ограничить кол-во upgrader`ов
            }
            
            //carryer's
            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 1
            if (roomMemInfo.containersSorted && roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1]) {
                if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 1700) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 3
                } else if (roomMemInfo.containersSorted[roomMemInfo.containersSorted.length - 1].store["energy"] > 500) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 2
                }
            }
            
            //helper
            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].helper = 1
            
            //starter's 
            const helperName = `${room}_helper_1`
            const helperCreep = Game.creeps[helperName]
            if (Memory.gl_var.gl_i == 1 || Memory.gl_var.gl_i % 20 == 0) { // чтобы каждый тик не считать countAmountToSpawn("starter")
                if (helperCreep || Game.rooms[room].energyAvailable >= population.countAmountToSpawn("helper", roomSpawnLevel)) {
                    //наверно надо еще проверять майнеров
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 0
                } else {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].starter = 2
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].helper = 0
                }
            }
            
            //ФЛАГИ 
            const flagEvents = Memory.gl_var.myRooms[room].flagEvents
            if (flagEvents && Object.keys(flagEvents).length != 0 && Game.rooms[room].storage.store["energy"] > flagsCreepsNeedMinEnergy) {
                // console.log(room, Object.keys(flagEvents).length);
                for (let actionName in flagEvents) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel][actionName] = flagEvents[actionName].flagCount
                    // Memory.constants.roomMaxCreeps[room][roomSpawnLevel]["test"] = flagEvents[actionName].flagCount
                    // ---!!!!!!!!!!!!!---
                }
            }
             
            if (Memory.obsInfo && Memory.obsInfo[room] && (Memory.obsInfo[room].status == 'idle' || Memory.obsInfo[room].status == 'taking') ) {
                Memory.constants.roomMaxCreeps[room][8].powerAttacker = 0
                Memory.constants.roomMaxCreeps[room][8].powerHealer = 0
                Memory.constants.roomMaxCreeps[room][8].powerCarryer = 0
            }
            
            
            //fixer's
            if (Game.time % 280 == 0) {
                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 0 //изначальный сброс если энергия упала в storage
                if (Game.cpu.bucket > 8000 && Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.fixerCanSpawnEnergy) {
                    //нахождение слабых стен и рампартов
                    const lowWallsRamps = Game.rooms[room].find(FIND_STRUCTURES, {
                        filter: (i) => (i.structureType == "constructedWall" && i.hits <= Memory.constants.wallsHitsMin[roomSpawnLevel])
                                    || (i.structureType == "rampart" && i.hits <= Memory.constants.wallsHitsMin[roomSpawnLevel])
                    });
                    lowWallsRamps.sort((a,b) => a.hits - b.hits);
                    if (lowWallsRamps.length) {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 1
                        if (lowWallsRamps[0].hits < Memory.constants.wallsHitsMin[roomSpawnLevel] * 0.97 && roomSpawnLevel == 8) { //чтобы когда все улучшится, не спавнить 3-х ради небольшого ремонта
                            if (Game.cpu.bucket > 9000 && Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.fixerCanSpawnEnergy * 3) {
                                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 3
                            } else if (Game.cpu.bucket > 8500 && Game.rooms[room].storage.store["energy"] > Memory.constants.energyThresholds.fixerCanSpawnEnergy * 2) {
                                Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 2
                            }
                        }
                    } else {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 0
                    }
                    
                    if (Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer == 0) {
                        
                        const targetHits = Memory.constants.wallsHitsMin[roomSpawnLevel]
                        let storageRamp = null
                        if (Memory.gl_var.myRooms[room].strgRmpId) {
                            storageRamp = Game.getObjectById(Memory.gl_var.myRooms[room].strgRmpId.id)
                        }
                        
                        if (storageRamp && storageRamp.hits < targetHits * 2) {
                            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].fixer = 1
                        }
                    }
                }
                
                
            }
            // Memory.constants.roomMaxCreeps["W47N31"][8].fixer = 1
            
            //roadFixer для W45N41
            // if (Game.time % 300 == 0 && room == "W45N41") {
            //     const roadId = "611a2b502e39065cce0eff3a"
            //     const road = Game.getObjectById(roadId)
            //     if (road && road.hits < 100000) {
            //         Memory.constants.roomMaxCreeps[room][roomSpawnLevel].roadFixer = 1
            //     } else {
            //         Memory.constants.roomMaxCreeps[room][roomSpawnLevel].roadFixer = 0
            //     }
            // }
            
            if (roomSpawnLevel >= 6) {
                
                //laborant
                if ( Memory.gl_var.myRooms[room].links && Memory.gl_var.myRooms[room].links.linkTo && Memory.gl_var.myRooms[room].links.linkTo.id) {
                    //приравнять carryerMax = 0 на всякий
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].carryer = 0
                    
                }
                
                //extractor
                if (Game.time % 180 == 0 && Game.cpu.bucket > 7000 && Memory.gl_var.myRooms[room].structures.extractor && Memory.gl_var.myRooms[room].structures.extractor.length && Game.rooms[room].storage && Game.rooms[room].storage.store["energy"] > 20000) {
                    const mineral = Game.getObjectById(Memory.gl_var.myRooms[room].sciense.mineral.mineralId)
                    const myTerminal = Game.rooms[room].terminal
                    const lessExtrsRooms = ["W43N29", "W48N35", "W48N49", "W43N41", "W45N41", "W41N47", "W49N37"]
                    const moreExtrsRooms = []
                    
                    if (myTerminal && mineral.mineralAmount > 0 && (myTerminal.store[mineral.mineralType] < Memory.constants.economyThresholds.myMineralMax || mineral.mineralAmount < 10000)) {
                        if ( lessExtrsRooms.includes(room) || mineral.mineralAmount < 5000 ) {
                            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].extractor = 1
                        } else {
                            Memory.constants.roomMaxCreeps[room][roomSpawnLevel].extractor = 2
                        }
                    } else {
                        Memory.constants.roomMaxCreeps[room][roomSpawnLevel].extractor = 0
                    }
                    
                }
                
                //scientist
                if (myController.level == 8 || (Memory.gl_var.myRooms[room].structures.lab && Memory.gl_var.myRooms[room].structures.lab.length >= 6) ) {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].scientist = 1
                } else {
                    Memory.constants.roomMaxCreeps[room][roomSpawnLevel].scientist = 0
                }
            }
            
            
        }
        
        
        
        
        //модификации из флагов
        // if (Memory.flagsInfo && Memory.flagsInfo[room]) {
        //     for (let actionName in Memory.flagsInfo[room]) {
        //         // console.log(room, actionName);
        //     }
        //     // Memory.constants.roomMaxCreeps[room][roomSpawnLevel][]
        // }
        
    }
};

module.exports.checkHealth = function checkHealth(creep) {
    // console.log(creep.hits, creep.hitsMax);
    if (creep.hits < creep.hitsMax && creep.pos.roomName == creep.memory.startRoom) {
        const room = creep.memory.startRoom
        const creepToHeal = {
                creepName: creep.name,
                creepRoom: creep.room.name, //где сейчас
            }
        Memory.gl_var.myRooms[room].needHeal = creepToHeal
        // console.log(Memory.gl_var.myRooms[room].needHeal);
    }
};

module.exports.activateCreep = function activateCreep(creep, roomsStructures) {
    this.checkHealth(creep)
    Memory.gl_var.myRooms[creep.memory.startRoom].screepsCounts.total++;
    eval(creep.memory.role).run(creep, roomsStructures, creepFuncs)
    // starter.run(creep)
};

module.exports.cpuCount = function cpu_used() {
    const n = 50;
    cpuAvg = cpuAvg + Game.cpu.getUsed(); 
    
    if (cpuCounter >= n) {
        console.log(`last ${n} ticks cpuAvg usage: `+ (cpuAvg/n).toFixed(2));
        cpuCounter = 1;
        cpuAvg = 0;
    }
    cpuCounter++;
}







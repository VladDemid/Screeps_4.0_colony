module.exports.roomLevels = function roomLevels() {
    mainRoom = "W45N41"
    const posX = 27
    const posY = 6
    if (!Memory.visual || Game.time % 200) {
        Memory.visual = {}
        Memory.visual.roomsInfo = {}
        for (let room in Memory.gl_var.myRooms) {
            if (Game.rooms[room].controller && Game.rooms[room].controller.my) {
                roomMem = Memory.gl_var.myRooms[room]
                Memory.visual.roomsInfo[room] = {}
                Memory.visual.roomsInfo[room].creepsCount = roomMem.screepsCounts.total
                Memory.visual.roomsInfo[room].spawnLevel = roomMem.spawnLevel
                
            }
        }
    }
    let index = 0
    
    //bucket
    let bucketColor = null
    const myBucket = Game.cpu.bucket
    if (myBucket > 8000) {bucketColor = "green"} else 
    if (myBucket > 6000) {bucketColor = "yellow"} else 
    if (myBucket > 4000) {bucketColor = "orange"} else 
    {bucketColor = "red"}
    
    bucketWidth = 2.9 * (myBucket / 10000)
    new RoomVisual(mainRoom).text(`Bucket-${myBucket}` , posX, posY - 0.4, {color: bucketColor, font: 0.7, stroke: "black", strokeWidth: 0.1, align: "left"});
    new RoomVisual(mainRoom).rect(posX + 4.45, posY - 1.15, 3, 1, {fill: 'transparent', stroke: 'grey'});
    new RoomVisual(mainRoom).rect(posX + 4.5, posY - 1.1, bucketWidth, 0.9, {fill: bucketColor});
    
    
    //стата по румам
    for (let room in Memory.visual.roomsInfo) {
        index++ 
        const controllerLevel = Game.rooms[room].controller.level
        const terminal = Game.rooms[room].terminal
        const spawnLevel = Memory.visual.roomsInfo[room].spawnLevel
        const creepsCount = Memory.visual.roomsInfo[room].creepsCount
        
        let thisNuker = null
        if (Memory.gl_var.myRooms[room].structures.nuker) {
            thisNuker = Game.getObjectById(Memory.gl_var.myRooms[room].structures.nuker[0].id)
        }
        
        const thisController = Game.rooms[room].controller
        const progressToUpgrade = thisController.progressTotal - thisController.progress
        const daysToUpgrade = (progressToUpgrade / 300000).toFixed(1)
        
        let statColor = null
        if (creepsCount <= 2) {statColor = "red"} else 
        if (controllerLevel != spawnLevel) {statColor = "orange"} else 
        {statColor = "gray"}
        
        let upgrColor = null
        if (daysToUpgrade <= 1) {upgrColor = "green"} else 
        if (daysToUpgrade < 3) {upgrColor = "yellow"} else 
        {upgrColor = "gray"} 
        
        new RoomVisual(mainRoom).text(`${room}: ${controllerLevel} lvl, ${creepsCount} cr` , posX, posY + index * 0.55, {color: statColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        if (terminal && terminal.store["power"] > 0 ) {
            new RoomVisual(mainRoom).text(`| ${terminal.store["power"]}p ${Math.trunc(terminal.store.getFreeCapacity()/1000)}k free` , posX + 3.5, posY + index * 0.55, {color: statColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        if (!isNaN(daysToUpgrade) ) {
            new RoomVisual(mainRoom).text(`${daysToUpgrade}` , posX + 7, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        if (daysToUpgrade < 1) { //уточнение в часах
            const hoursToUpgrade = ((progressToUpgrade / 290000) * 24).toFixed(1)
            new RoomVisual(mainRoom).text(`(${hoursToUpgrade}h)` , posX + 7.7, posY + index * 0.55, {color: upgrColor, font: 0.4, stroke: "black", strokeWidth: 0.1, align: "left"});
        }
        if (thisNuker) {
            
            let nukerCooldown = thisNuker.cooldown
            let nukerReady = "red"
            if (nukerCooldown < 25000 && nukerCooldown > 0) {
                nukerReady = "yellow" //наполнение|ожидание ресов
            } else if (nukerCooldown == 0) {
                if (thisNuker.store["energy"] == 300000 && thisNuker.store["G"] == 5000) {
                    nukerReady = "green"
                } else {
                    nukerReady = "white"
                }
            } 
            // else if (nukerCooldown < 28000) {
            //     nukerReady = "yellow"
            // }
            // thisNuker.store["energy"] < 300000 || thisNuker.store["G"] < 5000
            new RoomVisual(mainRoom).text(`☢️ ` , posX - 0.7, posY + index * 0.55, {color: statColor, font: 0.35, stroke: nukerReady, strokeWidth: 0.02, align: "left", opacity: 0.7});
        }
        
    }
    
    // console.log("----------------");
} 
const reverseComponents = [] //["GO"]
const reactionComponents = [ ["UO","U","O"], ["LH","L","H"], ["LO","L","O"], ["UH","U","H"], ["ZK","Z","K"], ["UL","U","L"], ["G","ZK","UL"],
                             ["OH","O","H"], ["KH","K","H"], ["ZH","Z","H"], ["ZO","Z","O"], ["GO","G","O"], 
                             ["LHO2","LH","OH"], ["XLHO2","LHO2","X"],
                             ["GHO2","GO","OH"], ["XGHO2","GHO2","X"],
                             ["ZH2O","ZH","OH"], ["XZH2O","ZH2O","X"]] 
//UH2O, XUH2O пока не делаются

module.exports.checkLabs = function checkLabs(room) {
    const labCpuStart = Game.cpu.getUsed()
    
    const allLabs = Memory.gl_var.myRooms[room].labs
    const terminal = Game.rooms[room].terminal
    
    let boostLab = null
    let inputLabs = []
    let outputLabs = []
    
    if (allLabs.boostLab) {
        boostLab = Game.getObjectById(allLabs.boostLab.id)
    }
    if (allLabs.inputLabs) {
        for (lab of allLabs.inputLabs) {
            inputLabs.push(Game.getObjectById(lab.id))
        }
    }
    if (allLabs.outputLabs) {
        for (lab of allLabs.outputLabs) {
            outputLabs.push(Game.getObjectById(lab.id))
        }
    }
    
    if (!Memory.synthesis) {
        Memory.synthesis = {}
    }
    if (!Memory.synthesis[room]) {
        Memory.synthesis[room] = {
            action: "idle",
            status: null,
            components: null
        }
    }
    
    // Memory.synthesis["W41N47"] = {
    //     action: "idle",
    //     status: null,
    //     components: null
    // }
    
    
    const thisScientistName = room + "_scientist_1"
    const thisScientist = Game.creeps[thisScientistName]
    // console.log(thisScientistName, !!thisScientist);
    
    buildMode = Memory.gl_var.myRooms[room].foundConstrSites[0]
    
    // this.markLabs(boostLab, inputLabs, outputLabs)
    if (Game.cpu.bucket > 5500) { //работа лаб
        this.checkReactionsQueue(boostLab, inputLabs, outputLabs, room, terminal, buildMode, thisScientist)
    }
    
    
    const labCpuEnd = Game.cpu.getUsed() - labCpuStart
    if (boostLab) {
        new RoomVisual(boostLab.room.name).text(labCpuEnd.toFixed(2) , boostLab.pos.x, boostLab.pos.y+0.5, {color: "grey", font: 0.3, stroke: "black", strokeWidth: 0.1});
    }
};

// Object.keys(thisScientist.store)[0]
module.exports.checkReactionsQueue = function checkReactionsQueue(boostLab, inputLabs, outputLabs, room, terminal, buildMode, thisScientist) {
    
    const myStorage = Game.rooms[room].storage  
    
    let nuker = null
    if (Memory.gl_var.myRooms[room].structures["nuker"]) {
        nuker = Game.getObjectById(Memory.gl_var.myRooms[room].structures["nuker"][0].id) 
    }
    let pSpawn = null
    if (Memory.gl_var.myRooms[room].structures["powerSpawn"]) {
        pSpawn = Game.getObjectById(Memory.gl_var.myRooms[room].structures["powerSpawn"][0].id)
    }
    
    let nukerIsFull = true //по умолчанию типа заполнена, даже если её нет
    if (nuker) {
        nukerIsFull = !!(nuker.store["G"] == 5000)
    }
    let pSpawnIsFull = true //по умолчанию типа заполнена, даже если её нет
    if (pSpawn) {
        pSpawnIsFull = !!(pSpawn.store["power"] > 0)
    }
    
    let nukerNeedFilling = false
    if (nuker && !nukerIsFull && terminal && thisScientist && (thisScientist.store["G"] + terminal.store["G"] + nuker.store["G"]) >= 5000 ) {
        nukerNeedFilling = true
    }
    let pSpawnNeedFilling = false
    if (pSpawn && !pSpawnIsFull && myStorage && terminal && thisScientist && ( (thisScientist.store["power"] + myStorage.store["power"] + pSpawn.store["power"]) >= 100 || (thisScientist.store["power"] + terminal.store["power"] + pSpawn.store["power"]) >= 100) ) {
        pSpawnNeedFilling = true
    }
    
    const scientistIsFree = !nukerNeedFilling && !pSpawnNeedFilling
    
    
    if (Memory.synthesis[room] && Memory.synthesis[room].action == "idle" && !buildMode && Game.time % 1 == 0 && scientistIsFree && (!thisScientist || (thisScientist && !Object.keys(thisScientist.store)[0]) ) ) {
        if (reverseComponents.length) { 
            for (component of reverseComponents) {
                if (terminal.store[component] > 5000) {
                    Memory.synthesis[room].action = "reverse"
                    Memory.synthesis[room].status = "waiting"
                    Memory.synthesis[room].components = [component]
                    // console.log(component);
                    break;
                }
            }
        }
        if (Memory.synthesis[room].action == "idle") { // если в предыдущем цикле не исправилось, то искать дальше
            for (component of reactionComponents) {
                if (terminal.store[component[0]] < Memory.constants.economyThresholds.boostsAmountMax && terminal.store[component[1]] >= 3000 && terminal.store[component[2]] >= 3000) {
                    // console.log(component[0], "< 3000");
                    Memory.synthesis[room].action = "synthesis"
                    Memory.synthesis[room].status = "waiting"
                    Memory.synthesis[room].components = [component[1], component[2]]
                    break;
                }
            }
        }
    } else if (Memory.synthesis[room].action == "reverse") {
        if (Memory.synthesis[room].status == "active") {
            for (lab of outputLabs) {
                if (lab.store[Memory.synthesis[room].components[0]] > 0) {
                    if ( lab.cooldown == 0) {
                        lab.reverseReaction(inputLabs[0], inputLabs[1])  
                        if (lab.reverseReaction(inputLabs[0], inputLabs[1]) == ERR_NOT_ENOUGH_RESOURCES) {
                            Memory.synthesis[room].status = "ready" //закончили упражнение
                        }
                    }
                } else {
                    Memory.synthesis[room].status = "ready" //закончили упражнение
                }
            }
        }
    } else if (Memory.synthesis[room].action == "synthesis") {
        if (Memory.synthesis[room].status == "active") {
            for (lab of outputLabs) {
                if (lab.cooldown == 0) {
                    lab.runReaction(inputLabs[0], inputLabs[1])
                    if (lab.runReaction(inputLabs[0], inputLabs[1]) == ERR_NOT_ENOUGH_RESOURCES) {
                        Memory.synthesis[room].status = "ready" //закончили упражнение
                    }
                }
                if ( inputLabs[0].store.getUsedCapacity() == 0 || inputLabs[1].store.getUsedCapacity() == 0) {
                     Memory.synthesis[room].status = "ready" //закончили упражнение
                }
            }
        }
    }
    
}

module.exports.markLabs = function markLabs(boostLab, inputLabs, outputLabs) {
    if (boostLab) {
        // console.log(Object.keys(boostLab), );
        new RoomVisual(boostLab.room.name).text(`💊` , boostLab.pos.x, boostLab.pos.y + 0.05, {color: "white", font: 0.3, stroke: "black", strokeWidth: 0.1, opacity: .7});
    }
    
    if (inputLabs) {
        for (lab of inputLabs) {
            new RoomVisual(lab.room.name).text(`📥` , lab.pos.x, lab.pos.y + 0.05, {color: "white", font: 0.5, stroke: "black", strokeWidth: 0.1, opacity: .7});
        }
    }
    
    if (outputLabs) {
        for (lab of outputLabs) {
            new RoomVisual(lab.room.name).text(`📤` , lab.pos.x, lab.pos.y + 0.05, {color: "white", font: 0.4, stroke: "black", strokeWidth: 0.1, opacity: .7});
        }
    }
    
};
